import { Helpers, FileNameOptions, Toc, Section, Module, Chapter } from './interfaces'
import { Browser, Page } from 'puppeteer'
/**
 * Take url to the first page of the book from openstax.org / cnx.org / herokuapp.com
 * or any subdomain like staging.openstax.org / staging.cnx.org / rex-web-issue-947-np39vpknfjij.herokuapp.com
 * and return object with helpfull data and functions.
 *
 * @param url url to the first page in the book on openstax.org or any subdomain.
 */
const parseUrl = (url: string): Helpers => {
  if (!/https:\/\//.test(url)) {
    throw new Error('Provided url has to start with "https://".')
  }

  return {
    domain: getDomainUrl(url),
    baseUrlForBook: getBaseUrlForBook(url),
    nextPageSelector: getNextPageSelector(url),
    mainContentSelector: getMainContentSelector(url),
    tocSelector: getTocSelector(url),
    bookTitleSelector: getBookTitleSelector(url),
    moduleTitleSelector: getModuleTitleSelector(url),
    isOpenstaxOrg: isOpenstaxOrg(url),
    isHerokuappCom: isHerokuappCom(url),
    isCnxOrg: isCnxOrg(url),
    isRex: isOpenstaxOrg(url) || isHerokuappCom(url),
    createNextPageUrl,
    createFileName,
  }
}

export default parseUrl

const isOpenstaxOrg = (url: string): boolean => Boolean(url.match(/https\:\/\/.*openstax\.org/g))
const isHerokuappCom = (url: string): boolean => Boolean(url.match(/https\:\/\/.*herokuapp\.com/g))
const isCnxOrg = (url: string): boolean => Boolean(url.match(/https\:\/\/.*cnx\.org/g))

export const isValidUrl = (url: string) => isOpenstaxOrg(url) || isHerokuappCom(url) || isCnxOrg(url)
/**
 * Get everything between https and domain.xxx
 * Throws an error if provided url is not supported.
 *
 * @param {string} url
 */
const getDomainUrl = (url: string): string => {
  if (isOpenstaxOrg(url)) return url.match(/https\:\/\/.*openstax\.org/g)![0]
  if (isHerokuappCom(url)) return url.match(/https\:\/\/.*herokuapp\.com/g)![0]
  if (isCnxOrg(url)) return url.match(/https\:\/\/.*cnx\.org/g)![0]
  throw new Error('Provided url must be in openstax.org, cnx.org or herokuapp.com domain.')
}

/**
 * Get base url for pages in specific book. It will be merged with next page url
 * to create url for the next page.
 * Throws an error if provided url is not supported.
 *
 * @param {string} url
 */
const getBaseUrlForBook = (url: string): string => {
  if (isOpenstaxOrg(url) || isHerokuappCom(url)) {
    const domain = getDomainUrl(url)
    const temp = url.match(/\/books\/.*\/pages\//)
    if (!temp) throw new Error(`Couldn't obtain book name from provided url`)
    const bookName = temp[0].replace(/(\/books\/|\/pages\/)/g, '')
    return cleanUrl(`${domain}/books/${bookName}/pages/`)
  } else if (isCnxOrg(url)) {
    // In cnx.org next page url contains everything which is required so we can pass domain name
    return url.match(/https\:\/\/.*cnx\.org/g)![0]
  }
  throw new Error('Provided url must be in openstax.org, cnx.org or herokuapp.com domain.')
}

/**
 * Make sure that url does not contain multiple slashes.
 *
 * @param {string} url
 */
export const cleanUrl = (url: string) => url.replace(/\/+/g, '/').replace(/https:\//g, 'https://')

/**
 * CSS selector for next page button depends on url domain.
 *
 * @param {string} url
 */
const getNextPageSelector = (url: string) => isOpenstaxOrg(url) || isHerokuappCom(url)
  ? '[aria-label="Next Page"]'
  : 'a.nav.next'

/**
 * CSS selector for div which holds book content depends on url domain.
 *
 * @param {string} url
 */
const getMainContentSelector = (url: string) => isOpenstaxOrg(url) || isHerokuappCom(url)
  ? '#main-content > div'
  : '.media-body #content > div'

/**
 * CSS selector for div which holds ToC depends on url domain.
 *
 * @param {string} url
 */
const getTocSelector = (url: string) => isOpenstaxOrg(url) || isHerokuappCom(url)
  ? '[data-testid="toc"]'
  : '.toc'

/**
 * CSS selector for book title depends on url domain.
 *
 * @param {string} url
 */
const getBookTitleSelector = (url: string) => isOpenstaxOrg(url) || isHerokuappCom(url)
  ? '[data-testid="bookbanner"] a'
  : '.title h1'


/**
 * CSS selector for module title depends on url domain.
 *
 * @param {string} url
 */
const getModuleTitleSelector = (url: string) => isOpenstaxOrg(url) || isHerokuappCom(url)
  ? 'li[aria-label="Current Page"] a'
  : '.table-of-contents > .toc ul li > div > .name-wrapper .active'


/**
 * Make valid url for next page from parts.
 *
 * @param {string} baseUrl
 * @param {string} nextPageUrl
 */
const createNextPageUrl = (baseUrl: string, nextPageUrl: string) => {
  // nextPageUrl from openstax.org and herokuapp.com may contain multiple "../"
  const parsed = nextPageUrl.replace(/\.\.\//g, '')
    // nextPageUrl from openstax.org and herokuapp.com may start with /bookName/pages/
    .replace(/.*\/pages\//, '')
  return cleanUrl(`${baseUrl}/${parsed}`)
}

/**
 * Creates filename from passed filenamePlaceholder and arguments.
 * Remove search query from url string
 * Remove slash from the end of url
 * Replace slashes with "+" and colons with "_" in the url.
 * Replace / \ ? % * : | " < > ] .  in the filename with _
 * Set file format.
 */
const createFileName = (filenamePlaceholder: string, options: FileNameOptions) => {
  const {
    bookTitle,
    chapterTitle,
    domain,
    moduleTitle,
    format = 'png',
    url,
  } = options
  const parsedUrl = decodeURIComponent(url.replace(/\?.*/, '').replace(/\/$/, '').replace(/\//g, '+').replace(/\:/g, '_'))
  const processed = filenamePlaceholder
    .replace(/<bookTitle>/g, bookTitle)
    .replace(/<chapterTitle>/g, chapterTitle)
    .replace(/<domain>/g, domain)
    .replace(/<moduleTitle>/g, moduleTitle)
    .replace(/<url>/g, parsedUrl)
  return `${processed.replace(/[/\\?%*:|"<>\.]/g, '_')}.${format}`
}

const isValidTocSection = (value: any): value is Section => {
  if (value instanceof Object) {
    if (
      value.type === 'module'
      && typeof value.title === 'string'
      && typeof value.url === 'string'
    ) {
      return true
    }

    if (
      value.type === 'chapter'
      && typeof value.title === 'string'
      && Array.isArray(value.sections)
      && value.sections.length > 0
      && value.sections.every(isValidTocSection)
    ) {
      return true
    }
  }
  return false
}

export const isValidToc = (value: any): value is Toc => {
  if (value instanceof Object) {
    if (
      typeof value.bookTitle === 'string'
      && Array.isArray(value.sections)
      && value.sections.every(isValidTocSection)
    ) return true
    return false
  }
  return false
}

const isModule = (section: Section): section is Module => {
  return section.type === 'module'
}

const isChapter = (section: Section): section is Chapter => {
  return section.type === 'chapter'
}


export const getModulesFromSections = (sections: Section[]): Module[] => {
  const modules: Module[] = []
  for (const section of sections) {
    if (isModule(section)) {
      modules.push(section)
    } else if (isChapter(section)) {
      modules.push(...getModulesFromSections(section.sections))
    }
  }
  return modules
}

export const getChapterForModule = (sections: Section[], module: Module, initialChapter?: Chapter): Chapter | undefined => {
  for (const section of sections) {
    if (
      isModule(section)
      && section.title === module.title
      && section.url === module.url
    ) {
      return initialChapter
    } else if (isChapter(section)) {
      const chapter = getChapterForModule(section.sections, module, section)
      if (chapter) {
        return chapter
      }
    }
  }
  return undefined
}

export const openNewPage = async (browser: Browser, { width, height }: { width: number, height: number }, logger: Logger): Promise<Page> => {
  logger('Opening new tab...', 'info')
  const page = await browser.newPage()

  logger(`Setting viewport to ${width}x${height}px`, 'log')
  await page.setViewport({
    width: 1920,
    height: 1080,
    deviceScaleFactor: 1,
  })

  return page
}

export type Logger = (msg: string, type?: 'log' | 'info' | 'warn' | 'error') => void

export const createLogger = (level: string | 'development' | 'production' = 'development'): Logger => {
  if (level === 'development') {
    return (msg: string, type: 'log' | 'info' | 'warn' | 'error' = 'log') => console[type](msg)
  } else if (level === 'production') {
    return (msg: string, type: 'log' | 'info' | 'warn' | 'error' = 'log') => {
      if (type === 'log') return
      console[type](msg)
    }
  } else {
    console.error(`Level: ${level} is unsuportted. Supported values: "development" and "production"`)
    return () => {}
  }
}
