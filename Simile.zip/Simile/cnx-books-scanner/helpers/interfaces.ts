export interface Helpers {
  domain: string
  baseUrlForBook: string
  nextPageSelector: string
  mainContentSelector: string
  tocSelector: string
  bookTitleSelector: string
  moduleTitleSelector: string
  isOpenstaxOrg: boolean
  isHerokuappCom: boolean
  isCnxOrg: boolean
  isRex: boolean
  createNextPageUrl: (baseUrl: string, nextPageUrl: string) => string
  createFileName: (filenamePlaceholder: string, options: FileNameOptions) => string
}

export interface Module {
  type: 'module'
  title: string
  url: string
}

export interface Chapter {
  type: 'chapter'
  title: string
  sections: Section[]
}

export type Section = Chapter | Module

export type Toc = {
  bookTitle: string
  sections: Section[]
}

export interface FileNameOptions {
  bookTitle: string
  chapterTitle: string
  domain: string
  moduleTitle: string
  format: 'png' | 'jpg'
  url: string
}
