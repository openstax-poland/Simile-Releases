package bookScan;

import org.junit.jupiter.api.Test;


import java.io.File;
import java.io.IOException;


public class RunScanningProcessTest {

    private String pathToTestDirectory = "ScanDB" + File.separator + "0";

    @Test
    public void syntaxOfCommandThatStartsCnxBookScannerIsCorrect() {

    }

    @Test
    public void cnxBookScannerRunsProperly() throws IOException {
        // If any error appears for this test please verify if URL leads to the last page of the book.
        // It is necessary, because it makes test faster. We don't have to wait for whole book scanning.
        // If the link seems OK, then verify if CNX Book Scanner is included in the Simile project and is build.



        // Process which ends with 0 means everything went well.
//        assertEquals(exitValue, 0);
//        assertFalse(new File(pathToTestDirectory).exists());
    }
}
