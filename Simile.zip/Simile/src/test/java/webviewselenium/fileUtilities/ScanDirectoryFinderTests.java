package webviewselenium.fileUtilities;

import org.junit.Assert;
import org.junit.Test;
import webviewselenium.bookProperties.ScanProperties;

import java.io.File;

public class ScanDirectoryFinderTests {
    private final File COLLECTION_SCAN_FOLDER = new File("resources/unit-tests/collection-scan-finder");
    private final File ASTRONOMY_SCAN_FOLDER = new File("resources/unit-tests/collection-scan-finder/1");

    @Test
    public void should_find_all_scan_directories() {
        final int NUMBER_OF_SCAN_DIRECTORIES = 3;
        ScanDirectoryFinder scanDirectoryFinder = new ScanDirectoryFinder();
        Assert.assertTrue(scanDirectoryFinder.getAllScansProperties(COLLECTION_SCAN_FOLDER.getPath()).size() == NUMBER_OF_SCAN_DIRECTORIES);
    }

    @Test
    public void should_find_all_scan_properties() {
        final int NUMBER_OF_SCAN_DIRECTORIES = 3;
        final ScanProperties EXPECTED_SCAN_PROPERTIES = new ScanProperties(
                "Astronomy",
                "8.33.17.4.8.2020",
                "my first note",
                "staging.openstax.org",
                "None",
                "1"
        );

        ScanDirectoryFinder scanDirectoryFinder = new ScanDirectoryFinder();
        ScanProperties actualScanProperties = scanDirectoryFinder.findScanProperties(ASTRONOMY_SCAN_FOLDER);

        Assert.assertEquals(EXPECTED_SCAN_PROPERTIES.getTitle(), actualScanProperties.getTitle());
        Assert.assertEquals(EXPECTED_SCAN_PROPERTIES.getCreationDate(), actualScanProperties.getCreationDate());
        Assert.assertEquals(EXPECTED_SCAN_PROPERTIES.getNote(), actualScanProperties.getNote());
        Assert.assertEquals(EXPECTED_SCAN_PROPERTIES.getServer(), actualScanProperties.getServer());
        Assert.assertEquals(EXPECTED_SCAN_PROPERTIES.getEstimatedComparisonTime(), actualScanProperties.getEstimatedComparisonTime());
        Assert.assertEquals(EXPECTED_SCAN_PROPERTIES.getDirectoryIndex(), actualScanProperties.getDirectoryIndex());
    }
}
