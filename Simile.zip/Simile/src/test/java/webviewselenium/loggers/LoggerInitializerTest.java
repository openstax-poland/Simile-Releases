package webviewselenium.loggers;

import org.apache.log4j.Logger;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import webviewselenium.constans.SharedConstants;
import webviewselenium.gui.ApplicationLoader;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class LoggerInitializerTest {
	private final LoggerInitializer loggerInitializer = new LoggerInitializer();
	private Logger initializedLogger;
	private File createdLogFile;

	@BeforeEach
	void initializeLogger() {
		initializedLogger = loggerInitializer.getInitializedLogger();
		createdLogFile = new File(loggerInitializer.getLoggerFilePath());
	}

	@AfterEach
	void deleteCreatedLogFile() {
		createdLogFile.delete();
	}

	@Test
	void initializeLogger_correctFileCreation() {
		assertTrue(createdLogFile.exists());
	}

	@Test
	void initializeLogger_correctValue() {
		assertEquals(ApplicationLoader.class.getName(), initializedLogger.getName());
		assertTrue(loggerInitializer.getLoggerFilePath().contains(SharedConstants.fullNameOfDirectoryThatContainsLogs));
	}

	@Test
	void initializeLogger_correctLogsFormat() throws IOException {
		final String baseDateFormat = "\\[\\d{2}-\\d{1,2}-\\d{4}_\\d{1,2}-\\d{1,2}-\\d{1,2}(.)*";
		final Pattern infoLogPatten = Pattern.compile(baseDateFormat + "INFO(.)*");
		final Pattern warnLogPatten = Pattern.compile(baseDateFormat + "WARN(.)*");
		final Path createLogFilePath = Paths.get(loggerInitializer.getLoggerFilePath());

		initializedLogger.info("Info Test Information");
		initializedLogger.warn("Warn Test Information");

		String logFileContent = Files.lines(createLogFilePath).collect(Collectors.joining());
		assertTrue(infoLogPatten.matcher(logFileContent).matches());
		assertTrue(warnLogPatten.matcher(logFileContent).matches());
	}
}
