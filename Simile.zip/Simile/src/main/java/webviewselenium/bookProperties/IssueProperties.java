package webviewselenium.bookProperties;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Class contains fields that fully describe each Issue component.
 */
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class IssueProperties {
    private String title;
    private String category;
    private String description;
    private String creationDate;
    private String parentDirectoryName;

    public static final class Builder {
        private String title;
        private String category;
        private String description;
        private String creationDate;
        private String parentDirectoryName;

        public IssueProperties.Builder title(String title) {
            this.title = title;
            return this;
        }

        public IssueProperties.Builder category(String category) {
            this.category = category;
            return this;
        }

        public IssueProperties.Builder description(String description) {
            this.description = description;
            return this;
        }

        public IssueProperties.Builder creationDate(String creationDate) {
            this.creationDate = creationDate;
            return this;
        }

        public IssueProperties.Builder parentDirectoryName(String parentDirectoryName) {
            this.parentDirectoryName = parentDirectoryName;
            return this;
        }

        public IssueProperties build() {
            if (title.isEmpty())
                throw new IllegalStateException("Title value cannot be empty!");
            if (category.isEmpty())
                throw new IllegalStateException("Category value cannot be empty!");
            if (creationDate.isEmpty())
                throw new IllegalStateException("Creation date value cannot be empty!");
            if (parentDirectoryName.isEmpty())
                throw new IllegalStateException("Parent directory name value cannot be empty!");

            IssueProperties IssueProperties = new IssueProperties();
            IssueProperties.title = this.title;
            IssueProperties.category = this.category;
            IssueProperties.description = this.description;
            IssueProperties.creationDate = this.creationDate;
            IssueProperties.parentDirectoryName = this.parentDirectoryName;

            return IssueProperties;
        }
    }
}
