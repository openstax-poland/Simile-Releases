package webviewselenium.bookScan;

import java.io.File;
import java.io.IOException;
import java.time.LocalDateTime;
import java.util.Arrays;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;

import org.apache.commons.io.FileUtils;
import webviewselenium.constans.SharedConstants;
import webviewselenium.parsers.xml.ContentXmlWriter;

public class FolderManager {

    public static void handleUsedTableOfContentsJsonFile(String pathScanDirectory) throws IOException {
        FileUtils.copyFile(new File(SharedConstants.WORKSPACE_TOC_JSON_PATH), new File(pathScanDirectory + SharedConstants.TOC_FILENAME));
        // TO-DO: Remove file when user leave the Menu.
        //FileUtils.forceDelete(new File(SharedConstants.WORKSPACE_TOC_JSON_PATH));
    }

    public static String createDirectoryThatContainsScans(String bookName, String note, String server) throws ParserConfigurationException, TransformerException {
        File directoryThatContainsScans = new File(SharedConstants.nameOfBookScanDirectory);
        File[] listOfScansDirectories = directoryThatContainsScans.listFiles();
        assert listOfScansDirectories != null;
        int highestDirectoryIndex = Arrays.stream(listOfScansDirectories)
                .filter(File::isDirectory)
                .filter(file -> isNumeric(file.getName()))
                .map(file -> Integer.parseInt(file.getName()))
                .max(Integer::compare).orElse(0);

        highestDirectoryIndex++;

        String path = SharedConstants.nameOfBookScanDirectory + File.separator + highestDirectoryIndex + File.separator + SharedConstants.SCAN_INFO_FILENAME;
		ContentXmlWriter contentXmlWriter = new ContentXmlWriter(path, "ScanInfo", "Book", "Name", bookName);
		contentXmlWriter.appendChildProperty(SharedConstants.SCAN_PROPERTY_TITLE, bookName);
        contentXmlWriter.appendChildProperty(SharedConstants.SCAN_PROPERTY_CREATION_DATE, getCurrentDatetime());
        contentXmlWriter.appendChildProperty(SharedConstants.SCAN_PROPERTY_NOTE, note);
        contentXmlWriter.appendChildProperty(SharedConstants.SCAN_PROPERTY_SERVER, server);
        contentXmlWriter.appendChildProperty(SharedConstants.SCAN_PROPERTY_ESTIMATED_COMPARISON_TIME, "None");
		contentXmlWriter.saveFile();

		return SharedConstants.nameOfBookScanDirectory + File.separator + highestDirectoryIndex + File.separator;
    }

    private static boolean isNumeric(String str) {
        try { Double.parseDouble(str); }
        catch (NumberFormatException e) { return false; }
        return true;
    }

    private static String getCurrentDatetime() {
        return LocalDateTime.now().getSecond() + "." + LocalDateTime.now().getMinute() + "."
                + LocalDateTime.now().getHour() + "." + LocalDateTime.now().getDayOfMonth() + "."
                + LocalDateTime.now().getMonthValue() + "." + LocalDateTime.now().getYear();
    }
}
