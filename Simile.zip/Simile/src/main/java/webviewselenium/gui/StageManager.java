package webviewselenium.gui;

import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
import webviewselenium.constans.ConstantFXMLPaths;

import java.io.File;
import java.io.IOException;
import java.net.URL;

/**
 * Class contains methods that allow to manage Simile's scenes.
 */
public class StageManager {
	private final Stage stage;

	public StageManager() {
		this.stage = null;
	};
	public StageManager(Stage stage) {
		this.stage = stage;
	}

	public void closeCurrentWindow(Button theButton) {
		Stage stage = (Stage) theButton.getScene().getWindow();
        stage.close();
	}

	public void closeCurrentWindow(Stage stage) {
		stage.close();
	}

	public void showStage(String stageFxmlPath) {
		try {
			URL stageUrl = new File(stageFxmlPath).toURI().toURL();
			Parent stageRoot = FXMLLoader.load(stageUrl);
			Stage theStage = new Stage();
			theStage.setScene(new Scene(stageRoot, ConstantFXMLPaths.width, ConstantFXMLPaths.height));
			theStage.setMinWidth(1200);
			theStage.centerOnScreen();
			theStage.toFront();
			theStage.show();
			theStage.setOnCloseRequest(new EventHandler<WindowEvent>() {
				public void handle(WindowEvent we) {
					System.exit(0);
				}
			});
		} catch (IOException ex) {
			ex.printStackTrace();
		}
	}

	public void showMyLibraryMenu() {
		closeCurrentWindow(stage);
		showStage(ConstantFXMLPaths.collectionMenu);
	}

	public void showScanMenu() {
		closeCurrentWindow(stage);
		showStage(ConstantFXMLPaths.scanMenu);
	}

	public void showCompareMenu() {
		closeCurrentWindow(stage);
		showStage(ConstantFXMLPaths.compareMenu);
	}

	public void showGenerateIssueMenu() {
		closeCurrentWindow(stage);
		showStage(ConstantFXMLPaths.generateIssueMenu);
	}

	public void showYourIssuesMenu() {
		closeCurrentWindow(stage);
		showStage(ConstantFXMLPaths.yourIssuesMenu);
	}
}
