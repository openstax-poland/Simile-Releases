package webviewselenium.gui.utilities;

import javafx.scene.text.Text;
import javafx.stage.Stage;
import webviewselenium.gui.ApplicationLoader;
import webviewselenium.gui.StageManager;

public interface ApplicationProperties {

    default void initializeApplicationVersionLabel(Text versionLabel) {
        versionLabel.setText(ApplicationLoader.getCurrentVersion());
    }

    default StageManager initializeStageManager(Text versionLabel) {
        Stage currentSceneWindowStage = (Stage) versionLabel.getScene().getWindow();
        return new StageManager(currentSceneWindowStage);
    }
}
