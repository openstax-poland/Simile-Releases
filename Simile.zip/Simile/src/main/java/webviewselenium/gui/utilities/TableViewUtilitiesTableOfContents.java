package webviewselenium.gui.utilities;

import javafx.scene.control.TableView;
import webviewselenium.bookProperties.tableOfContents.ToCComponentsTypes;
import webviewselenium.bookProperties.tableOfContents.ToCComponentProperties;
import webviewselenium.constans.SharedConstants;

import java.util.List;

/**
 * Class contains methods that allow to add formatted ToC components to the TableView.
 */
public class TableViewUtilitiesTableOfContents extends TableViewUtilities {
    public TableViewUtilitiesTableOfContents(TableView<ToCComponentProperties> tableView) {
        super(tableView);
    }

    public void addComponentsToTableView(List<ToCComponentProperties> components) {
        components.forEach(component -> {
            if(component.getComponentType() == ToCComponentsTypes.chapter) formatComponentAsChapter(component);
            else formatComponentAsModule(component);
            tableView.getItems().add(component);
        });
    }

    private void formatComponentAsChapter(ToCComponentProperties component) {
        component.setComponentTitle(component.getComponentTitle().contains(SharedConstants.EXERCISES_CHAPTER_NAME)
                ? "\t\t" + component.getComponentTitle()
                : "\t" + component.getComponentTitle());
    }

    private void formatComponentAsModule(ToCComponentProperties component) {
        component.setComponentTitle(component.getComponentsParentChapterName().equals(SharedConstants.EXERCISES_CHAPTER_NAME)
                ? "\t\t\t\t" + component.getComponentTitle()
                : "\t\t" + component.getComponentTitle());
    }
}
