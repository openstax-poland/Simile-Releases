package webviewselenium.gui.bookDetailsMenu;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.util.Callback;
import webviewselenium.bookProperties.tableOfContents.ToCComponentProperties;
import webviewselenium.bookProperties.tableOfContents.ToCComponentsTypes;
import webviewselenium.constans.ConstantFXMLPaths;
import webviewselenium.constans.SharedConstants;
import webviewselenium.constans.SimileContext;
import webviewselenium.fileUtilities.ScanDirectoryExporter;
import webviewselenium.gui.StageManager;
import webviewselenium.gui.utilities.ApplicationProperties;
import webviewselenium.gui.utilities.TableViewUtilitiesTableOfContents;
import webviewselenium.parsers.json.TableOfContentsParser;
import webviewselenium.parsers.json.TableOfContentsWriter;
import webviewselenium.parsers.xml.UpdateXmlBookProperties;
import webviewselenium.parsers.xml.UpdateXmlBookPropertiesImpl;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;
import java.util.concurrent.atomic.AtomicReference;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

public class BookDetailsController implements Initializable, ApplicationProperties {
    @FXML private Text versionLabelText;
    @FXML private Text bookTitleText;
    @FXML private TableView<ToCComponentProperties> tableOfContentsTableView;
    @FXML private TableColumn<ToCComponentProperties, String> chapterTableColumn;
    @FXML private TextArea bookSummaryTextArea;
    @FXML private TextArea noteTextField;

    private final String PATH_TO_TOC_FILE = SharedConstants.NAME_OF_DIRECTORY_THAT_CONTAINS_SCANS +
            File.separator + SimileContext.bookDirectoryIndex + File.separator + SharedConstants.TOC_FILENAME;
    private final String BREAK_AND_TAB = "\n\t";
    private final String TWO_NEW_LINES = "\n\n";
    private final String NEW_LINE = "\n";
    private final String TAB = "\t";

    private StageManager stageManager;
    private TableOfContentsParser tableOfContentsParser;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        initializeApplicationVersionLabel(versionLabelText);
        initializeUtilities();
        initializeScanInformationTextFields();
        markScansThatAreAlreadyInDatabase();
    }

    private void initializeScanInformationTextFields() {
        bookTitleText.setText(tableOfContentsParser.getBookTitle());
        noteTextField.setText(BREAK_AND_TAB + SimileContext.bookNote);

        bookSummaryTextArea.setText(
                BREAK_AND_TAB + SharedConstants.FOLDER_SUMMARY_HEADER + SimileContext.bookDirectoryIndex  + TWO_NEW_LINES +
                        TAB + SharedConstants.DATE_SUMMARY_HEADER + SimileContext.bookScanDate + TWO_NEW_LINES +
                        TAB + SharedConstants.SERVER_SUMMARY_HEADER + tableOfContentsParser.getServerName() + NEW_LINE);
    }

    private void initializeUtilities() {
        initializeChapterTableUtilities();
    }

    private void initializeChapterTableUtilities() {
        tableOfContentsParser = new TableOfContentsParser(PATH_TO_TOC_FILE);

        TableViewUtilitiesTableOfContents tableViewUtilitiesTableOfContents = new TableViewUtilitiesTableOfContents(tableOfContentsTableView);
        tableViewUtilitiesTableOfContents.setSelectionModeToMultiple();
        tableViewUtilitiesTableOfContents.addComponentsToTableView(tableOfContentsParser.getParsedComponents());
        parseComponentsTitlesIntoColumn();
    }

    private void parseComponentsTitlesIntoColumn() {
        chapterTableColumn.setCellValueFactory(new PropertyValueFactory<>(SharedConstants.nameOfVariableThatConstitutesColumn));
    }

    @FXML
    void goToMyLibraryMenu() {
        initializeStageManager();
        stageManager.showMyLibraryMenu();
    }

    @FXML
    void goToCompareMenu() {
        initializeStageManager();
        stageManager.showCompareMenu();
    }

    @FXML
    void goToGenerateIssueMenu() {
        initializeStageManager();
        stageManager.showGenerateIssueMenu();
    }

    @FXML
    void goToScanMenu() {
        initializeStageManager();
        stageManager.showScanMenu();
    }

    private void initializeStageManager() {
        if(stageManager == null) stageManager = initializeStageManager(versionLabelText);
    }

    private void markScansThatAreAlreadyInDatabase() {
        Callback<TableColumn<ToCComponentProperties, String>, TableCell<ToCComponentProperties, String>>
                chapterCellFactory = TextFieldTableCell.forTableColumn();
        File[] allFilesInDatabaseDirectory = new File(SharedConstants.NAME_OF_DIRECTORY_THAT_CONTAINS_SCANS +
                File.separator + SimileContext.bookDirectoryIndex).listFiles();
        List<String> scansNames = Arrays.stream(allFilesInDatabaseDirectory).map(scan -> scan.getName()).collect(Collectors.toList());
        AtomicReference<String> realIndex = new AtomicReference<>("");
        chapterTableColumn.setCellFactory(chapterTableColumn -> {
            TableCell<ToCComponentProperties, String> tableCell = chapterCellFactory.call(chapterTableColumn);
            tableCell.itemProperty().addListener((obs, oldValue, newValue) -> {
                TableRow currentRow = tableCell.getTableRow();
                if (currentRow != null) {
                    int index = currentRow.getIndex();
                    if(index >= 0) {
                        ToCComponentProperties toCComponentProperties = (ToCComponentProperties) currentRow.getTableView().getItems().get(index);

                        String parentIndex = toCComponentProperties.getComponentsParentChapterName().split(" ")[0];
                        if(parentIndex.matches("^(\\d+)")) {
                            realIndex.set(parentIndex);
                        }
                        String[] words = toCComponentProperties.getComponentTitle().toLowerCase().trim().split(" ");
                        String word = Arrays.stream(words).collect(Collectors.joining("-"));
                        word = word.replaceAll("\\.", "-");
                        word = word.replaceAll(",", "");
                        word = word.replaceAll("\\?", "");
                        word = word.replaceAll(":", "");
                        word = word.replaceAll(";", "");
                        word = word.replaceAll("#", "");
                        word = word.replaceAll("\\(", "");
                        word = word.replaceAll("\\)", "");
                        word = word.replaceAll("–", "-");
                        word = word.replaceAll("’", "");
                        tableCell.setStyle("-fx-text-fill: #8a8a8a;");

                        StringBuilder output = new StringBuilder("");
                        if(word.matches("^(\\d+).+")) {
                            output.append(word);
                        } else if(realIndex.get().isEmpty()) {
                            output.append(word);
                        } else if(word.contains("|")) {
                            String x = word.substring(word.lastIndexOf("|")+2);
                            output.append(x);
                        } else if(word.contains("chapter-")) {
                            Pattern p = Pattern.compile("chapter-\\d+");
                            Matcher m = p.matcher(word);
                            m.find();
                            output.append(m.group());
                        } else if(word.endsWith("index")) {
                            output.append("index");
                        } else if(word.endsWith("references")) {
                            output.append("references");
                        } else {
                            output.append(realIndex+"-"+word);
                        }

                        if (scansNames.stream().anyMatch(scan -> scan.toLowerCase().contains(output.toString().toLowerCase()))) {
                            tableCell.setStyle("-fx-text-fill: #440045;");
                        }
                    }
                }
            });
            return tableCell;
        });
    }



    @FXML
    void deleteSelectedComponents() {
        if (showScanConfirmationAlert("Delete Modules from Your Library.").get() == ButtonType.OK) {
            List<String> chaptersUrls = chapterTableColumn.getTableView().getSelectionModel().getSelectedItems().stream()
                    .map(toCComponentProperties -> toCComponentProperties.getComponentUrl().substring(toCComponentProperties.getComponentUrl().lastIndexOf("pages/")).replaceAll("/", "+"))
                    .collect(Collectors.toList());

            chaptersUrls.forEach(e -> System.out.println(e));

            List<File> allScanFiles = Arrays.stream(new File("ScanDB/" + SimileContext.bookDirectoryIndex).listFiles())
                    .collect(Collectors.toList());

            allScanFiles.forEach(scanFile -> {
                for(int i = 0; i < chaptersUrls.size(); i++) {
                    if(scanFile.getName().contains(chaptersUrls.get(i))) {
                        System.out.println(chaptersUrls.get(i));
                        try {
                            Files.delete(Paths.get(scanFile.getPath()));
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }
            });
            markScansThatAreAlreadyInDatabase();
        }
    }

    @FXML
    void discardNoteChanges() {
        noteTextField.setText("\n\t" + SimileContext.bookNote);
    }

    @FXML
    void exportBookToLocalDrive() throws IOException {
        ScanDirectoryExporter scanDirectoryExporter = new ScanDirectoryExporter((Stage) versionLabelText.getScene().getWindow());
        scanDirectoryExporter.handleScanExport();
    }

    @FXML
    void saveNoteChanges() {
        String newNoteContent = noteTextField.getText().trim();
        UpdateXmlBookProperties updateXmlBookProperties = new UpdateXmlBookPropertiesImpl();
        updateXmlBookProperties.updateNoteContent(
                "ScanDB/" + SimileContext.bookDirectoryIndex + "/info.xml",
                tableOfContentsParser.getBookTitle(),
                newNoteContent);
    }

    @FXML
    void scanSelectedComponents() throws IOException {
        if (showScanConfirmationAlert("Scan Modules to Your Library.").get() == ButtonType.OK) {
            TableOfContentsWriter tableOfContentsWriter = new TableOfContentsWriter();
            tableOfContentsWriter.createCustomScanTableOfContentsJson(
                    SharedConstants.WORKSPACE_CUSTOM_TOC_JSON_PATH,
                    tableOfContentsParser.getBookTitle(),
                    tableOfContentsTableView.getItems().stream().collect(Collectors.toList()),
                    new ArrayList<>(tableOfContentsTableView.getSelectionModel().getSelectedCells()));
            SimileContext.pathParameter = ".." + File.separator + SharedConstants.NAME_OF_DIRECTORY_THAT_CONTAINS_SCANS + File.separator + SimileContext.bookDirectoryIndex;
            SimileContext.scanFromTocParameter = ".." + File.separator + SharedConstants.WORKSPACE_CUSTOM_TOC_JSON_PATH;
            SimileContext.listOfAllSelectedChaptersToScan = "\n" +
                    chapterTableColumn.getTableView().getSelectionModel().getSelectedItems().stream()
                    .map(toCComponentProperties -> toCComponentProperties.getComponentTitle())
                    .collect(Collectors.joining("\n"));

            initializeStageManager();
            stageManager.showStage(ConstantFXMLPaths.bookDetailsScanMenu);
        }
    }

    private Optional<ButtonType> showScanConfirmationAlert(String headerText) {
        Alert scanConfirmationAlert = new Alert(Alert.AlertType.CONFIRMATION);
        scanConfirmationAlert.setHeaderText(headerText);

        String selectedChapters = chapterTableColumn.getTableView().getSelectionModel().getSelectedItems().stream()
                .map(toCComponentProperties -> toCComponentProperties.getComponentTitle())
                .collect(Collectors.joining("\n"));

        scanConfirmationAlert.setContentText(selectedChapters);
        return scanConfirmationAlert.showAndWait();
    }

    @FXML
    void tocTableViewContentClicked() {
        List<Integer> childIndexes = new ArrayList<>();

        int focusedCellIndex = tableOfContentsTableView.getFocusModel().getFocusedIndex();
        if(tableOfContentsTableView.getItems().get(focusedCellIndex).getComponentType() == ToCComponentsTypes.chapter) {
            String chapterNumber = findChapterNumber(tableOfContentsTableView.getItems().get(focusedCellIndex).getComponentTitle().trim());

            for(int i = 0; i < tableOfContentsTableView.getItems().size(); i++) {
                String actualChaptersUrl = tableOfContentsTableView.getItems().get(i).getComponentUrl();
                if(actualChaptersUrl.contains("pages/" + chapterNumber + "-"))
                    childIndexes.add(i);
            }
        }
        childIndexes.forEach(childIndex -> tableOfContentsTableView.getSelectionModel().select(childIndex));
    }

    private String findChapterNumber(String chapterName) {
        Pattern pattern = Pattern.compile("^\\d+");
        Matcher matcher = pattern.matcher(chapterName);
        return matcher.find() ? matcher.group() : "";
    }
}
