package webviewselenium.constans;

import webviewselenium.bookProperties.BookProperties;

public class SimileContext {
    public static final String OS_NAME = System.getProperty("os.name");

    public static String bookTitle = "";
    public static String bookDirectoryIndex = "1";
    public static String bookNote = " ";
    public static String bookScanDate = " ";
    public static String pathParameter = " ";
    public static String scanFromTocParameter = " ";
    public static String listOfAllSelectedChaptersToScan = " ";
    public static String pathToReportDirectory;
    public static BookProperties qaBookProperties;
    public static BookProperties referenceBookProperties;

    public static boolean doesUserUseMacOS() {
        return SimileContext.OS_NAME.contains("Mac");
    }

}
