package webviewselenium.parsers.xml;

import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import webviewselenium.constans.SharedConstants;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.File;

public class ContentXmlWriter {
    private final Document document;
    private final String path;
    private final Element parentPropertyElement;

    public ContentXmlWriter(String path, String rootElementName, String parentPropertyName, String parentAttributeName, String parentAttributeValue) throws ParserConfigurationException {
        this.path = path;
        createScanDirectory();

        DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
        document = documentBuilder.newDocument();

        Element rootElement = document.createElement(rootElementName);
        document.appendChild(rootElement);

        parentPropertyElement = document.createElement(parentPropertyName);
        rootElement.appendChild(parentPropertyElement);
        Attr parentAttr = document.createAttribute(parentAttributeName);
        parentAttr.setValue(parentAttributeValue);
        parentPropertyElement.setAttributeNode(parentAttr);
    }

    public void appendChildProperty(String propertyName, Object propertyValue) {
        Element childProperty = document.createElement(propertyName);
        childProperty.appendChild(document.createTextNode(propertyValue.toString()));
        parentPropertyElement.appendChild(childProperty);
    }

    public void saveFile() throws TransformerException {
        TransformerFactory transformerFactory = TransformerFactory.newInstance();
        Transformer transformer = transformerFactory.newTransformer();
        DOMSource source = new DOMSource(document);

        StreamResult result = new StreamResult(new File(path));
        transformer.transform(source, result);
    }

    private void createScanDirectory() {
        String directoryIndex = path.replaceAll("\\D+", "");
        new File(SharedConstants.nameOfBookScanDirectory + File.separator + directoryIndex).mkdirs();
    }
}
