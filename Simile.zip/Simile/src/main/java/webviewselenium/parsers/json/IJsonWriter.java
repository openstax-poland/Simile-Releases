package webviewselenium.parsers.json;

import org.apache.log4j.Logger;
import org.json.JSONObject;
import webviewselenium.gui.ApplicationLoader;

import java.io.FileWriter;
import java.io.IOException;

public interface IJsonWriter {
    Logger LOGGER = ApplicationLoader.getLogger();

    /**
     * Creates new JSON file based on the provided JSON object instance.
     *
     * @param path path to the file that is created
     * @param jsonObject json object which is the base for the created JSON file
     * @throws IOException if it isn't possible to write to the file/close the file
     */
    default void writeToFile(String path, JSONObject jsonObject) throws IOException {
        FileWriter jsonToC = new FileWriter(path);
        jsonToC.write(jsonObject.toString());
        jsonToC.close();
    }
}
