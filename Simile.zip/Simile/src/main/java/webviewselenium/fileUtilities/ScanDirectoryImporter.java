package webviewselenium.fileUtilities;

import org.apache.commons.io.FileUtils;
import webviewselenium.bookScan.cnxBookScanner.CnxBookScanner;
import webviewselenium.constans.ConstantMessages;
import webviewselenium.constans.SharedConstants;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * Class contains methods that allow to import scanned book by the user to the local Collection.
 * So far Simile supports only one importing way - via directories that stores scan information and table of contents files
 */
public class ScanDirectoryImporter implements ScanDirectoryTrader {


    /**
     * Allows to import file from any directory to the local database
     *
     * @param inputPath path to the directory that should be imported
     * @param outputPath path to the directory in the destination database directory
     * @return full path to the directory that is created during importing process
     * @throws IOException if it isn't possible to find/handle copying file
     */
    public String handleScanImport(File inputPath, String outputPath) throws IOException, InterruptedException {
        return importScanDirectory(inputPath, outputPath);
    }

    private String importScanDirectory(File importScanDirectory, String outputPath) throws IOException, InterruptedException {
        File importedToScanDB = new File(outputPath + findPossibleScanDirectoryIndex(importScanDirectory.getName(), outputPath));

       if(containsRequiredInfoFiles(importScanDirectory)) {
            FileUtils.copyDirectory(importScanDirectory, importedToScanDB);
            return importedToScanDB.getPath();
        } else {
            tryToPrepareImportedDirectoryThatHasOldPattern(importScanDirectory);
            FileUtils.copyDirectory(importScanDirectory, importedToScanDB);
       }
        return ConstantMessages.INVALID_SOURCE_DIRECTORY;
    }

    private boolean containsRequiredInfoFiles(File importFile) {
        return Arrays.stream(Objects.requireNonNull(importFile.listFiles())).anyMatch(file -> file.getName().equals(SharedConstants.SCAN_INFO_FILENAME)) &&
                Arrays.stream(Objects.requireNonNull(importFile.listFiles())).anyMatch(file -> file.getName().equals(SharedConstants.TOC_FILENAME));
    }

    /**
     * All below elements can be deleted if support for the old naming pattern will not be necessary anymore.
     *
     * @param importScanDirectory
     * @throws IOException
     * @throws InterruptedException
     */
    private void tryToPrepareImportedDirectoryThatHasOldPattern(File importScanDirectory) throws IOException, InterruptedException {
        String firstFoundScanFileName = findFirstScanFileName(importScanDirectory);
        firstFoundScanFileName = convertScanFileNameToUrl(firstFoundScanFileName);

        adjustAllScanFilesToCorrectNamePattern(importScanDirectory);
        adjustInfoXmlFileToNewFormat(importScanDirectory);
        removeOldToCFile(importScanDirectory);

        CnxBookScanner cnxBookScanner = prepareCnxBookScannerToCreateToC(firstFoundScanFileName, importScanDirectory.getPath());
        cnxBookScanner.runCommand();
    }

    private String findFirstScanFileName(File scanDirectory) {
        List<File> allFilesInScanDirectory = Arrays.stream(scanDirectory.listFiles()).collect(Collectors.toList());
        String firstFoundScanFileName = allFilesInScanDirectory.stream()
                .filter(file -> file.getName().contains(SharedConstants.PNG_EXTENSION))
                .findFirst()
                .get().getName();

        return firstFoundScanFileName;
    }

    private String convertScanFileNameToUrl(String scanFileName) {
        String bookUrl = scanFileName.substring(0, scanFileName.lastIndexOf("_1.png"));
        bookUrl = bookUrl.replaceAll("_", ":");
        bookUrl = bookUrl.replaceAll("\\+", "/");

        return bookUrl;
    }

    private void adjustAllScanFilesToCorrectNamePattern(File importScanDirectory) {
        final String OLD_PATTERN_IMAGE_SUFFIX = "_1";
        List<File> allFilesInScanDirectory = Arrays.stream(importScanDirectory.listFiles()).collect(Collectors.toList());
        List<File> allImageFiles = allFilesInScanDirectory.stream()
                .filter(file -> file.getName().contains(SharedConstants.PNG_EXTENSION))
                .collect(Collectors.toList());

        allImageFiles.forEach(imageFile -> {
            imageFile.renameTo(new File(imageFile.getPath().replace(OLD_PATTERN_IMAGE_SUFFIX, "")));
        });
    }

    private void adjustInfoXmlFileToNewFormat(File importScanDirectory) throws IOException {
        String content = FileUtils.readFileToString(new File(importScanDirectory.getPath() + File.separator + SharedConstants.SCAN_INFO_FILENAME));
        content = content.replaceAll("https://", "");
        content = content.replaceAll("/</Server>", "</Server>");
        content = content.replaceAll("Date", "Creation-Date");
        content = content.replaceAll("Commit", "Note");
        content = content.replaceAll("AverageTime", "Estimated-Comparison-Time");
        content = content.replaceAll("<ID>.+</ID>", "");
        content = content.replaceAll("<Path>.+</Path>", "");
        content = content.replaceAll("<Pages>.+</Pages>", "");
        content = content.replaceAll("<Branch/>", "");

        BufferedWriter writer = new BufferedWriter(new FileWriter(importScanDirectory.getPath() + "/info.xml"));
        writer.write(content);
        writer.close();
    }

    private void removeOldToCFile(File importScanDirectory) throws IOException {
        File oldToCFile = new File(importScanDirectory.getPath() + File.separator + SharedConstants.fullNameOfFileThatStoresToC);
        if(oldToCFile.exists()) {
            Files.delete(Paths.get(oldToCFile.getPath()));
        }
    }

    private CnxBookScanner prepareCnxBookScannerToCreateToC(String bookUrl, String outputPath) {
        CnxBookScanner cnxBookScanner = new CnxBookScanner();
        cnxBookScanner.addScanFromUrlParameter(bookUrl);
        cnxBookScanner.addPathParameter(outputPath);
        cnxBookScanner.addOnlyToCParameter();

        return cnxBookScanner;
    }
}
