package webviewselenium.fileUtilities;

import javafx.stage.DirectoryChooser;
import javafx.stage.Stage;
import org.apache.commons.io.FileUtils;
import webviewselenium.constans.SharedConstants;
import webviewselenium.constans.SimileContext;

import java.io.File;
import java.io.IOException;

public class ScanDirectoryExporter implements ScanDirectoryTrader {
    private final DirectoryChooser  directoryChooser;
    private final Stage importButtonStage;

    public ScanDirectoryExporter(Stage importButtonStageProperty) {
        this.directoryChooser = new DirectoryChooser();
        this.importButtonStage = importButtonStageProperty;
    }

    public String handleScanExport() throws IOException {
        return exportScanDirectory(SimileContext.bookDirectoryIndex);
    }

    private String exportScanDirectory(String scanDirectoryIndex) throws IOException {
        String sourceScanDirectoryPath = SharedConstants.NAME_OF_DIRECTORY_THAT_CONTAINS_SCANS +
                File.separator + scanDirectoryIndex;
        String outputScanDirectoryPath = runDirectoryChooserToSelectDirectory();

        String sourceScanDirectoryIndex = getScanDirectoryIndex(sourceScanDirectoryPath);
        String possibleOutputScanDirectoryIndex = findPossibleScanDirectoryIndex(sourceScanDirectoryIndex,
                outputScanDirectoryPath + File.separator).toString();

        File sourceDirectory = new File(sourceScanDirectoryPath);
        File outputDirectory = new File(outputScanDirectoryPath +
                File.separator + possibleOutputScanDirectoryIndex);
        FileUtils.copyDirectory(sourceDirectory, outputDirectory);

        return possibleOutputScanDirectoryIndex;
    }

    private String runDirectoryChooserToSelectDirectory() {
        return directoryChooser.showDialog(importButtonStage).getPath();
    }

    private String getScanDirectoryIndex(String path) {
        return path.substring(path.lastIndexOf(File.separator) + 1);
    }
}
