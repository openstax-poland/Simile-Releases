package webviewselenium.fileUtilities;

import java.io.File;

public interface ScanDirectoryTrader {

    default Integer findPossibleScanDirectoryIndex(String currentIndex, String outputPath) {
        int parsedIndex = parseIndex(currentIndex);

        if(new File(outputPath + parsedIndex).exists()) {
            return findPossibleScanDirectoryIndex(Integer.toString(++parsedIndex), outputPath);
        }
        return parsedIndex;
    }

    default int parseIndex(String index) {
        try {
            return Integer.parseInt(index);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return 1;
    }
}
