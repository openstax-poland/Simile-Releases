package webviewselenium.fileUtilities;

import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import webviewselenium.bookProperties.ScanProperties;
import webviewselenium.constans.SharedConstants;
import webviewselenium.parsers.xml.ContentXmlReader;

import java.io.File;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Class contains methods that allow to find scans and theirs properties in the main scan directory (ScanDB).
 * Raw data that provides properties is in the XML format.
 */
public class ScanDirectoryFinder {
    /**
     * Allows to get all Scans' Properties that are compliant with Simile's information files.
     *
     * @param scanDatabasePath path to the directory that stores scans directories
     * @return scan properties from all directories in the required directory
     */
    public List<ScanProperties> getAllScansProperties(String scanDatabasePath) {
        return findScanDirectoriesInScanDB(scanDatabasePath).stream().map(this::findScanProperties).collect(Collectors.toList());
    }

    /**
     * Allows to find all directories that are compliant with Simile's scan directories pattern.
     *
     * @param scanDatabasePath path to the directory that stores scans directories
     * @return all directories that are compliant with Simile's scans directories pattern
     */
    private List<File> findScanDirectoriesInScanDB(String scanDatabasePath) {
        File scansDirectory = new File(scanDatabasePath);

        return Arrays.stream(Objects.requireNonNull(scansDirectory.listFiles()))
                .filter(scanDirectory -> scanDirectory.getName().matches("\\d+"))
                .collect(Collectors.toList());
    }

    /**
     * Allows to find all scan properties from the requested scan directory
     *
     * @param scanDirectoryPath path to the directory that stores scan's information
     * @return all scan properties from the requested scan directory
     */
    public ScanProperties findScanProperties(File scanDirectoryPath) {
        ContentXmlReader contentXmlReader = new ContentXmlReader(
                scanDirectoryPath + File.separator + SharedConstants.SCAN_INFO_FILENAME,
                SharedConstants.SCAN_NODE_NAME);

        NodeList nodeList = contentXmlReader.readXmlContent();

        for(int nodeIndex = 0; nodeIndex < nodeList.getLength(); nodeIndex++) {
            Node theNode = nodeList.item(nodeIndex);

            if (theNode.getNodeType() == Node.ELEMENT_NODE) {
                Element theElement = (Element) theNode;

                return new ScanProperties(
                        theElement.getElementsByTagName(SharedConstants.SCAN_PROPERTY_TITLE).item(0).getTextContent(),
                        theElement.getElementsByTagName(SharedConstants.SCAN_PROPERTY_CREATION_DATE).item(0).getTextContent(),
                        theElement.getElementsByTagName(SharedConstants.SCAN_PROPERTY_NOTE).item(0).getTextContent(),
                        theElement.getElementsByTagName(SharedConstants.SCAN_PROPERTY_SERVER).item(0).getTextContent(),
                        theElement.getElementsByTagName(SharedConstants.SCAN_PROPERTY_ESTIMATED_COMPARISON_TIME).item(0).getTextContent(),
                        scanDirectoryPath.getName()
                );
            }
        }
        return new ScanProperties();
    }
}
