#!/bin/bash
update_system_command="sudo apt update"
current_path="$(cd "$(dirname "$0")"; pwd -P)"
cd $current_path
echo "$current_path"

curl_nodejs="curl -sL https://deb.nodesource.com/setup_10.x | sudo -E bash -"
install_nodejs="sudo apt install nodejs"

curl_yarn="curl -sS https://dl.yarnpkg.com/debian/pubkey.gpg | sudo apt-key add -"
echo_yarn="echo \"deb https://dl.yarnpkg.com/debian/ stable main\" | sudo tee /etc/apt/sources.list.d/yarn.list"
install_yarn="sudo apt update && sudo apt install yarn"

install_python="sudo apt-get install python3-pip"
install_pip="sudo python3 -m pip install -U pip"
install_setuptools="sudo python3 -m pip install -U setuptools"
install_opencv="sudo pip3 install opencv-python"

exec $update_system_command & wait

exec $curl_nodejs & wait
exec $install_nodejs & wait

exec $curl_yarn & wait
exec $echo_yarn & wait
exec $install_yarn & wait

exec $install_python & wait
exec $install_pip & wait
exec $install_setuptools & wait
exec $install_opencv & wait

cd ../cnx-books-scanner
yarn_node_modules="yarn"
exec $yarn_node_modules & wait
yarn_build="yarn build"
exec $yarn_build & wait
