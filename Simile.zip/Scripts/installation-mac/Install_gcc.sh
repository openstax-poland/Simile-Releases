#!/bin/bash
install_xcode="xcode-select --install"
exec $install_xcode
install_gcc="brew install gcc"
exec $install_gcc