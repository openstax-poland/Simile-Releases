#!/bin/bash
install_opencv="pip3 install opencv-python"
exec $install_opencv