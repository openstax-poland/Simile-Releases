#!/bin/bash
install_yarn_and_node="brew install yarn"
exec $install_yarn_and_node