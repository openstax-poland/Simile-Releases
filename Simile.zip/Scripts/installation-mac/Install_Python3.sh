#!/bin/bash
install_python="brew install python3"
exec $install_python