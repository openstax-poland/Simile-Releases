#!/bin/bash
install_protocools="brew install proctools"
exec $install_protocools