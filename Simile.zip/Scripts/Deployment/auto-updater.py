"""
Script starts update and installation process for the latest Simile version.
"""
from sys import platform
from zipfile import ZipFile 
import os

def update_local_release_id():
    github_relaseid_request = 'curl -s \'https://api.github.com/repos/openstax-poland/Simile-Releases/releases/latest\' | jq -r \'.id\''
    github_releaseid = os.popen(github_relaseid_request).read()

    local_releaseid_file_path = 'release-id.txt'#Scripts/Deployment/
    local_releaseid_file = open(local_releaseid_file_path, 'w')
    local_releaseid_file.write(github_releaseid)
    local_releaseid_file.close()

def find_os_name():
    if platform == 'linux' or platform == 'linux2':
        return 'linux'
    elif platform == 'darwin':
        return 'osx'

def download_latest_version():
    github_relaseid_request = 'curl https://github.com/openstax-poland/Simile-Releases/archive/master.zip -O -J -L'
    github_releaseid = os.system(github_relaseid_request)

def unzip_release_package():
    master_release_zip = 'Simile-Releases-master.zip'
    with ZipFile(master_release_zip, 'r') as zip: 
        zip.extractall('../../../Simile')
    
    #simile_zip = 'Simile.zip'
    #with ZipFile(simile_zip, 'r') as zip: 
    #    zip.extractall('../..') 

update_local_release_id()
user_os_name = find_os_name()
#download_latest_version()
unzip_release_package()
