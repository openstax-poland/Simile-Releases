"""
Script verifies if the ReleaseID from GitHub is equal to the ReleaseID of the currently installed version.
"""
import os

def is_the_local_release_id_equal_to_the_latest_one():
    github_relaseid_request = 'curl -s \'https://api.github.com/repos/openstax-poland/Simile-Releases/releases/latest\' | jq -r \'.id\''
    github_releaseid = os.popen(github_relaseid_request).read()

    local_releaseid_file_path = 'release-tag.txt'
    local_releaseid_file = open(local_releaseid_file_path, 'r')
    local_releaseid = local_releaseid_file.readline()
    local_releaseid_file.close()

    return github_releaseid == local_releaseid

def is_newer_version_available():
    is_newer_version_available_checks_result = not is_the_local_release_id_equal_to_the_latest_one()
    return is_newer_version_available_checks_result


# It is necessary to print function's result, because Simile uses result from the console in its calculations.
print(is_newer_version_available())