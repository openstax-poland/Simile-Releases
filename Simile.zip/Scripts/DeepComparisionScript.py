from utils.image_diff import ImageDiff
import sys, cv2

img1 = cv2.imread(sys.argv[1])
img2 = cv2.imread(sys.argv[2])

if(img1.shape[0] < 25000 and img2.shape[0] < 25000):
    if sys.argv[4] == '1.0':
        img = ImageDiff(hash_score=0.99)
    else:
        img = ImageDiff(hash_score=float(sys.argv[4]))
    img.increment_diff(sys.argv[1], sys.argv[2], sys.argv[3])
else:
    print('Mentioned scanned pages are too long, Simile cannot handle them. Skipping this step...')
