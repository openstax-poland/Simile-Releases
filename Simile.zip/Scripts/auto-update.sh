#!/bin/bash
result="$(curl -s 'https://api.github.com/repos/openstax-poland/Simile-Releases/releases/latest' | jq -r '.id')"

input="release-tag.txt"
line=$(head -n 1 $input)

echo $result > $input
unzip -j -o Simile-Releases-master.zip
unzip -o Simile.zip
curl https://github.com/openstax-poland/Simile-Releases/archive/master.zip -O -J -L

./Scripts/Install_Simile_Linux.sh
