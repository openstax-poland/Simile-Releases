import os

scandb_name = "../ScanDB"

def fast_scandir(dirname):
    subfolders= [f.path for f in os.scandir(dirname) if f.is_dir()]
    for dirname in list(subfolders):
        subfolders.extend(fast_scandir(dirname))
    return subfolders

def replace_old_name(scan_path):
    if '.png' in scan_path:
        os.rename(scan_path, scan_path.replace('_1', ''))

directories = fast_scandir(scandb_name)
for directory in directories:
    scan_directories = os.listdir(directory)
    for scan_path in scan_directories:
        replace_old_name(f'''{directory}/{scan_path}''')