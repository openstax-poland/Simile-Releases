from utils.image_similar import HashSimilar
import numpy as np
import sys, cv2

# Function allows to calculate differences between images:
#   1. ResultImage - image that was created during Comaprison Process in Simile.
#   2. ReferenceImage - image that is the template of created ResultImage.
# Function returns similarity value of provided images, e.g. 0 means those images are exactly the same.
def calculateDifference(pathResultImage, pathReferenceImage):
    resultImage = cv2.imread(pathResultImage)
    #resultImage = cv2.cvtColor(resultImage, cv2.COLOR_BGR2GRAY)
    resultImage_height = resultImage.shape[0]
    resultImage_width = resultImage.shape[1]

    refeferenceImage = cv2.imread(pathReferenceImage)
    refeferenceImage_height = refeferenceImage.shape[0]
    refeferenceImage_width = refeferenceImage.shape[1]

    number_of_not_blank_pixels = 0
    for y in range(0, refeferenceImage_height):
        if number_of_not_blank_pixels == 1:
            break
        for x in range(0, refeferenceImage_width):
            r = np.array([255, 255, 255])
            if refeferenceImage[y, x][2] != r[2] and refeferenceImage[y, x][1] != r[1] and refeferenceImage[y, x][0] != r[0]:
                number_of_not_blank_pixels += 1
                break

    if number_of_not_blank_pixels == 0:
        return 0

    number_of_not_blank_pixels = 0
    for y in range(0, resultImage_height):
        if number_of_not_blank_pixels == 1:
            break
        for x in range(0, resultImage_width):
            r = np.array([255, 255, 255])
            if resultImage[y, x][2] != r[2] and resultImage[y, x][1] != r[1] and resultImage[y, x][0] != r[0]:
                number_of_not_blank_pixels += 1
                break

    if number_of_not_blank_pixels == 0:
        return 0

    cnt = 0
    for y in range(0, resultImage_height):
        for x in range(0, resultImage_width):
            r = np.array([100, 100, 225])
            if resultImage[y, x][2] == r[2] and resultImage[y, x][1] == r[1] and resultImage[y, x][0] == r[0]:
                return 1
    
    return cnt

# It is necessary to print function's result, because Simile uses result from the console in its calculations.
print(calculateDifference(sys.argv[1], sys.argv[2]))
