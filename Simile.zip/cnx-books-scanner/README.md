### Description

CNX Book Scanner is a tool for creating screenshots (scans) from online modules for books created by the OpenStax foundation. We are supporting creating scans from domains like openstax.org, cnx.org, and herokuapp.com (which is used for development purposes only). The scanner is using a headless browser (puppeteer) in order to open, navigate, and make screenshots.

### Instalation

In order to install this tool, you have to run `yarn` and `yarn build`

### Usage

Assuming that there is `./scans/astronomy/` directory created, a simple usage will be `yarn start --scan-from-url https://staging.openstax.org/books/astronomy/pages/1-introduction --path ./scans/astronomy/`. This command will first create a `toc.json` file with and then start creating screenshots for every module in the book. Output files will be saved into `./scans/astronomy/` directory.

##### Allowed parameters

- `--scan-from-url`: String (required) - takes an URL to any of the modules in the book. If you didn't add any other argument it will start scanning the whole book.
- `--scan-from-toc`: String (optional) - takes a path to the `toc.json` file and scans only these modules which are in this file (you can, for example, remove some of them in order to scan only selected ones).
- `--only-toc`: Boolean (optional) - this argument may be passed only with - `--scan-from-url` and will exit a script after creating `toc.json` file.
- `--path`: String (optional) - takes a path for the output files. The directory has to exists.
- `--filename`: String (optional) - takes a template string which will be used for creating filenames for the screenshots. You can use these fragments: `<bookTitle>`, `<chapterTitle>`, `<moduleTitle>`, `<url>`, `<domain>`. Default: `<url>`
- `--open-tabs-limit`: Number (optional) - determines how many browser tabs can be open at the same time (it will make screenshots in parallel). Default: `5`
- `--width` and `--height`: Number (optional) - determines a size of a window in pixels for headless browser. Default: 1920px x 1080px
- `--logger`: String (optional) - determines which logs during the scanning process will show up in the console. Allowed values: `development` which displays all logs and `production` which display only necessary logs. Default: `development`