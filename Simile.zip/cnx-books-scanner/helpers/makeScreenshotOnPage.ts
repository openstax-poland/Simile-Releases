import { Page } from 'puppeteer'
import defaultCookies from '../config/cookies'
import parseUrl, { cleanUrl, Logger } from './utils'

const makeScreenshotOnPage = async (
  page: Page,
  url: string,
  outputPath: string,
  filename: string,
  bookTitle: string,
  chapterTitle: string,
  moduleTitle: string,
  logger: Logger,
) => {
  const { createFileName, domain, mainContentSelector, isCnxOrg, isRex } = parseUrl(url);

  logger('Setting default cookies...', 'log')
  await page.setCookie(...defaultCookies.map(c => ({ domain: domain.replace('https://', ''), ...c })))

  logger(`Opening ${url}`, 'info')
  await page.goto(url, { waitUntil: 'networkidle0', timeout: 0 })

  logger('hiding top bars, moving content above popups...', 'log')
  await page.evaluate((mainContentSelector, isRex, isCnxOrg) => {
    // Selector for elements to hide for openstax.org
    let selectorsForElementsToHide = '[class^=BookBanner__BarWrapper], [class^=styled__BarWrapper], [data-analytics-region="signup CTA"]'

    // Selector for elements to hide for cnx.org
    if (isCnxOrg) {
      selectorsForElementsToHide = '.pinnable, .media-header'

      // cnx.org is adding margin-top to then #main-content when scrolled down.
      // We want to disable it since it's affecting screenshots.
      window.addEventListener('scroll', function (event) {
        event.stopPropagation()
      }, true)
    }

    // Hide elements
    Array.from(document.querySelectorAll(selectorsForElementsToHide))
      .forEach(el => (el as HTMLElement).style.display = 'none')

    // Open all Show Solution sections
    const buttons = document.querySelectorAll('[data-type="solution"] button') as NodeListOf<HTMLButtonElement>
    buttons.forEach(btn => btn.click())

    if (isRex) {
      // Moving content above all other elements so popup are not visible
      const content = document.querySelector(mainContentSelector) as HTMLElement
      if (content) {
        content.style.position = 'relative'
        content.style.zIndex = '9999999999'
        content.style.background = '#ffffff'
      }
    }
  }, mainContentSelector, isRex, isCnxOrg)

  logger('Obtaining content element...', 'log')
  const content = await page.waitForSelector(mainContentSelector)
  if (!content) {
    console.error(`Error: Couldn't find main content selector: "${mainContentSelector}" in the page.`)
    return
  }

  logger('Taking screenshot...', 'info')
  const name = createFileName(
    filename,
    {
      bookTitle,
      chapterTitle,
      domain,
      format: 'png',
      moduleTitle,
      url,
    }
  )
  await content.screenshot({
    type: 'png',
    path: cleanUrl(`${outputPath}/${name}`)
  })
}

export default makeScreenshotOnPage
