import fs from 'fs'
import { Page } from 'puppeteer'
import parseUrl, { Logger } from './utils'
import { Chapter, Module, Toc, Section } from './interfaces'

const scanAndSaveToc = async (page: Page, url: string, outputPath: string, logger: Logger,): Promise<Toc> => {
  const {
    baseUrlForBook,
    bookTitleSelector,
    tocSelector,
    isRex,
  } = parseUrl(url)

  logger(`Opening ${url}`, 'info')
  await page.goto(url, { waitUntil: 'networkidle0', timeout: 0 })

  const sections = await page.evaluate((tocSelector, isRex, baseUrlForBook) => {
    const getSections = (el: Element, isRex: boolean): Section[] | undefined => {
      const sections: Section[] = []

      const list = el.querySelector(isRex ? 'ol' : 'ul')
      if (!list) return undefined
      list.setAttribute('id', 'temp_id')
      // Get only direct children
      const items = el.querySelectorAll(`#temp_id > li`)
      list.removeAttribute('id')
      if (!items.length) return undefined

      for (const item of Array.from(items)) {
        const title = isRex
          ? (item.querySelector('a, summary')!.textContent || 'Unknown title').trim()
          : (item.querySelector('.name-wrapper')!.textContent || 'Unknown title').trim()
        const anchorOrWrapper = item.querySelector('a')
        const href = anchorOrWrapper ? anchorOrWrapper.getAttribute('href') : undefined
        const url = href ? `${baseUrlForBook}${href}` : undefined
        const subsections = getSections(item as Element, isRex)

        if (subsections) {
          sections.push({
            type: 'chapter',
            title,
            sections: subsections,
          } as Chapter)
        } else if (url) {
          sections.push({
            type: 'module',
            title,
            url,
          } as Module)
        }
      }

      return sections
    }

    const toc = document.querySelector(tocSelector) as HTMLElement
    const sections = getSections(toc, isRex)

    return sections || []
  }, tocSelector, isRex, baseUrlForBook)

  const bookTitle = await page.evaluate((bookTitleSelector) => {
    const bookTitleElement = document.querySelector(bookTitleSelector) as HTMLElement | null
    const bookTitle = bookTitleElement ? bookTitleElement.innerText : ''
    return bookTitle
  }, bookTitleSelector)

  const toc: Toc = {
    bookTitle,
    sections,
  }

  logger('Saving Table of Contents...', 'info')
  fs.writeFile(
    `${outputPath}/toc.json`,
    JSON.stringify(toc, null, 2),
    err => { if (err) throw err }
  )
  return toc
}

export default scanAndSaveToc
