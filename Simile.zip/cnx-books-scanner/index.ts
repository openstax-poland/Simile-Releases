import * as yargs from 'yargs'
import fs from 'fs'
import puppeteer from 'puppeteer'
import path from 'path'

import makeScreenshotOnPage from './helpers/makeScreenshotOnPage'
import scanAndSaveToc from './helpers/scanAndSaveToc'
import { Toc } from './helpers/interfaces'
import { isValidToc, getModulesFromSections, isValidUrl, getChapterForModule, openNewPage, createLogger } from './helpers/utils'

const argv = yargs
  .option('scan-from-url', {
    describe: 'Url to the book which you want to scan (it will scan whole book) - allowed domains: openxtax.org, cnx.org and herokuapp.com',
    type: 'string',
  })
  .options('scan-from-toc', {
    describe: 'Path to the file with modules to scan. This file should be in the same format as a toc.json',
    type: 'string',
  })
  .option('only-toc', {
    describe: 'Scan only Table of Contents from specific url.',
  })
  .options('width', {
    alias: 'w',
    describe: 'Width of web browser which will be used to display page. Default is 1920px.',
    type: 'number',
  })
  .option('height', {
    alias: 'h',
    describe: 'Height of web browser which will be used to display page. Default is 1080px.',
    type: 'number',
  })
  .options('path', {
    alias: 'p',
    describe: 'Path where screen should be saved.',
    type: 'string',
  })
  .options('filename', {
    describe: 'String from which filenames for screenshots will be created. Allowed fragments: <bookTitle>, <chapterTitle>, <moduleTitle>, <url>, <domain>',
    type: 'string',
  })
  .options('open-tabs-limit', {
    describe: 'Maximum limit of open tabs. It will speed up scanning but it requires more resources. Default limit is 5',
    type: 'number',
  })
  .options('logger', {
    describe: 'Determine which logs shows up in the console. Allowed values: "development" and "production". Default: "development"',
    type: 'string',
  })
  .help()
  .argv

const scanFromUrl = argv['scan-from-url']
const scanFromToc = argv['scan-from-toc']
const width = argv.width || 1920
const height = argv.height || 1080
const outputPath = path.resolve(argv.path || './').replace(/\\/g, '/')
const filename = argv.filename || '<url>'
const openTabsLimit = argv['open-tabs-limit'] || 5
const loggerLevel = argv.logger || 'development'

if (scanFromUrl && scanFromToc) {
  console.error(`You can't use --scan-from-url and --scan-from-toc at the same time.`)
  process.exit(1)
}

if (argv['only-toc'] && !scanFromUrl) {
  console.error(`If you pass --only-toc then you have to pass --scan-from-url`)
  process.exit(1)
}

if (!filename.match(/<moduleTitle>|<url>/)) {
  console.error('An argument --filename has to contain <moduleTitle> or <url> in order to create unique filenames for scans.')
  process.exit(1)
}

const start = async () => {
  const logger = createLogger(loggerLevel)

  logger('Lauching puppeteer...', 'info')
  const browser = await puppeteer.launch()

  if (argv["only-toc"] && scanFromUrl) {
    const page = await openNewPage(browser, { width, height }, logger)
    await scanAndSaveToc(page, scanFromUrl, outputPath, logger)
    await page.close()
    logger('Closing browser...', 'info')
    await browser.close()
    return
  }

  let pathToToc = scanFromToc ? path.resolve(scanFromToc) : outputPath + '/toc.json'
  let toc: Toc | undefined = undefined
  if (scanFromUrl) {
    const page = await openNewPage(browser, { width, height }, logger)
    toc = await scanAndSaveToc(page, scanFromUrl, outputPath, logger)
    await page.close()
  }
  if (!toc) {
    try {
      const maybeToc = JSON.parse(fs.readFileSync(pathToToc, 'utf8'))
      if (isValidToc(maybeToc)) {
        toc = maybeToc
      } else {
        logger(`File at ${pathToToc} has invalid format.`, 'error')
        browser.close()
        process.exit()
      }
    } catch (e) {
      logger(e, 'error')
      browser.close()
      process.exit(1)
    }
  }

  let promises: Promise<void>[] = []
  for (const module of getModulesFromSections(toc!.sections)) {
    if (!isValidUrl(module.url)) {
      logger(`Module: ${module.title} has invalid url: ${module.url}. Skipping...`, 'warn')
      continue
    }
    const chapter = getChapterForModule(toc!.sections, module)
    const chapterTitle = chapter ? chapter.title : ''
    if (promises.length < openTabsLimit) {
      const page = await openNewPage(browser, { width, height }, logger)
      promises.push(
        makeScreenshotOnPage(page, module.url, outputPath, filename, toc!.bookTitle, chapterTitle, module.title, logger)
          .then(() => page.close())
      )
    } else {
      await Promise.all(promises)
      const page = await openNewPage(browser, { width, height }, logger)
      promises = [
        makeScreenshotOnPage(page, module.url, outputPath, filename, toc!.bookTitle, chapterTitle, module.title, logger)
          .then(() => page.close())
        ]
    }
  }
  await Promise.all(promises)

  logger('Closing browser...', 'info')
  await browser.close()
}

start().catch((err) => {
  console.error("Error:", err);
  process.exit(1)
})
