package webviewselenium.gui.scanBookInQA;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;

public class ChangeBrowser {
    @FXML
    private RadioButton Firefox;

    @FXML
    private TextField categoryDescriptionField;

    @FXML
    private Button addCategoryButton;

}
