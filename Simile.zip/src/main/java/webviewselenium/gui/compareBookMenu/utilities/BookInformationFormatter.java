package webviewselenium.gui.compareBookMenu.utilities;

import java.util.Arrays;
import java.util.stream.Collectors;

public class BookInformationFormatter {

	public String getFormattedChapterName(String pathToFile) {
		String formattedChapterName = pathToFile.substring(pathToFile.lastIndexOf("pages") + 6);
		if(countNumberOfDigits(formattedChapterName.substring(0, 5)) > 1)
			formattedChapterName = formattedChapterName.replaceFirst("-", ".");
		else
			formattedChapterName = formattedChapterName.replaceFirst("-", ". ");
		formattedChapterName = formattedChapterName.replaceAll("-", " ");
		formattedChapterName = formattedChapterName.substring(0, formattedChapterName.lastIndexOf("_"));
		formattedChapterName = upperCaseAllFirstCharacter(formattedChapterName);
		return formattedChapterName;
	}

	private Integer countNumberOfDigits(String text) {
		int count = 0;
		for (int i = 0, len = text.length(); i < len; i++) {
			if (Character.isDigit(text.charAt(i))) {
				count++;
			}
		}
		return count;
	}

	private String upperCaseAllFirstCharacter(String textToModify) {
		return Arrays.stream(textToModify.split("\\s+"))
				.map(text -> text.substring(0, 1).toUpperCase() + text.substring(1))
				.collect(Collectors.joining(" "));
	}
}