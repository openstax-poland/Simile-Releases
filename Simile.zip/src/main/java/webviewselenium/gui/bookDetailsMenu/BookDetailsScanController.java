package webviewselenium.gui.bookDetailsMenu;

import javafx.concurrent.Task;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.TextArea;
import javafx.scene.text.Text;
import webviewselenium.bookScan.cnxBookScanner.CnxBookScanner;
import webviewselenium.constans.ConstantFXMLPaths;
import webviewselenium.constans.SharedConstants;
import webviewselenium.constans.SimileContext;
import webviewselenium.gui.StageManager;
import webviewselenium.gui.utilities.ApplicationProperties;
import webviewselenium.parsers.json.TableOfContentsParser;

import java.io.File;
import java.net.URL;
import java.util.ResourceBundle;

public class BookDetailsScanController implements Initializable, ApplicationProperties {
    @FXML private Button collectionMenuButton;
    @FXML private Button scanMenuButton;
    @FXML private Button myLibraryMenuButton;
    @FXML private Button compareMenuButton;
    @FXML private Button generateIssueMenuButton;
    @FXML private Text versionLabelText;
    @FXML private TextArea noteTextArea;
    @FXML private ProgressBar scanProgressBar;
    @FXML private TextArea bookInformationTextArea;
    @FXML private TextArea scannedChaptersTextArea;

    private StageManager stageManager;
    private CnxBookScanner cnxBookScanner;
    private Task<Object> progressTask;
    private TableOfContentsParser tableOfContentsParser;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        stageManager = new StageManager();

        tableOfContentsParser = new TableOfContentsParser(
                SharedConstants.NAME_OF_DIRECTORY_THAT_CONTAINS_SCANS +
                        File.separator + SimileContext.bookDirectoryIndex +
                        File.separator + SharedConstants.TOC_FILENAME);

        initializeApplicationVersionLabel(versionLabelText);
        initializeBookInformationTextAreas();

        cnxBookScanner = new CnxBookScanner();
        cnxBookScanner.addPathParameter(SimileContext.pathParameter);
        cnxBookScanner.addScanFromTocParameter(SimileContext.scanFromTocParameter);

        runScanningProcess();
    }

    private Task<Object> createProgressTask() {
        return new Task<Object>() {
            @Override
            protected Object call() throws Exception {
                updateProgress(0, -1);
                cnxBookScanner.runCommand();
                updateProgress(1, 1);
                return true;
            }
        };
    }

    private void initializeBookInformationTextAreas() {
        bookInformationTextArea.setText(
                "\n\tTitle: " + tableOfContentsParser.getBookTitle()  + "\n\n" +
                        "\tFolder: " + SimileContext.bookDirectoryIndex  + "\n\n" +
                        "\tDate: " + SimileContext.bookScanDate + "\n\n" +
                        "\tServer: " + tableOfContentsParser.getServerName() + "\n");

        noteTextArea.setText("\n\t" + SimileContext.bookNote);

        scannedChaptersTextArea.setText(SimileContext.listOfAllSelectedChaptersToScan);
    }

    private void runScanningProcess() {
        progressTask = createProgressTask();
        scanProgressBar.setStyle("-fx-accent: #440045;");
        scanProgressBar.progressProperty().unbind();
        scanProgressBar.progressProperty().bind(progressTask.progressProperty());
        progressTask.messageProperty().addListener((observable, oldValue, newValue) -> {});
        new Thread(progressTask).start();
    }

    @FXML
    void goToCompareMenu() {
        stageManager.closeCurrentWindow(compareMenuButton);
        stageManager.showStage(ConstantFXMLPaths.compareMenu);
    }

    @FXML
    void goToGenerateIssueMenu() {

    }

    @FXML
    void goToMyLibraryMenu() {
        stageManager.closeCurrentWindow(myLibraryMenuButton);
        stageManager.showStage(ConstantFXMLPaths.collectionMenu);
    }

    @FXML
    void goToScanMenu() {
        stageManager.closeCurrentWindow(scanMenuButton);
        stageManager.showStage(ConstantFXMLPaths.scanMenu);
    }

    @FXML
    void tocTableViewContentClicked() {

    }
}
