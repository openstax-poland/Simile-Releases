package webviewselenium.gui.chooseBookMenu.utilities;

public interface BookPathFinder {

	public String getBookPath(String bookDirectory);
	
}
