package webviewselenium.gui.chooseBookMenu;

public enum ComparisionType {
    QuickCompare,
    DeepCompare
}
