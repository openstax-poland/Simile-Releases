package webviewselenium.gui.generateIssue.yourIssuesMenu;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.text.Text;
import org.apache.commons.lang3.concurrent.BasicThreadFactory;
import org.apache.logging.log4j.core.tools.Generate;
import webviewselenium.bookProperties.BookProperties;
import webviewselenium.bookProperties.IssueProperties;
import webviewselenium.constans.SharedConstants;
import webviewselenium.gui.StageManager;
import webviewselenium.gui.compareBookMenu.CompareBookController;
import webviewselenium.gui.generateIssue.GenerateIssueController;
import webviewselenium.gui.utilities.ApplicationProperties;
import webviewselenium.parsers.xml.issueProperties.IssuePropertiesReader;
import webviewselenium.parsers.xml.scanProperties.ScanPropertiesReader;

import java.awt.*;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.*;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

public class YourIssuesController implements Initializable, ApplicationProperties {
    @FXML private Text versionLabelText;
    @FXML private Text noIssuesCreatedInformationText;
    @FXML private TableView<IssueProperties> issuesTableView;
    @FXML private TableColumn<IssueProperties, String> dateColumn;
    @FXML private TableColumn<IssueProperties, String> titleColumn;
    @FXML private TableColumn<IssueProperties, String> categoryColumn;
    @FXML private TableColumn<IssueProperties, String> descriptionColumn;

    private final Pattern REPORT_DIRECTORY_NAME_PATTERN = Pattern.compile("\\d{4}(-\\d{2}){5}");
    private StageManager stageManager;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        initializeApplicationVersionLabel(versionLabelText);
        initializeTableColumnFactoryValues();
        initializeTableColumnStylesheets();
        initializeIssueTableViewContent();
    }

    /**
     * Method allows to map fields from IssueProperties objects into specific Table View's columns.
     */
    private void initializeTableColumnFactoryValues() {
        dateColumn.setCellValueFactory(new PropertyValueFactory<>(SharedConstants.YI_DATE_COLUMN_VALUE_FACTORY));
        titleColumn.setCellValueFactory(new PropertyValueFactory<>(SharedConstants.YI_TITLE_COLUMN_VALUE_FACTORY));
        categoryColumn.setCellValueFactory(new PropertyValueFactory<>(SharedConstants.YI_CATEGORY_COLUMN_VALUE_FACTORY));
        descriptionColumn.setCellValueFactory(new PropertyValueFactory<>(SharedConstants.YI_DESCRIPTION_COLUMN_VALUE_FACTORY));
    }

    /**
     * Method allows to add necessary stylesheets to the specific Table View's columns.
     */
    private void initializeTableColumnStylesheets() {
        dateColumn.setStyle( "-fx-alignment: CENTER;");
    }

    /**
     * Method allows to fill the Table View with the information about all created Issues/show information about
     * the lack of the issues.
     */
    private void initializeIssueTableViewContent() {
        List<String> directoriesThatContainCreatedIssues = findDirectoriesNamesThatContainCreatedIssues();
        addContentToIssueTableView(directoriesThatContainCreatedIssues);
        showOrHideTableViewOnBasisOfIssues();
    }

    /**
     * Method allows to find all directories inside Results directory that stores created issues.
     * @return all directories inside Results directory that stores created issues
     */
    private List<String> findDirectoriesNamesThatContainCreatedIssues() {
        List<File> allFilesInReportsDirectory = Arrays.asList(Objects.requireNonNull(new File(SharedConstants.NAME_OF_DIRECTORY_THAT_CONTAINS_RESULTANT_REPORTS).listFiles()));
        return allFilesInReportsDirectory.stream()
                .map(File::getName)
                .filter(REPORT_DIRECTORY_NAME_PATTERN.asPredicate())
                .collect(Collectors.toList());
    }

    /**
     * Method allows to add all Issues Properties to the Table View that contains information about created issues.
     * @param directoriesThatContainCreatedIssues list of directories inside Results directory that stores created issues
     */
    private void addContentToIssueTableView(List<String> directoriesThatContainCreatedIssues) {
        directoriesThatContainCreatedIssues.forEach(directoryName -> {
            final File[] allDirectoriesThatStoresIssueCategories = new File(SharedConstants.NAME_OF_DIRECTORY_THAT_CONTAINS_RESULTANT_REPORTS + File.separator + directoryName).listFiles();
            assert allDirectoriesThatStoresIssueCategories != null;

            Arrays.stream(allDirectoriesThatStoresIssueCategories).forEach(issueFile -> {
                String pathToIssueInformationFile = issueFile + File.separator + SharedConstants.ISSUE_INFO_FILENAME;

                if(new File(pathToIssueInformationFile).exists()) {
                    IssuePropertiesReader propertiesReader = new IssuePropertiesReader(pathToIssueInformationFile);
                    IssueProperties properties = propertiesReader.findIssueProperties();
                    issuesTableView.getItems().add(new IssueProperties(properties.getTitle(), properties.getCategory(), properties.getDescription(), properties.getCreationDate(), properties.getParentDirectoryName()));
                }
            });
        });
    }

    /**
     * Method allows to show/hide information about the lack of issues and show/hide Table View that shows
     * created issues on the basis of the number of created issues.
     */
    private void showOrHideTableViewOnBasisOfIssues() {
        if(issuesTableView.getItems().size() > 0) noIssuesCreatedInformationText.setVisible(false);
        else issuesTableView.setVisible(false);
    }

    /**
     * Navigational method that allows to close the current Stage and navigate to the Collection Menu.
     */
    @FXML
    void goToMyLibraryMenu() {
        initializeStageManager();
        stageManager.showMyLibraryMenu();
        stageManager.closeCurrentWindow(stageManager.getStage());
    }

    /**
     * Navigational method that allows to close the current Stage and navigate to the Compare Menu.
     */
    @FXML
    void goToCompareMenu() {
        initializeStageManager();
        stageManager.showCompareMenu();
        stageManager.closeCurrentWindow(stageManager.getStage());
    }

    /**
     * Navigational method that allows to close the current Stage and navigate to the Generate Issue Menu.
     */
    @FXML
    void goToGenerateIssueMenu() {
        initializeStageManager();
        stageManager.showGenerateIssueMenu();
        stageManager.closeCurrentWindow(stageManager.getStage());
    }

    /**
     * Method allows to initialize StageManager which is used to navigate between Stages.
     * VersionLabel object is passed to the initializeStageManager(Text versionLabel) method,
     * because engine is able to use that object to close the current Stage.
     */
    private void initializeStageManager() {
        if(stageManager == null) stageManager = initializeStageManager(versionLabelText);
    }

    /**
     * Method defines the behaviour for the situation when user clicks the Report Record in the Issue Table View.
     * It was decided to open PDF Report with the default PDF Viewer, if it is possible.
     */
    @FXML
    void reportRecordIsClicked() {
        final String currentSimilePathInUserSystem = System.getProperty("user.dir");
        final String issueCategory = issuesTableView.getSelectionModel().getSelectedItem().getCategory();
        final String issueParentDirectoryName = issuesTableView.getSelectionModel().getSelectedItem().getParentDirectoryName();
        final String pathToThePotentialIssueReport = currentSimilePathInUserSystem + File.separator +
                issueParentDirectoryName + File.separator + issueCategory + File.separator + SharedConstants.REPORT_FILE;

        if(!doesReportFileExists(pathToThePotentialIssueReport)) {
            showReportNotFoundAlert();
            return;
        }

        final File reportFile = new File(pathToThePotentialIssueReport);
        final BasicThreadFactory factory = new BasicThreadFactory.Builder().build();
        final ExecutorService executorService = Executors.newSingleThreadExecutor(factory);

        if(Desktop.isDesktopSupported()) executorService.execute(() -> tryToOpenReportFileWithDefaultPDFViewer(reportFile));
    }

    /**
     * Method indicates if the Issue Report file exists or not.
     * @param pathToReportFile path to the potential Issue Report file
     * @return true if the Issue Report file exists or false if the Issue Report does not exist
     */
    private boolean doesReportFileExists(String pathToReportFile) {
        return new File(pathToReportFile).exists();
    }

    /**
     * Method makes a try to open the Issue Report file with the default PDF Viewer.
     * @param reportFile path to the Issue Report file
     */
    private void tryToOpenReportFileWithDefaultPDFViewer(File reportFile) {
        try {
            Desktop.getDesktop().open(reportFile);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void showReportNotFoundAlert() {
        Alert generateReportAlert = new Alert(Alert.AlertType.WARNING);
        generateReportAlert.setHeaderText("Issue Report not found!");
        generateReportAlert.setContentText("Probably report hasn't been created.");
        generateReportAlert.showAndWait();
    }
}
