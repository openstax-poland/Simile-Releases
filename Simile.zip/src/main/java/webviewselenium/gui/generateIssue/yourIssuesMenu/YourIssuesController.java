package webviewselenium.gui.generateIssue.yourIssuesMenu;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.text.Text;
import org.apache.commons.lang3.concurrent.BasicThreadFactory;
import webviewselenium.bashRunScripts.CommandsRunner;
import webviewselenium.bookProperties.IssueProperties;
import webviewselenium.constans.SharedConstants;
import webviewselenium.constans.SimileContext;
import webviewselenium.gui.StageManager;
import webviewselenium.gui.utilities.ApplicationProperties;
import webviewselenium.parsers.xml.issueProperties.IssuePropertiesReader;

import java.awt.*;
import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.*;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

public class YourIssuesController implements Initializable, ApplicationProperties {
    @FXML private Text versionLabelText;
    @FXML private Text noIssuesCreatedInformationText;
    @FXML private TableView<IssueProperties> issuesTableView;
    @FXML private TableColumn<IssueProperties, String> dateColumn;
    @FXML private TableColumn<IssueProperties, String> titleColumn;
    @FXML private TableColumn<IssueProperties, String> categoryColumn;
    @FXML private TableColumn<IssueProperties, String> descriptionColumn;

    private final Pattern REPORT_DIRECTORY_NAME_PATTERN = Pattern.compile("\\d{4}(-\\d{2}){5}");
    private StageManager stageManager;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        initializeApplicationVersionLabel(versionLabelText);
        initializeTableColumnFactoryValues();
        initializeTableColumnStylesheets();
        initializeIssueTableViewContent();
    }

    /**
     * Method allows to map fields from IssueProperties objects into specific Table View's columns.
     */
    private void initializeTableColumnFactoryValues() {
        dateColumn.setCellValueFactory(new PropertyValueFactory<>(SharedConstants.YI_DATE_COLUMN_VALUE_FACTORY));
        titleColumn.setCellValueFactory(new PropertyValueFactory<>(SharedConstants.YI_TITLE_COLUMN_VALUE_FACTORY));
        categoryColumn.setCellValueFactory(new PropertyValueFactory<>(SharedConstants.YI_CATEGORY_COLUMN_VALUE_FACTORY));
        descriptionColumn.setCellValueFactory(new PropertyValueFactory<>(SharedConstants.YI_DESCRIPTION_COLUMN_VALUE_FACTORY));
    }

    /**
     * Method allows to add necessary stylesheets to the specific Table View's columns.
     */
    private void initializeTableColumnStylesheets() {
        dateColumn.setStyle( "-fx-alignment: CENTER;");
    }

    /**
     * Method allows to fill the Table View with the information about all created Issues/show information about
     * the lack of the issues.
     */
    private void initializeIssueTableViewContent() {
        List<String> directoriesThatContainCreatedIssues = findDirectoriesNamesThatContainCreatedIssues();
        addContentToIssueTableView(directoriesThatContainCreatedIssues);
        showOrHideTableViewOnBasisOfIssues();
    }

    /**
     * Method allows to find all directories inside Results directory that stores created issues.
     * @return all directories inside Results directory that stores created issues
     */
    private List<String> findDirectoriesNamesThatContainCreatedIssues() {
        List<File> allFilesInReportsDirectory = Arrays.asList(Objects.requireNonNull(new File(SharedConstants.NAME_OF_DIRECTORY_THAT_CONTAINS_RESULTANT_REPORTS).listFiles()));
        return allFilesInReportsDirectory.stream()
                .map(File::getName)
                .filter(REPORT_DIRECTORY_NAME_PATTERN.asPredicate())
                .collect(Collectors.toList());
    }

    /**
     * Method allows to add all Issues Properties to the Table View that contains information about created issues.
     * @param directoriesThatContainCreatedIssues list of directories inside Results directory that stores created issues
     */
    private void addContentToIssueTableView(List<String> directoriesThatContainCreatedIssues) {
        directoriesThatContainCreatedIssues.forEach(directoryName -> {
            final File[] allDirectoriesThatStoresIssueCategories = new File(SharedConstants.NAME_OF_DIRECTORY_THAT_CONTAINS_RESULTANT_REPORTS + File.separator + directoryName).listFiles();
            assert allDirectoriesThatStoresIssueCategories != null;

            Arrays.stream(allDirectoriesThatStoresIssueCategories).forEach(issueFile -> {
                String pathToIssueInformationFile = issueFile + File.separator + SharedConstants.ISSUE_INFO_FILENAME;

                if(new File(pathToIssueInformationFile).exists()) {
                    IssuePropertiesReader propertiesReader = new IssuePropertiesReader(pathToIssueInformationFile);
                    IssueProperties properties = propertiesReader.findIssueProperties();
                    issuesTableView.getItems().add(new IssueProperties(properties.getTitle(), properties.getCategory(), properties.getDescription(), properties.getCreationDate(), properties.getParentDirectoryName()));
                }
            });
        });
    }

    /**
     * Method allows to show/hide information about the lack of issues and show/hide Table View that shows
     * created issues on the basis of the number of created issues.
     */
    private void showOrHideTableViewOnBasisOfIssues() {
        if(issuesTableView.getItems().size() > 0) noIssuesCreatedInformationText.setVisible(false);
        else issuesTableView.setVisible(false);
    }

    /**
     * Navigational method that allows to close the current Stage and navigate to the Collection Menu.
     */
    @FXML
    void goToMyLibraryMenu() {
        initializeStageManager();
        stageManager.showMyLibraryMenu();
    }

    /**
     * Navigational method that allows to close the current Stage and navigate to the Compare Menu.
     */
    @FXML
    void goToCompareMenu() {
        initializeStageManager();
        stageManager.showCompareMenu();
    }

    /**
     * Navigational method that allows to close the current Stage and navigate to the Generate Issue Menu.
     */
    @FXML
    void goToGenerateIssueMenu() {
        initializeStageManager();
        stageManager.showGenerateIssueMenu();
    }

    /**
     * Method allows to initialize StageManager which is used to navigate between Stages.
     * VersionLabel object is passed to the initializeStageManager(Text versionLabel) method,
     * because engine is able to use that object to close the current Stage.
     */
    private void initializeStageManager() {
        if(stageManager == null) stageManager = initializeStageManager(versionLabelText);
    }

    @FXML
    void reportRecordIsClicked() throws IOException, InterruptedException {
        String date = issuesTableView.getSelectionModel().getSelectedItem().getCreationDate().replaceAll(" ", "-").replaceAll(":", "-");
        String category = issuesTableView.getSelectionModel().getSelectedItem().getCategory();
        String parent = issuesTableView.getSelectionModel().getSelectedItem().getParentDirectoryName();
        IssueProperties is = issuesTableView.getSelectionModel().getSelectedItem();
        String currentPath = System.getProperty("user.dir");
        String x = currentPath + "/" + parent + "/" + category + "/category-report.pdf";

        if(SimileContext.OS_NAME.contains("Mac")) {
            File myFile = new File(x);
            Desktop.getDesktop().open(myFile);
        } else {
            ExecutorService executorService;
            BasicThreadFactory factory = new BasicThreadFactory.Builder()
                    .namingPattern("YourPatternIndeficator")
                    .build();
            executorService = Executors.newSingleThreadExecutor(factory);
            if (Desktop.isDesktopSupported()) {
                File myFile = new File(x);
                executorService.execute(() -> {
                    try {
                        Desktop.getDesktop().open(myFile);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                });

            }
        }



    }

    private void runProcess(ProcessBuilder pb) throws IOException {
        pb.redirectErrorStream(true);
        Process p = pb.start();
        BufferedReader reader = new BufferedReader(new InputStreamReader(p.getInputStream()));
        String line;
        while ((line = reader.readLine()) != null) {
            System.out.println(line);
        }
    }
}
