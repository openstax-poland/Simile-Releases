package webviewselenium.gui.generateIssue;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;

import javafx.scene.text.Text;
import org.apache.log4j.Logger;

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.PdfWriter;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextArea;
import javafx.scene.control.Tooltip;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import webviewselenium.bookProperties.BookProperties;
import webviewselenium.bookProperties.IssueProperties;
import webviewselenium.constans.SimileContext;
import webviewselenium.gui.ApplicationLoader;
import webviewselenium.gui.StageManager;
import webviewselenium.constans.ConstantFXMLPaths;
import webviewselenium.constans.SharedConstants;
import webviewselenium.gui.generateIssue.utilities.GenerateIssueControllerUtilities;
import webviewselenium.gui.generateIssue.utilities.ImageNavigationUtilities;
import webviewselenium.gui.utilities.ApplicationProperties;
import webviewselenium.parsers.xml.issueProperties.IssuePropertiesReader;
import webviewselenium.reportConversion.IReportIntoImagesConverter;
import webviewselenium.reportConversion.ReportIntoJpgConverter;

public class GenerateIssueController implements Initializable, ApplicationProperties {
	private final Logger LOGGER = ApplicationLoader.getLogger();
	private final GenerateIssueControllerUtilities utilities = new GenerateIssueControllerUtilities();
	private ImageNavigationUtilities imageNavigationUtilities;
	private StageManager stageManager;

	private final String QA_IMAGE_PREFIX = SharedConstants.QA_RESULTANT_IMAGE_PREFIX;

	private static String pathToReportDirectory;
	private static BookProperties qaBookProperties;
	private static BookProperties referenceBookProperties;

    private List<String> foundCategoriesCreatedByUser = new ArrayList<>();

	private static List<Integer> imagesIndexesWithinCategory;
    private static Integer numberOfCurrentlyDisplayedImageWithinCategory = 0;
    private static Integer indexOfCurrentlyDisplayedImageWithCategory = 0;

    private IssueProperties issueProperties = new IssueProperties();

	@FXML private Text versionLabelText;
	@FXML private Text bookTitleText;
	@FXML private Text chapterNameText;
	@FXML private ComboBox<String> categoryComboBox;
	@FXML private TextArea categoryDescriptionField;
	@FXML private Button qaBookInfoButton;
	@FXML private ScrollPane qaBookScrollPane;
	@FXML private ImageView qaBookImage;
	@FXML private Button referenceBookInfoButton;
	@FXML private ScrollPane referenceBookScrollPane;
	@FXML private ImageView referenceBookImage;

	// This no-args constructor is required by the JavaFX.
	public GenerateIssueController() {
		this.pathToReportDirectory = SimileContext.pathToReportDirectory;
		this.qaBookProperties = SimileContext.qaBookProperties;
		this.referenceBookProperties = SimileContext.referenceBookProperties;
	}

	public GenerateIssueController(String pathToReportDirectory, BookProperties qaBookProperties, BookProperties referenceBookProperties) {
		this.pathToReportDirectory = pathToReportDirectory;
		this.qaBookProperties = qaBookProperties;
		this.referenceBookProperties = referenceBookProperties;
	}

	/**
	 * Navigational method that allows to close the current Stage and navigate to the Collection Menu.
	 */
	@FXML
	void goToMyLibraryMenu() {
		initializeStageManager();
		stageManager.showMyLibraryMenu();
	}

	/**
	 * Navigational method that allows to close the current Stage and navigate to the Compare Menu.
	 */
	@FXML
	void goToCompareMenu() {
		initializeStageManager();
		stageManager.showCompareMenu();
	}

	/**
	 * Navigational method that allows to close the current Stage and navigate to the Your Issues Menu.
	 */
	@FXML
	void goToYourIssuesMenu() {
		initializeStageManager();
		stageManager.showYourIssuesMenu();
	}

	/**
	 * Method allows to initialize StageManager which is used to navigate between Stages.
	 * VersionLabel object is passed to the initializeStageManager(Text versionLabel) method,
	 * because engine is able to use that object to close the current Stage.
	 */
	private void initializeStageManager() {
		if(stageManager == null) stageManager = initializeStageManager(versionLabelText);
	}

	/**
	 * Method allows to display the previous image within the category (if exists).
	 */
	@FXML
	void moveLeft() {
		final Image currentImage = qaBookImage.getImage();
		if(imageNavigationUtilities.isItPossibleToDisplayPreviousImage(currentImage, numberOfCurrentlyDisplayedImageWithinCategory, imagesIndexesWithinCategory)) {
			numberOfCurrentlyDisplayedImageWithinCategory--;
			displayResultantImages();
		}
	}

	/**
	 * Method allows to display the next image within the category (if exists).
	 */
	@FXML
	void moveRight() {
		final Image currentImage = qaBookImage.getImage();
		if(imageNavigationUtilities.isItPossibleToDisplayNextImage(currentImage, numberOfCurrentlyDisplayedImageWithinCategory, imagesIndexesWithinCategory)) {
			numberOfCurrentlyDisplayedImageWithinCategory++;
			displayResultantImages();
		}
	}
	
	@FXML
	void categoryHasBeenChosen() {
		imageNavigationUtilities = new ImageNavigationUtilities(pathToReportDirectory, categoryComboBox.getSelectionModel().getSelectedItem());
		numberOfCurrentlyDisplayedImageWithinCategory = imageNavigationUtilities.getFirstImageNumberWithinCategory();

		String pathToIssue = pathToReportDirectory + File.separator + categoryComboBox.getSelectionModel().getSelectedItem();
        List<String> allImagesRelatedToIssueInReportDirectory = utilities.findPNGs(pathToIssue);
        imagesIndexesWithinCategory = utilities.findPossibleSortedImageIndexes(allImagesRelatedToIssueInReportDirectory);

		String link = utilities.readLinksFromXMLFile(pathToIssue, Integer.toString(imagesIndexesWithinCategory.get(numberOfCurrentlyDisplayedImageWithinCategory)));
		String currentChapterName = link.substring(link.lastIndexOf("+") + 1);

		bookTitleText.setText(getValidatedBookTitle());
		chapterNameText.setText(currentChapterName);

		displayResultantImages();

		final String pathToIssueXmlProperties = pathToIssue + File.separator + SharedConstants.ISSUE_INFO_FILENAME;
		final IssuePropertiesReader issuePropertiesReader = new IssuePropertiesReader(pathToIssueXmlProperties);
		this.issueProperties = issuePropertiesReader.findIssueProperties();

		final String issueDescription = this.issueProperties.getDescription();
		this.categoryDescriptionField.setText(issueDescription);
	}

	private void displayResultantImages() {
		imageNavigationUtilities.displayResultantImages(findIndexOfCurrentlyDisplayedImageWithCategory(), qaBookImage, qaBookScrollPane, referenceBookImage, referenceBookScrollPane);
	}

	private Integer findIndexOfCurrentlyDisplayedImageWithCategory() {
		return imagesIndexesWithinCategory.get(numberOfCurrentlyDisplayedImageWithinCategory);
	}

	private String getValidatedBookTitle() {
		final int MAX_TITLE_LENGTH = 30;
		if(qaBookProperties.getBookTitle().length() > MAX_TITLE_LENGTH) {
			final StringBuilder validatedBookTitle = new StringBuilder(qaBookProperties.getBookTitle().substring(0, MAX_TITLE_LENGTH));
			validatedBookTitle.append("...");
			return validatedBookTitle.toString();
		}
		return qaBookProperties.getBookTitle();
	}

	@FXML
	void generateIssue() {
		String categoryPath = pathToReportDirectory +
				File.separator + 
				categoryComboBox.getSelectionModel().getSelectedItem();
		Map<Integer, String> images = new LinkedHashMap<Integer, String>();
		String pathToCurrentImage = pathToReportDirectory +
				File.separator + 
				categoryComboBox.getSelectionModel().getSelectedItem() +
				File.separator +
				QA_IMAGE_PREFIX +
				imagesIndexesWithinCategory.get(numberOfCurrentlyDisplayedImageWithinCategory);
		images.put(0, pathToCurrentImage);
		generatePDF(categoryPath, this.issueProperties.getCategory(), this.issueProperties.getDescription(), images);
		IReportIntoImagesConverter pdfToImageConverter = new ReportIntoJpgConverter();
		String jpgReportDirectory = categoryPath + File.separator + "jpgReport";
		if(!new File(jpgReportDirectory).exists()) {
			new File(jpgReportDirectory).mkdirs();
		}
		pdfToImageConverter.convertPDF(
				categoryPath + File.separator + SharedConstants.nameOfCategoryReportPdfFile + SharedConstants.PDF_EXTENSION,
				jpgReportDirectory);
	}

	public void showStage() {
		try {
			URL stageUrl = new File(ConstantFXMLPaths.generateIssueMenu).toURI().toURL();
			Parent stageRoot = FXMLLoader.load(stageUrl);
			Stage theStage = new Stage();
			theStage.setScene(new Scene(stageRoot, 1366, 750));
			theStage.setMinWidth(1366);
			theStage.centerOnScreen();
			theStage.show();
		} catch (IOException ex) {
			ex.printStackTrace();
			LOGGER.error(GenerateIssueController.class.getName() + ": " + ex.getMessage());
		}
	}
	
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		initializeApplicationVersionLabel(versionLabelText);
		bookTitleText.setText("");
		chapterNameText.setText("");
		if(qaBookProperties != null && referenceBookProperties != null && new File(pathToReportDirectory).listFiles() != null) {
			File reportDirectory = new File(pathToReportDirectory);
			File[] allFiles = reportDirectory.listFiles();

			for (File categoryDirectory : allFiles) {
				if (!categoryDirectory.getPath().contains(".")) {
					categoryComboBox.getItems().add(categoryDirectory.getName());
					foundCategoriesCreatedByUser.add(categoryDirectory.getPath());
				}
			}

			qaBookInfoButton.setTooltip(new Tooltip(
					"Title: " + qaBookProperties.getBookTitle() + "\n" +
							"Commit: " + qaBookProperties.getCommitName() + "\n" +
							"Browser: " + qaBookProperties.getBrowserName() + "\n" +
							"Source: " + qaBookProperties.getServerName() + "\n" +
							"Date: " + qaBookProperties.getDate() + "\n"));

			referenceBookInfoButton.setTooltip(new Tooltip(
					"Title: " + referenceBookProperties.getBookTitle() + "\n" +
							"Commit: " + referenceBookProperties.getCommitName() + "\n" +
							"Browser: " + referenceBookProperties.getBrowserName() + "\n" +
							"Source: " + referenceBookProperties.getServerName() + "\n" +
							"Date: " + referenceBookProperties.getDate() + "\n"));
		}
	}

    private void generatePDF(String path, String categoryName, String categoryDescription, Map<Integer, String> images) {
        String pathToPDF = path + File.separator + SharedConstants.nameOfCategoryReportPdfFile + ".pdf";
        File pdfFile = new File(pathToPDF);
        if (!pdfFile.exists()) {
            try {
                pdfFile.createNewFile();
            } catch (IOException ex) {
				ex.printStackTrace();
				LOGGER.error(GenerateIssueController.class.getName() + ": " + ex.getMessage());
            }
        }
        try {
        	String link = utilities.readLinksFromXMLFile(path, Integer.toString(imagesIndexesWithinCategory.get(numberOfCurrentlyDisplayedImageWithinCategory)));
            com.itextpdf.text.Document document = new com.itextpdf.text.Document();
            document.setPageSize(PageSize.A4.rotate());
            PdfWriter writer = PdfWriter.getInstance(document, new FileOutputStream(pathToPDF));
            document.open();

            Font font = FontFactory.getFont(FontFactory.HELVETICA, 16, new BaseColor(68, 0, 69));
            Font linkAttributeFont = FontFactory.getFont(FontFactory.HELVETICA, 12, new BaseColor(68, 0, 69));
            writer.setSpaceCharRatio(PdfWriter.SPACE_CHAR_RATIO_DEFAULT);
            
            Rectangle background = new Rectangle(PageSize.A4.rotate());
            background.setBackgroundColor(new BaseColor(212, 212, 217));   
            document.add(background);
            Rectangle categoryWhiteBackground = new Rectangle(165, 430, 830, 565);
            categoryWhiteBackground.setBackgroundColor(new BaseColor(255,255,255));
            
            document.add(categoryWhiteBackground);

            Paragraph paragraph;
            Chunk header, value;
            
            header = new Chunk("      Category:", font);
            value = new Chunk(categoryName, font);
            paragraph = new Paragraph();
            paragraph.add(header);
            paragraph.add(Chunk.TABBING); paragraph.add(Chunk.TABBING);
            paragraph.add(value);            
            document.add(paragraph);
            
            header = new Chunk("   Description:", font);
            value = new Chunk(categoryDescription, font);
            paragraph = new Paragraph();
            paragraph.add(header);
            paragraph.add(Chunk.TABBING); paragraph.add(Chunk.TABBING);
            paragraph.add(value);            
            document.add(paragraph);
            
            header = new Chunk("     Book Title:", font);
            value = new Chunk(qaBookProperties.getBookTitle(), font);
            paragraph = new Paragraph();
            paragraph.add(header);
            paragraph.add(Chunk.TABBING); paragraph.add(Chunk.TABBING);
            paragraph.add(value);            
            document.add(paragraph);

            boolean isPlusAtTheEnd = false;
            if(link.charAt(link.length()-1) == '+') {
				link = link.substring(0, link.length() - 1);
				isPlusAtTheEnd = true;
			}
            String location = link.substring(link.lastIndexOf("+") + 1, link.length() - 1);
            header = new Chunk("       Location:", font);
            value = new Chunk(location, font);
            paragraph = new Paragraph();
            paragraph.add(header);
            paragraph.add(Chunk.TABBING); paragraph.add(Chunk.TABBING);
            paragraph.add(value);            
            document.add(paragraph);

            if(isPlusAtTheEnd)
            	link += "+";
            link = link.replace("+", "/");
            link = link.replace("[]", ":");
            link = link.replace("_", ":");
            link = link.substring(0, link.length());
            link = link.replace(referenceBookProperties.getServerName(), qaBookProperties.getServerName());
            header = new Chunk("              Link:", font);
            value = new Chunk(link, linkAttributeFont);
            paragraph = new Paragraph();
            paragraph.add(header);
            paragraph.add(Chunk.TABBING); paragraph.add(Chunk.TABBING);
            paragraph.add(value);            
            document.add(paragraph);
            
            header = new Chunk("         Source:", font);
            value = new Chunk(qaBookProperties.getServerName(), font);
            paragraph = new Paragraph();
            paragraph.add(header);
            paragraph.add(Chunk.TABBING); paragraph.add(Chunk.TABBING);
            paragraph.add(value);            
            document.add(paragraph);
            
            header = new Chunk("       Browser:", font);
            value = new Chunk(qaBookProperties.getBrowserName(), font);
            paragraph = new Paragraph();
            paragraph.add(header);
            paragraph.add(Chunk.TABBING); paragraph.add(Chunk.TABBING);
            paragraph.add(value);            
            document.add(paragraph);
            
            document.add(Chunk.NEWLINE);
            document.add(Chunk.NEWLINE);
            paragraph = new Paragraph();
            paragraph.add(new Chunk("Book in QA", font));
            paragraph.add(Chunk.TABBING); paragraph.add(Chunk.TABBING);
            paragraph.add(Chunk.TABBING); paragraph.add(Chunk.TABBING);
            paragraph.add(Chunk.TABBING); paragraph.add(Chunk.TABBING);
            paragraph.add(Chunk.TABBING); paragraph.add(Chunk.TABBING);
            paragraph.add(Chunk.TABBING); paragraph.add(Chunk.TABBING); paragraph.add(Chunk.TABBING);
            paragraph.add(new Chunk("Reference Book", font));
            document.add(paragraph);
            document.add(Chunk.NEWLINE);
            
            int numberOfImages = images.size();
            for (int i = 0; i < numberOfImages; i++) {

            	com.itextpdf.text.Image scannedImage = com.itextpdf.text.Image.getInstance(images.get(i) + ".png");

            	if(scannedImage.getWidth() > 420 && scannedImage.getHeight() > 350) {
            		scannedImage.setAbsolutePosition(37, 30);
            		scannedImage.scaleAbsolute(420, 350);
            	}
            	else if(scannedImage.getWidth() > 420 && scannedImage.getHeight() <= 350) {
            		//scannedImage.setAbsolutePosition(37, 420 - scannedImage.getHeight());
            		scannedImage.setAbsolutePosition(37, 380 - scannedImage.getHeight());
            		scannedImage.scaleAbsolute(420, scannedImage.getHeight());
            		//scannedImage.scaleToFit(425, scannedImage.getHeight());
            	} else {
            		//scannedImage.setAbsolutePosition(37, 380 - scannedImage.getHeight());
            		scannedImage.setAbsolutePosition(37, 380 - scannedImage.getHeight());
            		//scannedImage.scaleToFit(scannedImage.getWidth(), scannedImage.getHeight());
            		scannedImage.scaleAbsolute(scannedImage.getWidth(), scannedImage.getHeight());
            	}

                document.add(scannedImage);
                
                int lastIndex = images.get(i).lastIndexOf("Scanned");
                String sub1 = images.get(i).substring(0, lastIndex);
                String sub2 = images.get(i).substring(lastIndex + 7, images.get(i).length());
                String result = sub1 + "Template" + sub2;

                com.itextpdf.text.Image templateImage = com.itextpdf.text.Image.getInstance(result + ".png");
                
            	if(templateImage.getWidth() > 420 && templateImage.getHeight() > 350) {
            		templateImage.scaleAbsolute(325, 295);
            		templateImage.setAbsolutePosition(503, 85);
            	}
            	else if(templateImage.getWidth() > 420 && templateImage.getHeight() <= 350) {
            		//templateImage.setAbsolutePosition(503, 420 - templateImage.getHeight());
            		//templateImage.scaleToFit(325, templateImage.getHeight());
            		templateImage.setAbsolutePosition(503, 380 - scannedImage.getHeight());
            		templateImage.scaleAbsolute(325, scannedImage.getHeight());
            	} else {
            		//templateImage.setAbsolutePosition(503, 380 - templateImage.getHeight());
            		//templateImage.scaleToFit(templateImage.getWidth(), templateImage.getHeight());
            		templateImage.setAbsolutePosition(503, 380 - scannedImage.getHeight());
            		templateImage.scaleAbsolute(scannedImage.getWidth(), scannedImage.getHeight());
            	}  
            	
                document.add(templateImage);

                document.add(new Paragraph(""));
                document.add(new Paragraph(""));
            }

            document.close();
            
            Alert issueGeneratedAlert = new Alert(AlertType.INFORMATION);
            issueGeneratedAlert.setTitle("Information");
            issueGeneratedAlert.setHeaderText("Issue has been generated successfully!");
            issueGeneratedAlert.showAndWait();

        } catch (DocumentException ex) {
			ex.printStackTrace();
			LOGGER.error(GenerateIssueController.class.getName() + ": " + ex.getMessage());
        } catch (FileNotFoundException ex) {
			ex.printStackTrace();
			LOGGER.error(GenerateIssueController.class.getName() + ": " + ex.getMessage());
        } catch (IOException ex) {
			ex.printStackTrace();
			LOGGER.error(GenerateIssueController.class.getName() + ": " + ex.getMessage());
        }
    }
}
