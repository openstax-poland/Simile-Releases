package webviewselenium.gui.generateIssue.utilities;

import javafx.scene.control.ScrollPane;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import webviewselenium.constans.SharedConstants;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.List;

public class ImageNavigationUtilities {
    private final String QA_IMAGE_PREFIX = SharedConstants.QA_RESULTANT_IMAGE_PREFIX;
    private final String PATH_TO_REPORT_DIRECTORY;
    private final String ISSUE_CATEGORY_NAME;

    private Integer currentImageIndex;
    private ImageView qaBookImage;
    private ScrollPane qaBookScrollPane;
    private ImageView referenceBookImage;
    private ScrollPane referenceBookScrollPane;

    public ImageNavigationUtilities(String pathToReportDirectory, String issueCategoryName) {
        this.PATH_TO_REPORT_DIRECTORY = pathToReportDirectory;
        this.ISSUE_CATEGORY_NAME = issueCategoryName;
    }

    public boolean isItPossibleToDisplayPreviousImage(Image image, Integer numberOfImageWithinCategory, List<Integer> imagesIndexesWithinCategory) {
        if(image != null && numberOfImageWithinCategory > 0 && numberOfImageWithinCategory < imagesIndexesWithinCategory.size()) return true;
        return false;
    }

    public boolean isItPossibleToDisplayNextImage(Image image, Integer numberOfImageWithinCategory, List<Integer> imagesIndexesWithinCategory) {
        if(image != null && numberOfImageWithinCategory >= 0 && numberOfImageWithinCategory < imagesIndexesWithinCategory.size() - 1) return true;
        return false;
    }

    public void displayResultantImages(Integer currentImageIndex, ImageView qaBookImage, ScrollPane qaBookScrollPane, ImageView referenceBookImage, ScrollPane referenceBookScrollPane) {
        this.currentImageIndex = currentImageIndex;
        this.qaBookImage = qaBookImage;
        this.qaBookScrollPane = qaBookScrollPane;
        this.referenceBookImage = referenceBookImage;
        this.referenceBookScrollPane = referenceBookScrollPane;

        displayResultantQaImage();
        displayResultantReferenceImage();
    }

    private void displayResultantQaImage() {
        String pathToQaImage = PATH_TO_REPORT_DIRECTORY + File.separator + ISSUE_CATEGORY_NAME + File.separator +
                QA_IMAGE_PREFIX + currentImageIndex + SharedConstants.PNG_EXTENSION;
        try {
            FileInputStream qaBookSource = new FileInputStream(pathToQaImage);
            qaBookImage.setImage(new Image(qaBookSource));
            qaBookScrollPane.setContent(qaBookImage);
        } catch (FileNotFoundException ex) {
            ex.printStackTrace();
        }
    }

    private void displayResultantReferenceImage() {
        String referenceResultantImagePrefix = SharedConstants.REFERENCE_RESULTANT_IMAGE_PREFIX;

        String pathToReferenceImage = PATH_TO_REPORT_DIRECTORY + File.separator + ISSUE_CATEGORY_NAME + File.separator +
                referenceResultantImagePrefix + currentImageIndex + SharedConstants.PNG_EXTENSION;
        try {
            FileInputStream referenceBookSource = new FileInputStream(pathToReferenceImage);
            referenceBookImage.setImage(new Image(referenceBookSource));
            referenceBookScrollPane.setContent(referenceBookImage);
        } catch (FileNotFoundException ex) {
            ex.printStackTrace();
        }
    }

    public Integer getFirstImageNumberWithinCategory() {
        final Integer FIRST_IMAGE_NUMBER = 0;
        return FIRST_IMAGE_NUMBER;
    }
}
