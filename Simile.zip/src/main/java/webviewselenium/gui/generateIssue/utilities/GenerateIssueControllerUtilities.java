package webviewselenium.gui.generateIssue.utilities;

import org.w3c.dom.*;
import org.xml.sax.SAXException;
import webviewselenium.constans.SharedConstants;
import webviewselenium.gui.generateIssue.GenerateIssueController;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.File;
import java.io.IOException;
import java.util.*;

public class GenerateIssueControllerUtilities {

    public List<String> findPNGs(String pathToReportDirectory) {
        List<String> allPNGs = new ArrayList<>();
        File[] allFiles = new File(pathToReportDirectory).listFiles();
        for (File file : allFiles) {
            if (!file.getPath().contains(SharedConstants.XML_EXTENSION)) {
                allPNGs.add(file.getPath());
            }
        }
        return allPNGs;
    }

    public List<Integer> findPossibleSortedImageIndexes(List<String> allPNGs) {
        List<Integer> allImagesIndexes = new ArrayList<>();
        allPNGs.forEach(png -> {
            if (png.contains(SharedConstants.QA_RESULTANT_IMAGE_PREFIX)) {
                allImagesIndexes.add(Integer.parseInt(png.substring(png.lastIndexOf("_") + 1, png.lastIndexOf("_") + 2)));
            }
        });

        Collections.sort(allImagesIndexes);
        return allImagesIndexes;
    }

    public Map<String, String> readInformationFromXMLFile(String pathToCategoryDirectory) {
        try {
            File xmlFile = new File(pathToCategoryDirectory + File.separator + SharedConstants.nameOfCategoryInfoXmlFile + ".xml");
            DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
            Document document = documentBuilder.parse(xmlFile);
            document.getDocumentElement().normalize();

            // the name of the root element
            NodeList nodeList = document.getElementsByTagName("Category");

            Map<String, String> categoryInformation = new LinkedHashMap<>();

            for (int i = 0; i < nodeList.getLength(); i++) {
                Node theNode = nodeList.item(i);

                if (theNode.getNodeType() == Node.ELEMENT_NODE) {
                    Element theElement = (Element) theNode;

                    String name = theElement.getElementsByTagName("Name").item(0).getTextContent();
                    String description = theElement.getElementsByTagName("Description").item(0).getTextContent();

                    categoryInformation.put("name", name);
                    categoryInformation.put("description", description);
                }
            }
            return categoryInformation;

        } catch (IOException | NumberFormatException | ParserConfigurationException | DOMException | SAXException ex) {
            ex.printStackTrace();
        }
        return null;
    }

    public String readLinksFromXMLFile(String pathToCategoryDirectory, String imageIndex) {
        try {
            File xmlFile = new File(pathToCategoryDirectory + File.separator
                    + SharedConstants.nameOfLinksXmlFile+ ".xml");
            DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
            Document document = documentBuilder.parse(xmlFile);
            document.getDocumentElement().normalize();

            // the name of the root element
            NodeList nodeList = document.getElementsByTagName("Images");

            String link = "";

            for (int i = 0; i < nodeList.getLength(); i++) {
                Node theNode = nodeList.item(i);

                if (theNode.getNodeType() == Node.ELEMENT_NODE) {
                    Element theElement = (Element) theNode;

                    if(theElement.getElementsByTagName("Index").item(0).getTextContent().equals(imageIndex)) {
                        link = theElement.getElementsByTagName("Link").item(0).getTextContent();
                    }
                }
            }
            return link;

        } catch (IOException | NumberFormatException | ParserConfigurationException | DOMException | SAXException ex) {
            ex.printStackTrace();
        }
        return null;
    }

}
