package webviewselenium.gui.compareMenu.utilities;

import org.apache.commons.lang3.StringUtils;
import webviewselenium.bookProperties.ScanProperties;
import webviewselenium.constans.SharedConstants;
import webviewselenium.parsers.xml.scanProperties.ScanPropertiesReader;

import java.io.File;

public class ComparisonTimeEstimater {
    private final String ESTIMATED_TIME_PREFFIX = "Estimated Comparison Time: ";
    private final String ESTIMATED_TIME_SUCCESS_SUFFIX = " seconds.";
    private final String ESTIMATED_TIME_FAILURE_SUFFIX = " Impossible to calculate Comparison Time.";

    private final String qAScanPath;
    private final String referenceScanPath;

    private final String qaDatabaseFilePath;
    private final String referenceDatabaseFilePath;

    private final ScanProperties qaScanProperties;
    private final ScanProperties referenceScanProperties;

    private final String qaEstimatedComparisonTime;
    private final String referenceEstimatedComparisonTime;

    public ComparisonTimeEstimater(String qaScanPropertiesDescription, String referenceScanPropertiesDescription) {
        qAScanPath = qaScanPropertiesDescription.split(" ")[0];
        referenceScanPath = referenceScanPropertiesDescription.split(" ")[0];

        qaDatabaseFilePath = qAScanPath + File.separator + SharedConstants.SCAN_INFO_FILENAME;
        referenceDatabaseFilePath = referenceScanPath + File.separator + SharedConstants.SCAN_INFO_FILENAME;

        qaScanProperties = new ScanPropertiesReader(qaDatabaseFilePath).findScanProperties();
        referenceScanProperties = new ScanPropertiesReader(referenceDatabaseFilePath).findScanProperties();

        qaEstimatedComparisonTime = qaScanProperties.getEstimatedComparisonTime();
        referenceEstimatedComparisonTime = referenceScanProperties.getEstimatedComparisonTime();
    }

    public String getEstimatedComparisonTime() {
        if(isPossibleToCalculate()) return ESTIMATED_TIME_PREFFIX + calculateEstimatedComparisonTime() + ESTIMATED_TIME_SUCCESS_SUFFIX;
        return ESTIMATED_TIME_PREFFIX + ESTIMATED_TIME_FAILURE_SUFFIX;
    }

    private boolean isPossibleToCalculate() {
        return StringUtils.isNumeric(qaEstimatedComparisonTime) && StringUtils.isNumeric(referenceEstimatedComparisonTime);
    }

    private int calculateEstimatedComparisonTime() {
        Integer qaParsedEstimatedComparisonTime = Integer.parseInt(qaEstimatedComparisonTime);
        Integer referenceParsedEstimatedComparisonTime = Integer.parseInt(referenceEstimatedComparisonTime);
        return (qaParsedEstimatedComparisonTime + referenceParsedEstimatedComparisonTime) / 2;
    }
}
