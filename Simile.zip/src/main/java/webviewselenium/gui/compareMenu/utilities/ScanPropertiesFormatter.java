package webviewselenium.gui.compareMenu.utilities;

import org.apache.commons.lang3.StringUtils;
import webviewselenium.bookProperties.ScanProperties;
import webviewselenium.constans.SharedConstants;
import webviewselenium.parsers.xml.scanProperties.ScanPropertiesReader;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

public class ScanPropertiesFormatter {
    private Pattern NUMBER_PATTERN = Pattern.compile(
            SharedConstants.NAME_OF_DIRECTORY_THAT_CONTAINS_SCANS + File.separator + "\\d+");

    public List<String> getAllFormattedBooksScanProperties() {
        List<ScanProperties> allBooksScanProperties = findAllBooksScanProperties();
        List<String> allFormattedBooksScanProperties = new ArrayList<>();

        allBooksScanProperties.stream().forEach(scanProperties -> {
            allFormattedBooksScanProperties.add(getFormattedScanProperties(scanProperties));
        });

        return allFormattedBooksScanProperties;
    }

    public List<String> getAllFormattedBooksScanPropertiesExcludingProvidedScanProperties(String scanPropertiesDescription) {
        // Splitted Scan Properties: [0] -> Path, [1] -> Title, [2] -> Server, [3] -> Note, [4] -> Date
        String[] splittedScanProperties = scanPropertiesDescription.split("\\s{2,}");
        String selectedScanPath = splittedScanProperties[0];
        String selectedScanTitle = splittedScanProperties[1];

        return getAllFormattedBooksScanProperties().stream()
                .filter(formattedScanProperties -> !formattedScanProperties.contains(selectedScanPath + " "))
                .filter(formattedScanProperties -> formattedScanProperties.contains(selectedScanTitle + " "))
                .collect(Collectors.toList());
    }

    private List<ScanProperties> findAllBooksScanProperties() {
        List<String> allScanDirectoriesInDatabase = findAllScanDirectoriesInDatabase();
        List<ScanProperties> allBooksScanProperties = new ArrayList<>();

        allScanDirectoriesInDatabase.forEach(scanDirectory -> {
            ScanPropertiesReader scanPropertiesReader = new ScanPropertiesReader(scanDirectory +
                    File.separator + SharedConstants.SCAN_INFO_FILENAME);
            allBooksScanProperties.add(scanPropertiesReader.findScanProperties());
        });

        return allBooksScanProperties;
    }

    private List<String> findAllScanDirectoriesInDatabase() {
        File databaseDirectory = new File(SharedConstants.NAME_OF_DIRECTORY_THAT_CONTAINS_SCANS);
        List<File> allFilesInDatabaseDirectory = Arrays.stream(databaseDirectory.listFiles()).collect(Collectors.toList());

        return allFilesInDatabaseDirectory.stream()
                .map(file -> file.getPath())
                .filter(path -> isScanDirectory(path))
                .collect(Collectors.toList());
    }

    private boolean isScanDirectory(String pathToDirectoryThatShouldBeVerified) {
        return NUMBER_PATTERN.matcher(pathToDirectoryThatShouldBeVerified).matches();
    }

    private String getFormattedScanProperties(ScanProperties scanProperties) {
        return formatDirectoryProperty(scanProperties.getDirectoryIndex()) + StringUtils.repeat(" ", 15) +
                formatTitleProperty(scanProperties.getTitle()) + StringUtils.repeat(" ", 24) +
                formatServerProperty(scanProperties.getServer())  + StringUtils.repeat(" ", 37) +
                formatNoteProperty(scanProperties.getNote())  + StringUtils.repeat(" ", 32) +
                formatDateProperty(scanProperties.getCreationDate());
    }

    private String formatDirectoryProperty(String directoryIndex) {
        final int SCAN_DIRECTORY_NAME_LENGTH = SharedConstants.NAME_OF_DIRECTORY_THAT_CONTAINS_SCANS.length();
        final int FILE_SEPARATOR_LENGTH = File.separator.length();
        final int DIRECTORY_INDEX_MAX_LENGTH = 35;
        final int DIRECTORY_PROPERTY_MAX_LENGTH = SCAN_DIRECTORY_NAME_LENGTH + FILE_SEPARATOR_LENGTH + DIRECTORY_INDEX_MAX_LENGTH;

        String directoryProperty = SharedConstants.NAME_OF_DIRECTORY_THAT_CONTAINS_SCANS + File.separator + directoryIndex;
        directoryProperty = getValidatedTextAccordingToLength(directoryProperty, DIRECTORY_PROPERTY_MAX_LENGTH);
        directoryProperty = getValidatedTextAccordingToWhitespacesAtTheEnd(directoryProperty, DIRECTORY_PROPERTY_MAX_LENGTH);
        return directoryProperty;
    }

    private String formatTitleProperty(String title) {
        final int TITLE_MAX_LENGTH = 40;

        title = getValidatedTextAccordingToLength(title, TITLE_MAX_LENGTH);
        title = getValidatedTextAccordingToWhitespacesAtTheEnd(title, TITLE_MAX_LENGTH);
        return title;
    }

    private String formatServerProperty(String server) {
        final int SERVER_MAX_LENGTH = 20;

        server = getValidatedTextAccordingToLength(server, SERVER_MAX_LENGTH);
        server = getValidatedTextAccordingToWhitespacesAtTheEnd(server, SERVER_MAX_LENGTH);
        return server;
    }

    private String formatNoteProperty(String note) {
        final int NOTE_MAX_LENGTH = 40;

        note = getValidatedTextAccordingToLength(note, NOTE_MAX_LENGTH);
        note = getValidatedTextAccordingToWhitespacesAtTheEnd(note, NOTE_MAX_LENGTH);
        return note;
    }

    private String formatDateProperty(String date) {
        final int DATE_MAX_LENGTH = 10;

        date = validateDatePattern(date);
        date = getValidatedTextAccordingToLength(date, DATE_MAX_LENGTH);
        date = getValidatedTextAccordingToWhitespacesAtTheEnd(date, DATE_MAX_LENGTH);
        return date;
    }

    private String validateDatePattern(String date) {
        // To remove hours from the date property replacement should be run 3 times.
        for(int i = 0; i < 3; i++) {
            date = date.replaceFirst("\\d+\\.", "");
        }
        return date;
    }

    private String getValidatedTextAccordingToLength(String textToValidate, int maxLength) {
        if(textToValidate.length() > maxLength) {
            textToValidate = textToValidate.substring(0, maxLength - 3);
            textToValidate += "...";
            return textToValidate;
        }
        return textToValidate;
    }

    private String getValidatedTextAccordingToWhitespacesAtTheEnd(String textToValidate, int maxLength) {
        StringBuilder validatedText = new StringBuilder(textToValidate);
        String whitespaces = StringUtils.repeat(" ", maxLength - textToValidate.length());
        return validatedText.append(whitespaces).toString();
    }
}
