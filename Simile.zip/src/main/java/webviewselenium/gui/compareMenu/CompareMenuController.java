package webviewselenium.gui.compareMenu;

import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.concurrent.Task;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Cursor;
import javafx.scene.control.*;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import org.apache.commons.io.FileUtils;
import webviewselenium.bookProperties.BookProperties;
import webviewselenium.bookProperties.ScanProperties;
import webviewselenium.compareImages.CompareImages;
import webviewselenium.compareImages.database.FileExplorer;
import webviewselenium.constans.ConstantMessages;
import webviewselenium.constans.SimileContext;
import webviewselenium.fileUtilities.FileDeleter;
import webviewselenium.fileUtilities.ImageFinder;
import webviewselenium.gui.StageManager;
import webviewselenium.gui.chooseBookMenu.BookChooser;
import webviewselenium.gui.chooseBookMenu.BookChooserImpl;
import webviewselenium.gui.chooseBookMenu.books.ScannedBookProperties;
import webviewselenium.gui.chooseBookMenu.utilities.ImageSpliter;
import webviewselenium.gui.chooseBookMenu.utilities.SplittedImageDeleter;
import webviewselenium.gui.chooseBookMenu.utilities.SubchapterFinder;
import webviewselenium.gui.compareBookMenu.CompareBookController;
import webviewselenium.gui.compareMenu.utilities.ComparisonTimeEstimater;
import webviewselenium.gui.compareMenu.utilities.ScanPropertiesFormatter;
import webviewselenium.gui.utilities.ApplicationProperties;
import webviewselenium.parsers.xml.UpdateXmlBookPropertiesImpl;
import webviewselenium.parsers.xml.scanProperties.ScanPropertiesReader;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.*;
import java.util.stream.Collectors;

public class CompareMenuController implements Initializable, ApplicationProperties {
    @FXML private Button compareMenuButton;
    @FXML private ComboBox<String> qaBookComboBox;
    @FXML private ComboBox<String> referenceBookComboBox;
    @FXML private TextArea comparisonInformationTextArea;
    @FXML private ProgressIndicator comparisonProgressIndicator;
    @FXML private Button compareButton;
    @FXML private Text versionLabelText;

    private Stage currentSceneWindowStage;
    private StageManager stageManager;

    private ScanPropertiesFormatter scanPropertiesFormatter;
    private ComparisonTimeEstimater comparisonTimeEstimater;
    private List<String> allFormattedBooksScanProperties;

    private boolean isComparisonDone = false;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        scanPropertiesFormatter = new ScanPropertiesFormatter();

        initializeApplicationVersionLabel(versionLabelText);
        initializeQABookComboBox();
        initializeStylesheets();
    }

    /**
     * Method allows to initialize ComboBox that stores all books that can be selected as a QA Book.
     */
    private void initializeQABookComboBox() {
        qaBookComboBox.getItems().clear();
        allFormattedBooksScanProperties = scanPropertiesFormatter.getAllFormattedBooksScanProperties();
        allFormattedBooksScanProperties.forEach(qaBookComboBox.getItems()::add);
    }

    /**
     * Method allows to initialize stylesheets of the GUI components.
     */
    private void initializeStylesheets() {
        comparisonProgressIndicator.setStyle("-fx-progress-color: #440046;");
    }

    @FXML
    void goToSeeResultsMenu() {
        if(isComparisonDone && listOfResultantImagesSize > 0) {
            CompareBookController compareBookController = new CompareBookController(
                    listOfResultantImages,
                    listOfTemplateImages,
                    bookProperties,
                    referenceBookProperties
            );
            initializeStageManager();
            stageManager.closeCurrentWindow(compareButton);
            compareBookController.showStage();
        } else {
            showNoDifferencesFoundAlert();
        }
    }

    @FXML
    void goToMyLibraryMenu() {
        initializeStageManager();
        stageManager.showMyLibraryMenu();
        stageManager.closeCurrentWindow(stageManager.getStage());
    }

    @FXML
    void goToCompareMenu() {
        initializeStageManager();
        stageManager.showCompareMenu();
        stageManager.closeCurrentWindow(stageManager.getStage());
    }

    @FXML
    void goToGenerateIssueMenu() {
        initializeStageManager();
        stageManager.showGenerateIssueMenu();
        stageManager.closeCurrentWindow(stageManager.getStage());
    }

    private void initializeStageManager() {
        if(currentSceneWindowStage == null) currentSceneWindowStage = (Stage) compareMenuButton.getScene().getWindow();
        if(stageManager == null) stageManager = new StageManager(currentSceneWindowStage);
    }

    @FXML
    void qaBookHasBeenSelected() {
        removeAllElementsFromReferenceComboBox();
        SplittedImageDeleter splittedImageDeleter = new SplittedImageDeleter();
        String qAScanPath = qaBookComboBox.getSelectionModel().getSelectedItem().split(" ")[0];
        List<String> splittedImagesFromQADirectory = splittedImageDeleter.findAllSplittedImages(qAScanPath);
        splittedImageDeleter.removeAllSplittedImages(splittedImagesFromQADirectory);
        fillReferenceComboBoxWithFormattedScanPropertiesExcludingAlreadySelectedBook();
        clearComparisonInformationTextArea();
    }

    private void removeAllElementsFromReferenceComboBox() {
        referenceBookComboBox.getItems().clear();
    }

    private void fillReferenceComboBoxWithFormattedScanPropertiesExcludingAlreadySelectedBook() {
        String selectedScanDescription = qaBookComboBox.getSelectionModel().getSelectedItem();
        scanPropertiesFormatter.getAllFormattedBooksScanPropertiesExcludingProvidedScanProperties(selectedScanDescription)
                .forEach(referenceBookComboBox.getItems()::add);
    }

    private void clearComparisonInformationTextArea() {
        comparisonInformationTextArea.setText("");
    }

    @FXML
    void referenceBookHasBeenSelected() {
        updateComparisonInformationTextArea();

        String qAScanPath = qaBookComboBox.getSelectionModel().getSelectedItem().split(" ")[0];
        String referenceScanPath = referenceBookComboBox.getSelectionModel().getSelectedItem().split(" ")[0];
        SplittedImageDeleter splittedImageDeleter = new SplittedImageDeleter();
        List<String> splittedImagesFromQADirectory = splittedImageDeleter.findAllSplittedImages(qAScanPath);
        splittedImageDeleter.removeAllSplittedImages(splittedImagesFromQADirectory);
        List<String> splittedImagesFromReferenceDirectory = splittedImageDeleter.findAllSplittedImages(referenceScanPath);
        splittedImageDeleter.removeAllSplittedImages(splittedImagesFromReferenceDirectory);
    }

    private void updateComparisonInformationTextArea() {
        StringBuilder overall = new StringBuilder();
        String qAScanPath = qaBookComboBox.getSelectionModel().getSelectedItem().split(" ")[0];
        String referenceScanPath = referenceBookComboBox.getSelectionModel().getSelectedItem().split(" ")[0];
        ScannedBookProperties qaBook = new ScannedBookProperties(qAScanPath);
        ScannedBookProperties refBook = new ScannedBookProperties(referenceScanPath);

        List<String> qaUniqueSubchapters = new ArrayList<>();
        List<String> refUniqueSubchapters = new ArrayList<>();

        qaBook.getImages().forEach(image -> {
            qaUniqueSubchapters.add(image.substring(image.lastIndexOf("pages+") + 6));
        });

        refBook.getImages().forEach(image -> {
            refUniqueSubchapters.add(image.substring(image.lastIndexOf("pages+") + 6));
        });

        List<String> qaUniqueSubchapters2 = new ArrayList<>();
        List<String> refUniqueSubchapters2 = new ArrayList<>();

        qaUniqueSubchapters2 = qaUniqueSubchapters.stream()
                .filter(x -> !refUniqueSubchapters.contains(x))
                .collect(Collectors.toList());

        refUniqueSubchapters2 = refUniqueSubchapters.stream()
                .filter(x -> !qaUniqueSubchapters.contains(x))
                .collect(Collectors.toList());

        StringBuilder qa = new StringBuilder("Additional subchapters in QA:\n");
        qaUniqueSubchapters2.forEach(chapter -> {
            qa.append(chapter.replaceAll(".png", "") + "\n");
        });

        StringBuilder ref = new StringBuilder("Missing subchapters in QA:\n");
        refUniqueSubchapters2.forEach(chapter -> {
            ref.append(chapter.replaceAll(".png", "") + "\n");
        });

        qa.append("\n"); ref.append("\n");
        overall.append(qa.toString());
        overall.append(ref.toString());

        StringBuilder updatedComparisonInformation = new StringBuilder();
        updatedComparisonInformation.append(calculateComparisonTime());

        overall.append(updatedComparisonInformation.toString());
        comparisonInformationTextArea.setText(overall.toString());
    }

    private String calculateComparisonTime() {
        String qASelectedScanDescription = qaBookComboBox.getSelectionModel().getSelectedItem();
        String referenceSelectedScanDescription = referenceBookComboBox.getSelectionModel().getSelectedItem();

        comparisonTimeEstimater = new ComparisonTimeEstimater(qASelectedScanDescription, referenceSelectedScanDescription);
        return comparisonTimeEstimater.getEstimatedComparisonTime();
    }

    private Task progressTask;
    private static List<String> listOfScannedImages;
    private static List<String> listOfTemplateImages;
    private static List<String> listOfResultantImages;
    private static int listOfScannedImagesSize;
    private static int listOfTemplateImagesSize;
    private static int listOfResultantImagesSize;

    String pathToQABookDirectory = "";
    String qaBookDirectoryIndex = "";
    String pathToSelectedQABookDirectory = "";

    String pathToReferenceBookDirectory = "";
    String referenceBookDirectoryIndex = "";
    String pathToSelectedReferenceBookDirectory = "";

    private BookChooser bookChooser = new BookChooserImpl();
    private BookProperties bookProperties;
    private BookProperties referenceBookProperties;

    private SubchapterFinder subchapterFinder;

    public Task createProgressTask() {
        return new Task() {
            @Override
            protected Object call() throws Exception {
                comparisonProgressIndicator.setVisible(true);
                compareMenuButton.setDisable(true);
                compareButton.setDisable(true);
                isComparisonDone = false;

                // Run ProgressBar
                updateProgress(0, -1);
                listOfResultantImagesSize = 0; //???

                // Get properties of the scanned books
                String qAScanPath = qaBookComboBox.getSelectionModel().getSelectedItem().split(" ")[0];
                String referenceScanPath = referenceBookComboBox.getSelectionModel().getSelectedItem().split(" ")[0];
                ScannedBookProperties qaBook = new ScannedBookProperties(qAScanPath);
                ScannedBookProperties refBook = new ScannedBookProperties(referenceScanPath);

                // Get full paths to images from QA Book and Reference Book
                qaBook.setImages(FileExplorer.findAllPNGs(qaBook.getScanPath(), qaBook.getScanPath().getPath()));
                refBook.setImages(FileExplorer.findAllPNGs(refBook.getScanPath(), refBook.getScanPath().getPath()));

                // Delete chapters that are not common to both books
                qaBook.setSubchapters(qaBook.removeDifferentRexSubchapters(refBook.getRexSubchapters()));
                refBook.setSubchapters(refBook.removeDifferentRexSubchapters(qaBook.getRexSubchapters()));

                // Delete paths that are not contain common subchapters
                qaBook.setImages(qaBook.removeUnusedRexPaths(refBook.getRexSubchapters()));
                refBook.setImages(refBook.removeUnusedRexPaths(qaBook.getRexSubchapters()));

                qaBook.setNumberOfScansInPath(qaBook.getImages().size());
                refBook.setNumberOfScansInPath(refBook.getImages().size());

                // Delete all files from ScanDB/Results directory
                try {
                    FileUtils.cleanDirectory(new File("ScanDB/Results"));
                } catch (IOException e) {
                    e.printStackTrace();
                }

                long comparisionStartTime = System.currentTimeMillis();

                System.out.println(("----------------------------------"));
                System.out.println(("Comparison Process is starting..."));

                // Compare QA Book and Reference Book
                for (int i = 0; i < qaBook.getImages().size(); i++) {
                    String pathToResultantImage = refBook.getImages().get(i).replace(refBook.getScanPath().getPath(), "ScanDB/Results");

                    System.out.println(("----------------------------------"));
                    System.out.println(("\tProgress: " + (i+1) + "/" + qaBook.getImages().size()));
                    System.out.println(("\tQA: " + qaBook.getImages().get(i)));
                    System.out.println(("\tREF: " + refBook.getImages().get(i)));
                    System.out.println(("\tRES: " + pathToResultantImage));

                    CompareImages.deepCompreImages(qaBook.getImages().get(i), refBook.getImages().get(i), pathToResultantImage);
                    updateProgress(i + 1, qaBook.getNumberOfScansInPath() + 1);
                    System.out.println(("DONE"));
                }

                long comparisionEndTime = System.currentTimeMillis();
                int current;
                try { current = Integer.parseInt(calculateComparisonTime()); } catch (Exception e) {current = 0;}

                int comparisionTime = (int) ((comparisionEndTime - comparisionStartTime) / 1000);
                if(current != 0) comparisionTime = (comparisionTime + current) / 2;

                ScanPropertiesReader qaScanPropertiesReader = new ScanPropertiesReader(qAScanPath + "/info.xml");
                ScanPropertiesReader refScanPropertiesReader = new ScanPropertiesReader(referenceScanPath + "/info.xml");
                ScanProperties qaScanProperties = qaScanPropertiesReader.findScanProperties();
                ScanProperties refScanProperties = refScanPropertiesReader.findScanProperties();

                SimileContext.bookTitle = qaScanProperties.getTitle();
                UpdateXmlBookPropertiesImpl updateXmlBookProperties = new UpdateXmlBookPropertiesImpl();
                updateXmlBookProperties.updateEstimatedTimeContent(
                        "ScanDB/" + qaScanProperties.getDirectoryIndex() + "/info.xml",
                        qaScanProperties.getTitle(),
                        Integer.toString(comparisionTime));
                updateXmlBookProperties.updateEstimatedTimeContent(
                        "ScanDB/" + refScanProperties.getDirectoryIndex() + "/info.xml",
                        qaScanProperties.getTitle(),
                        Integer.toString(comparisionTime));

                System.out.println(("----------------------------------"));
                System.out.println(("Comparison Process has finished..."));

                bookProperties = new BookProperties.Builder()
                        .bookTitle(qaScanProperties.getTitle())
                        .commitName(qaScanProperties.getNote())
                        .branchName("")
                        .serverName(qaScanProperties.getServer())
                        .date(qaScanProperties.getCreationDate())
                        .avgTime(qaScanProperties.getEstimatedComparisonTime())
                        .pathToImage("ScanDB/" + qaScanProperties.getDirectoryIndex())
                        .build();

                referenceBookProperties = new BookProperties.Builder()
                        .bookTitle(refScanProperties.getTitle())
                        .commitName(refScanProperties.getNote())
                        .branchName("")
                        .serverName(refScanProperties.getServer())
                        .date(refScanProperties.getCreationDate())
                        .avgTime(refScanProperties.getEstimatedComparisonTime())
                        .pathToImage("ScanDB/" + refScanProperties.getDirectoryIndex())
                        .build();

                // Find resultant images
                ImageFinder imageFinder = new ImageFinder.ImageFinderBuilder("ScanDB/Results").build();
                List<String> resultantImages = imageFinder.findPathsToImages();

                ImageSpliter imageSpliter = new ImageSpliter(1500);
                // Split resultant images into smaller pieces
                System.out.println("----------------------------------");
                System.out.println("QA Splitting Process is starting...");
                imageSpliter.splitImages(resultantImages.stream()
                        .map(image -> new File("ScanDB/Results" + File.separator + image))
                        .collect(Collectors.toList()));
                System.out.println("----------------------------------");
                System.out.println("QA Splitting Process has finished...");
                // Remove original resultant images
                FileDeleter.deleteFiles(resultantImages.stream()
                        .map(image -> "ScanDB/Results" + File.separator + image)
                        .collect(Collectors.toList()));
                // Split reference images into smaller pieces
                System.out.println("----------------------------------");
                System.out.println("REF Splitting Process is starting...");
                imageSpliter.splitImages(resultantImages.stream()
                        .map(image -> new File(refBook.getScanPath().getPath() + File.separator + image))
                        .collect(Collectors.toList()));
                System.out.println("----------------------------------");
                System.out.println("REF Splitting Process has finished...");

                // Create list of resultant images and their reference images
                listOfResultantImages = imageFinder.findPathsToImages().stream()
                        .map(image -> "ScanDB/Results" + File.separator + image)
                        .collect(Collectors.toList());
                listOfTemplateImages = listOfResultantImages.stream()
                        .map(image -> image.replace("ScanDB/Results", refBook.getScanPath().getPath()))
                        .collect(Collectors.toList());

                SplittedImageDeleter splittedImageDeleter = new SplittedImageDeleter();
                splittedImageDeleter.removeUnusedSplittedImagesinComparision(listOfResultantImages, refBook.getScanIndex());

                // Create list of resultant images and their reference images
                listOfResultantImages = imageFinder.findPathsToImages().stream()
                        .map(image -> "ScanDB/Results" + File.separator + image)
                        .collect(Collectors.toList());
                listOfTemplateImages = listOfResultantImages.stream()
                        .map(image -> image.replace("ScanDB/Results", refBook.getScanPath().getPath()))
                        .collect(Collectors.toList());

                listOfResultantImagesSize = listOfResultantImages.size();

                updateProgress(1, 1);

                compareMenuButton.setCursor(Cursor.HAND);

                compareButton.setDisable(false);
                compareMenuButton.setDisable(false);
                isComparisonDone = true;
                Thread.sleep(1000);

                return true;
            }
        };
    }

    @FXML
    void runComparisonProcess() {
        progressTask = createProgressTask();
        comparisonProgressIndicator.progressProperty().unbind();
        comparisonProgressIndicator.progressProperty().bind(progressTask.progressProperty());
        progressTask.messageProperty().addListener(new ChangeListener<String>() {
            public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
            }
        });
        new Thread(progressTask).start();
    }

    private void showNoDifferencesFoundAlert() {
        Alert differencesNotFoundAlert = new Alert(Alert.AlertType.INFORMATION);
        differencesNotFoundAlert.setTitle(ConstantMessages.informationHeader);
        differencesNotFoundAlert.setHeaderText(ConstantMessages.noDifferencesAfterComparisionMessage);
        differencesNotFoundAlert.showAndWait();
    }
}
