package webviewselenium.gui.scanMenu;

import javafx.concurrent.Task;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.text.Text;

import webviewselenium.bookProperties.tableOfContents.ToCComponentProperties;
import webviewselenium.bookProperties.tableOfContents.ToCComponentsTypes;
import webviewselenium.bookScan.FolderManager;
import webviewselenium.bookScan.cnxBookScanner.CnxBookScanner;
import webviewselenium.constans.ConstantFXMLPaths;
import webviewselenium.constans.SharedConstants;
import webviewselenium.gui.ApplicationLoader;

import webviewselenium.gui.StageManager;
import webviewselenium.gui.utilities.ApplicationProperties;
import webviewselenium.gui.utilities.TableViewUtilitiesTableOfContents;
import webviewselenium.parsers.json.TableOfContentsParser;
import webviewselenium.parsers.json.TableOfContentsWriter;

import java.io.*;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

public class ScanMenuController implements Initializable, ApplicationProperties {
    @FXML private Button collectionMenuButton;
    @FXML private Button scanMenuButton;
    @FXML private Button myLibraryMenuButton;
    @FXML private Button compareMenuButton;
    @FXML private Button generateIssueMenuButton;
    @FXML private Text versionLabelText;
    @FXML private TextField urlTextField;
    @FXML private TableView<ToCComponentProperties> tableOfContentsTableView;
    @FXML private TableColumn<ToCComponentProperties, String> chapterTableColumn;
    @FXML private Button selectAllChaptersButton;
    @FXML private TextArea noteTextField;
    @FXML private ProgressBar scanProgressBar;
    @FXML private Button scanButton;

    private TableViewUtilitiesTableOfContents tableViewUtilitiesTableOfContents;
    private TableOfContentsParser tableOfContentsParser;
    private CnxBookScanner cnxBookScanner;
    private Task<Object> progressTask;
    private StageManager stageManager;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        tableViewUtilitiesTableOfContents = new TableViewUtilitiesTableOfContents(tableOfContentsTableView);
        tableViewUtilitiesTableOfContents.setSelectionModeToMultiple();
        chapterTableColumn.setCellValueFactory(new PropertyValueFactory<>(SharedConstants.nameOfVariableThatConstitutesColumn));
        scanProgressBar.setStyle("-fx-accent: #440045;");
        tableOfContentsParser = new TableOfContentsParser(SharedConstants.WORKSPACE_TOC_JSON_PATH);
        cnxBookScanner = new CnxBookScanner();
        versionLabelText.setText(ApplicationLoader.getCurrentVersion());
        stageManager = new StageManager();

        initializeApplicationVersionLabel(versionLabelText);
        addListenerToUrlTextField();
    }

    @FXML
    void goToCompareMenu() {
        stageManager.closeCurrentWindow(compareMenuButton);
        stageManager.showStage(ConstantFXMLPaths.compareMenu);
    }

    @FXML
    void goToGenerateIssueMenu() {
        stageManager.closeCurrentWindow(myLibraryMenuButton);
        stageManager.showStage(ConstantFXMLPaths.generateIssueMenu);
    }

    @FXML
    void goToMyLibraryMenu() {
        stageManager.closeCurrentWindow(myLibraryMenuButton);
        stageManager.showStage(ConstantFXMLPaths.collectionMenu);
    }

    @FXML
    void goToScanMenu() {
        stageManager.closeCurrentWindow(scanMenuButton);
        stageManager.showStage(ConstantFXMLPaths.scanMenu);
    }

    @FXML
    void selectOrClearAllChaptersButton() {
        tableViewUtilitiesTableOfContents.selectOrClearAllElementsToSetOppositeState();
    }

    @FXML
    void tocTableViewContentClicked() {
        List<Integer> childIndexes = new ArrayList<>();

        int focusedCellIndex = tableOfContentsTableView.getFocusModel().getFocusedIndex();
        if(tableOfContentsTableView.getItems().get(focusedCellIndex).getComponentType() == ToCComponentsTypes.chapter) {
            String chapterNumber = findChapterNumber(tableOfContentsTableView.getItems().get(focusedCellIndex).getComponentTitle().trim());

            for(int i = 0; i < tableOfContentsTableView.getItems().size(); i++) {
                String actualChaptersUrl = tableOfContentsTableView.getItems().get(i).getComponentUrl();
                if(actualChaptersUrl.contains("pages/" + chapterNumber + "-"))
                    childIndexes.add(i);
            }
        }
        childIndexes.forEach(childIndex -> tableOfContentsTableView.getSelectionModel().select(childIndex));
    }

    private String findChapterNumber(String chapterName) {
        Pattern pattern = Pattern.compile("^\\d+");
        Matcher matcher = pattern.matcher(chapterName);
        return matcher.find() ? matcher.group() : "";
    }

    @FXML
    void runScanningProcess()  {
        progressTask = createProgressTask();
        scanProgressBar.progressProperty().unbind();
        scanProgressBar.progressProperty().bind(progressTask.progressProperty());
        progressTask.messageProperty().addListener((observable, oldValue, newValue) -> {});
        new Thread(progressTask).start();
    }

    public Task<Object> createProgressTask() {
        return new Task<Object>() {
            @Override
            protected Object call() throws Exception {
                updateProgress(0, -1);

                String noteContent = noteTextField.getText().length() == 0 ? " " : noteTextField.getText();
                String pathScanDirectory = FolderManager.createDirectoryThatContainsScans(tableOfContentsParser.getBookTitle(), noteContent, tableOfContentsParser.getServerName());
                FolderManager.handleUsedTableOfContentsJsonFile(pathScanDirectory);

                if (tableViewUtilitiesTableOfContents.areAllItemsSelected()) {
                    cnxBookScanner.addScanFromUrlParameter(urlTextField.getText());
                } else {
                    TableOfContentsWriter tableOfContentsWriter = new TableOfContentsWriter();
                    tableOfContentsWriter.createCustomScanTableOfContentsJson(SharedConstants.WORKSPACE_CUSTOM_TOC_JSON_PATH, tableOfContentsParser.getBookTitle(), tableOfContentsTableView.getItems().stream().collect(Collectors.toList()), new ArrayList<>(tableOfContentsTableView.getSelectionModel().getSelectedCells()));
                    cnxBookScanner.addScanFromTocParameter(".." + File.separator + SharedConstants.WORKSPACE_CUSTOM_TOC_JSON_PATH);
                }
                cnxBookScanner.addPathParameter(".." + File.separator + pathScanDirectory);
                cnxBookScanner.runCommand();

                updateProgress(1, 1);
                return true;
            }
        };
    }

    private void addListenerToUrlTextField() {
        urlTextField.textProperty().addListener((observable, newValue, oldValue) -> {
            cnxBookScanner.addScanFromUrlParameter(oldValue);
            cnxBookScanner.addPathParameter(".." + File.separator + SharedConstants.NAME_OF_DIRECTORY_THAT_CONTAINS_SCANS);
            cnxBookScanner.addOnlyToCParameter();
            try { cnxBookScanner.runCommand(); }
            catch (IOException | InterruptedException e) { e.printStackTrace(); }
            tableViewUtilitiesTableOfContents.clearContent();
            tableViewUtilitiesTableOfContents.addComponentsToTableView(tableOfContentsParser.getParsedComponents());
            tableOfContentsParser.getBookTitle();
        });
    }
}
