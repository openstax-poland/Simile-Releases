package webviewselenium.gui.utilities;

import javafx.scene.control.SelectionMode;
import javafx.scene.control.TableView;
import webviewselenium.bookProperties.tableOfContents.ToCComponentProperties;

/**
 * Class is the basis for classes which handle TableView elements.
 * As it is not expected to create an instance of this class - constructor visibility should remain 'protected'.
 */
public class TableViewUtilities {
    protected final TableView<ToCComponentProperties> tableView;

    protected TableViewUtilities(TableView<ToCComponentProperties> tableView) {
        this.tableView = tableView;
    }

    public void setSelectionModeToMultiple() {
        tableView.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
    }

    public void selectOrClearAllElementsToSetOppositeState() {
        TableView.TableViewSelectionModel<?> tableViewSelectionModel = tableView.getSelectionModel();
        if (tableViewSelectionModel.isEmpty()) tableViewSelectionModel.selectAll();
        else tableViewSelectionModel.clearSelection();
    }

    public void clearContent() {
        tableView.getItems().clear();
    }

    public boolean areAllItemsSelected() {
        return tableView.getItems().size() == tableView.getSelectionModel().getSelectedItems().size();
    }
}
