package webviewselenium.gui.collectionMenu;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.text.Text;
import javafx.stage.DirectoryChooser;
import javafx.stage.Stage;
import webviewselenium.bookProperties.ScanProperties;
import webviewselenium.constans.ConstantFXMLPaths;
import webviewselenium.constans.SharedConstants;
import webviewselenium.constans.SimileContext;
import webviewselenium.fileUtilities.ScanDirectoryFinder;
import webviewselenium.fileUtilities.ScanDirectoryImporter;
import webviewselenium.gui.StageManager;
import webviewselenium.gui.utilities.ApplicationProperties;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

public class CollectionMenuController implements Initializable, ApplicationProperties {
    @FXML private Button collectionMenuButton;
    @FXML private Button scanMenuButton;
    @FXML private Button myLibraryMenuButton;
    @FXML private Button compareMenuButton;
    @FXML private Button generateIssueMenuButton;
    @FXML private Button importButton;
    @FXML private Text versionLabelText;
    @FXML private Text noBooksInCollectionText;
    @FXML private TableView<ScanProperties> availableBooksTableView;
    @FXML private TableColumn<ScanProperties, String> folderColumn;
    @FXML private TableColumn<ScanProperties, String> titleColumn;
    @FXML private TableColumn<ScanProperties, String> serverColumn;
    @FXML private TableColumn<ScanProperties, String> noteColumn;
    @FXML private TableColumn<ScanProperties, String> dateColumn;

    private ScanDirectoryFinder scanDirectoryFinder;
    private ScanDirectoryImporter scanDirectoryImporter;
    private StageManager stageManager;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        scanDirectoryFinder = new ScanDirectoryFinder();
        scanDirectoryImporter = new ScanDirectoryImporter();
        stageManager = new StageManager();

        initializeApplicationVersionLabel(versionLabelText);
        initializeTableColumnFactoryValues();
        initializeTableColumnStylesheets();
        refreshCollectionTableContent();
    }

    private void initializeTableColumnFactoryValues() {
        folderColumn.setCellValueFactory(new PropertyValueFactory<>(SharedConstants.FOLDER_COLUMN_VALUE_FACTORY));
        titleColumn.setCellValueFactory(new PropertyValueFactory<>(SharedConstants.TITLE_COLUMN_VALUE_FACTORY));
        serverColumn.setCellValueFactory(new PropertyValueFactory<>(SharedConstants.SERVER_COLUMN_VALUE_FACTORY));
        noteColumn.setCellValueFactory(new PropertyValueFactory<>(SharedConstants.NOTE_COLUMN_VALUE_FACTORY));
        dateColumn.setCellValueFactory(new PropertyValueFactory<>(SharedConstants.DATE_COLUMN_VALUE_FACTORY));
    }

    private void initializeTableColumnStylesheets() {
        folderColumn.setStyle( "-fx-alignment: CENTER;");
    }

    private void refreshCollectionTableContent() {
        availableBooksTableView.getItems().clear();
        initializeScansCollectionList();
        initializeCollectionTableContent();
    }

    private String validateDatePattern(String date) {
        // To remove hours from the date property replacement should be run 3 times.
        for(int i = 0; i < 3; i++) {
            date = date.replaceFirst("\\d+\\.", "");
        }
        return date;
    }

    private void initializeScansCollectionList() {
        List<ScanProperties> allScansInCollection = scanDirectoryFinder.getAllScansProperties(SharedConstants.NAME_OF_DIRECTORY_THAT_CONTAINS_SCANS);
        allScansInCollection.forEach(scanProperties -> {
            String formattedDate = validateDatePattern(scanProperties.getCreationDate());
            availableBooksTableView.getItems().add(
                    new ScanProperties(
                            scanProperties.getTitle(),
                            formattedDate,//scanProperties.getCreationDate(),
                            scanProperties.getNote(),
                            scanProperties.getServer(),
                            scanProperties.getEstimatedComparisonTime(),
                            scanProperties.getDirectoryIndex()
                    )
            );
        });
    }

    private void initializeCollectionTableContent() {
        if(availableBooksTableView.getItems().size() == 0) {
            availableBooksTableView.setVisible(false);
        } else {
            noBooksInCollectionText.setVisible(false);
        }
    }

    @FXML
    void goToCompareMenu() {
        stageManager.closeCurrentWindow(compareMenuButton);
        stageManager.showStage(ConstantFXMLPaths.compareMenu);
    }

    @FXML
    void goToGenerateIssueMenu() {
        stageManager.closeCurrentWindow(compareMenuButton);
        stageManager.showStage(ConstantFXMLPaths.generateIssueMenu);
    }

    @FXML
    void goToMyLibraryMenu() {
        stageManager.closeCurrentWindow(myLibraryMenuButton);
        stageManager.showStage(ConstantFXMLPaths.collectionMenu);
    }

    @FXML
    void goToBookDetailsMenu() {
        SimileContext.bookDirectoryIndex = availableBooksTableView.getSelectionModel().getSelectedItem().getDirectoryIndex();
        SimileContext.bookNote = availableBooksTableView.getSelectionModel().getSelectedItem().getNote();
        SimileContext.bookScanDate = availableBooksTableView.getSelectionModel().getSelectedItem().getCreationDate();

        stageManager.closeCurrentWindow(myLibraryMenuButton);
        stageManager.showStage(ConstantFXMLPaths.bookDetailsMenu);
    }

    @FXML
    void goToScanMenu() throws IOException {
        stageManager.closeCurrentWindow(scanMenuButton);
        stageManager.showStage(ConstantFXMLPaths.scanMenu);
    }

    @FXML
    void importBookButtonClicked() throws IOException, InterruptedException {
        scanDirectoryImporter.handleScanImport(getImportDirectoryPath(), SharedConstants.NAME_OF_DIRECTORY_THAT_CONTAINS_SCANS + File.separator);
        refreshCollectionTableContent();
    }

    private File getImportDirectoryPath() {
        DirectoryChooser directoryChooser = new DirectoryChooser();
        Stage stage = (Stage) importButton.getScene().getWindow();
        File chosenScanDirectory = directoryChooser.showDialog(stage);
        return chosenScanDirectory;
    }
}
