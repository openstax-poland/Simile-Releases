package webviewselenium.bookScan;

public class DirectoryManager {

	public String NewScanFolderSetup(String bookName, String bookID, String numberOfPages, String scanDate, String commitName, String branchname, String serverName) {
		
		return null;
	}

}
