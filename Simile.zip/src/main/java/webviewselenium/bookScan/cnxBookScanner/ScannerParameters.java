package webviewselenium.bookScan.cnxBookScanner;

/**
 * Class contains all possible parameters that can be assigned to
 * the command that starts cnx-book-scanner's script.
 */
public enum ScannerParameters {
    SCAN_FROM_URL(" --scan-from-url="),
    SCAN_FROM_TOC(" --scan-from-toc="),
    ONLY_TOC(" --only-toc"),
    PATH(" --path="),
    FILENAME(" --filename="),
    OPEN_TABS_LIMIT(" --open-tabs-limit="),
    WIDTH(" --width="),
    HEIGHT(" --height="),
    LOGGER(" --logger=");

    private String scanParameter;

    ScannerParameters(String scanParameter) {
        this.scanParameter = scanParameter;
    }

    public String getScanParameter() {
        return scanParameter;
    }
}
