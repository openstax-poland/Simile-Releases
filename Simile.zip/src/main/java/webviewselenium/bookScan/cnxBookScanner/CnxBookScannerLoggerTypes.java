package webviewselenium.bookScan.cnxBookScanner;

/**
 * Class contains all possible logger types that can be assigned to
 * the logger-type parameter in the cnx-book-scanner's script.
 */
public enum CnxBookScannerLoggerTypes {
    DEVELOPMENT("development"),
    PRODUCTION("production");

    private String loggerType;

    CnxBookScannerLoggerTypes(String loggerType) {
        this.loggerType = loggerType;
    }

    public String getLoggerType() {
        return loggerType;
    }
}
