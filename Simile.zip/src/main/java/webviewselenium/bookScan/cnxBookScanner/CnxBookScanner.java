package webviewselenium.bookScan.cnxBookScanner;

import webviewselenium.bashRunScripts.CommandsRunner;
import webviewselenium.constans.SharedConstants;

import java.io.IOException;

/**
 * Class contains methods that allow to start Scanning Process and manage its properties.
 * Scanning Process is handled by cnx-book-scanner, @see https://github.com/openstax-poland/cnx-books-scanner.
 */
public class CnxBookScanner {
    private StringBuilder yarnCommand;

    public CnxBookScanner() {
        resetYarnCommandContentToDefaultValue();
    }

    /**
     * Runs Scanning Process by calling cnx-book-scanner's script.
     * Keep in mind that method should be run once all needed parameters are set.
     *
     * @throws IOException if script cannot be run or script cannot read line from the Buffer
     * @throws InterruptedException if something interrupts waiting for the end of the script execution
     */
    public void runCommand() throws IOException, InterruptedException {
        CommandsRunner.runCommand(getYarnCommand());
        resetYarnCommandContentToDefaultValue();
    }

    /**
     * Resets the command's content to the default value.
     * Default value means that command's content has no additional parameters.
     */
    public void resetYarnCommandContentToDefaultValue() {
        final String defaultCommandContent = SharedConstants.DEFAULT_CNX_BOOK_SCANNER_COMMAND_CONTENT;
        this.yarnCommand = new StringBuilder(defaultCommandContent);
    }

    /**
     * Returns the current content of the created yarn command which is used to run Scanning Process.
     *
     * @return content of the created yarn command
     */
    public String getYarnCommand() {
        return yarnCommand.toString();
    }

    /**
     * Adds scan-from-url parameter to the yarn command.
     * It allows to scan the whole book from the provided url.
     *
     * @param url url to any page from a book that should be scanned as a whole
     */
    public void addScanFromUrlParameter(String url) {
        this.yarnCommand.append(ScannerParameters.SCAN_FROM_URL.getScanParameter()).append(url);
    }

    /**
     * Adds scan-from-toc parameter to the yarn command.
     * It allows to scan chosen pages from the book. Provided ToC file has to comply with cnx-book-scanner's requirements.
     *
     * @param tocPath path to the JSON file that contains information necessary to scan chosen pages
     */
    public void addScanFromTocParameter(String tocPath) {
        this.yarnCommand.append(ScannerParameters.SCAN_FROM_TOC.getScanParameter()).append(tocPath);
    }

    /**
     * Adds only-toc parameter to the yarn command.
     * It allows to scan only ToC of the chosen book. Keep in mind no content will be scanned in this case!
     */
    public void addOnlyToCParameter() {
        this.yarnCommand.append(ScannerParameters.ONLY_TOC.getScanParameter());
    }

    /**
     * Adds path parameter to the yarn command.
     * It allows to set the path to the directory that will store created scans.
     *
     * @param path path to the directory that will store created scans
     */
    public void addPathParameter(String path) {
        this.yarnCommand.append(ScannerParameters.PATH.getScanParameter()).append(path);
    }

    /**
     * Adds filename parameter to the yarn command.
     * It allows to set the filenames' pattern for the created scans.
     * More details about available patterns are available in the cnx-book-scanner's documentation.
     *
     * @param filename filenames' pattern for the created scans
     */
    public void addFilenameParameter(String filename) {
        this.yarnCommand.append(ScannerParameters.FILENAME.getScanParameter()).append(filename);
    }

    /**
     * Adds open-tabs-limit parameter to the yarn command.
     * It allows to set the limit of the open tabs which will be scanned in parallel.
     * Be careful, if too many tabs will be opened scans may not be correct!
     *
     * @param openTabsLimit the limit of the open tabs which will be scanned in parallel
     */
    public void addOpenTabsLimitParameter(String openTabsLimit) {
        this.yarnCommand.append(ScannerParameters.OPEN_TABS_LIMIT.getScanParameter()).append(openTabsLimit);
    }

    /**
     * Adds width parameter to the yarn command.
     * It allows to set the width for the created scans.
     * Be careful, if width will be too big - comparison process's results may not be correct!
     *
     * @param width width for the created scans
     */
    public void addWidthParameter(String width) {
        this.yarnCommand.append(ScannerParameters.WIDTH.getScanParameter()).append(width);
    }

    /**
     * Adds height parameter to the yarn command.
     * It allows to set the height for the created scans.
     * Be careful, if height will be too big - comparison process's results may not be correct!
     *
     * @param height height for the created scans
     */
    public void addHeightParameter(String height) {
        this.yarnCommand.append(ScannerParameters.HEIGHT.getScanParameter()).append(height);
    }

    /**
     * Adds logger parameter to the yarn command.
     * It allows to turn on/turn off some additional logged comments.
     * Those comments are useful for debugging purposes, but unnecessary for the end user.
     *
     * @param loggerType the type of the logs which will be shown in the terminal/written to the file
     */
    public void addLoggerParameter(CnxBookScannerLoggerTypes loggerType) {
        this.yarnCommand.append(ScannerParameters.LOGGER.getScanParameter()).append(loggerType.getLoggerType());
    }
}
