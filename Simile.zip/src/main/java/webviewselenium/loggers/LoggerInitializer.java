package webviewselenium.loggers;

import org.apache.log4j.Appender;
import org.apache.log4j.ConsoleAppender;
import org.apache.log4j.FileAppender;
import org.apache.log4j.Logger;
import org.apache.log4j.helpers.DateLayout;
import org.apache.log4j.spi.LoggingEvent;
import webviewselenium.constans.FormattedDates;
import webviewselenium.constans.SharedConstants;
import webviewselenium.gui.ApplicationLoader;

import java.io.File;
import java.io.IOException;

/**
 * Class contains methods that allow to create logger. As it was found as a useful feature,
 * we decided to print state logs both to the Console and to the File. As you want to find
 * the created log file follow the path described by loggerFilePath.
 */
public class LoggerInitializer {
	private final Logger logger;
	private final String loggerFilePath;

	public LoggerInitializer() {
		logger  = Logger.getLogger(ApplicationLoader.class);
		String loggerFilename = FormattedDates.getFormattedCurrentDatetime() + ".log";
		loggerFilePath = SharedConstants.fullNameOfDirectoryThatContainsLogs + File.separator + loggerFilename;
	}

	public Logger getInitializedLogger() {
		return initializeLogger();
	}

	public String getLoggerFilePath() {
		return loggerFilePath;
	}

	private Logger initializeLogger() {
		logger.addAppender(initializeFileAppender());
		logger.addAppender(initializeConsoleAppender());
		return logger;
	}

	private Appender initializeConsoleAppender() {
		return new ConsoleAppender(new DateLayout() {
			@Override
			public String format(LoggingEvent loggingEvent) {
				return getCustomLayout(loggingEvent);
			}

			@Override
			public boolean ignoresThrowable() {
				return false;
			}
		});
	}

	private Appender initializeFileAppender() {
		try {
			return new FileAppender(new DateLayout() {
				@Override
				public String format(LoggingEvent loggingEvent) {
					return getCustomLayout(loggingEvent);
				}

				@Override
				public boolean ignoresThrowable() {
					return false;
				}
			}, loggerFilePath);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}

	private String getCustomLayout(LoggingEvent loggingEvent) {
		return "[" + FormattedDates.getFormattedCurrentDatetime() + "]"
				+ " - " + loggingEvent.getLevel()
				+ " - " + loggingEvent.getMessage() + "\n";
	}
}
