package webviewselenium.structure;

import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import org.apache.log4j.Logger;
import webviewselenium.bashRunScripts.CommandsRunner;
import webviewselenium.constans.SharedConstants;
import webviewselenium.constans.SimileContext;
import webviewselenium.gui.ApplicationLoader;

import java.io.File;
import java.io.IOException;
import java.util.Optional;

/**
 * Class contains methods that allow to check the correctness of the Simile's structure.
 * When the necessary structure directory is missing - it is initialized.
 */
public class StructureInitializer {
    private static final Logger logger = ApplicationLoader.getLogger();
    private final File directoryThatContainsScans;
    private final File directoryThatContainsResultantImages;

    public StructureInitializer() {
        directoryThatContainsScans = new File(SharedConstants.fullNameOfDirectoryThatContainsScans);
        directoryThatContainsResultantImages = new File(SharedConstants.fullNameOfDirectoryThatContainsResultantImages);
    }

    public void initializeDirectoryStructure() {
        if(!doesDirectoryExist(directoryThatContainsScans)) {
            logger.info("Initializing directory that stores scanned books...(" + directoryThatContainsScans + ")");
            createDirectoryThatStoresScannedBooks();
        }

        if(!doesDirectoryExist(directoryThatContainsResultantImages)) {
            logger.info("Initializing directory that stores resultant images...(" + directoryThatContainsResultantImages + ")");
            createDirectoryThatStoresResultantImages();
        }
    }

    public boolean doesDirectoryExist(File directoryPath) {
        return directoryPath.exists();
    }

    public void createDirectory(File directoryPath) {
        directoryPath.mkdirs();
    }

    public void createDirectoryThatStoresScannedBooks() {
        createDirectory(directoryThatContainsScans);
    }

    public void createDirectoryThatStoresResultantImages() {
        createDirectory(directoryThatContainsResultantImages);
    }

    public boolean isRestartNeeded(String versionChecksResult) {
        if(versionChecksResult.equals(SharedConstants.NO_NEWER_SIMILE_VERSION_AVAILABLE)) return false;
        return true;
    }

    public void handleVersionChecksAndUpdates() throws IOException, InterruptedException {
        boolean isNewerVersionAvailable = isNewerVersionAvailable();
        if(isNewerVersionAvailable) {
            System.out.println(SimileContext.OS_NAME);
            boolean doesUserWantToStartUpdate = showAlertThatInformNewerVersionIsAvailable();
            if(doesUserWantToStartUpdate) {
                if(SimileContext.OS_NAME.toLowerCase().contains("mac")) {
                    CommandsRunner.runCommand("./Scripts/auto-update.command");
                }
                else if(SimileContext.OS_NAME.toLowerCase().contains("nix") || SimileContext.OS_NAME.contains("nux") || SimileContext.OS_NAME.contains("aix")) {
                    CommandsRunner.runCommand("./Scripts/auto-update.sh");
                }
                System.exit(0);
            }
        }
    }

    public boolean showAlertThatInformNewerVersionIsAvailable() {
        Alert newerVersionIsAvailableAlert = new Alert(Alert.AlertType.CONFIRMATION);
        newerVersionIsAvailableAlert.setHeaderText("Newer Simile version is available.");
        newerVersionIsAvailableAlert.setContentText("Do you want to start an update?"
                + "\nApplication restart will be needed.");

        Optional<ButtonType> doesUserWantToStartUpdate = newerVersionIsAvailableAlert.showAndWait();
        if(!doesUserWantToStartUpdate.isPresent() || doesUserWantToStartUpdate.get() != ButtonType.OK) {
            return false;
        } else {
            return true;
        }
    }

    /**
     * Method allows to verify if the newer version is available.
     * It calls the Python script which compares the GitHub ReleaseId with the local ReleaseId.
     *
     * @return information if newer Simile version is available
     * @throws IOException if script cannot be run or script cannot read line from the Buffer
     * @throws InterruptedException if something interrupts waiting for the end of the script execution
     */
    private boolean isNewerVersionAvailable() throws IOException, InterruptedException {
        String isLocalReleaseIdEqualToLatestReleaseId = CommandsRunner.runCommand("python3 ./Scripts/Deployment/version-checker.py").toLowerCase();
        return Boolean.parseBoolean(isLocalReleaseIdEqualToLatestReleaseId);
    }
}
