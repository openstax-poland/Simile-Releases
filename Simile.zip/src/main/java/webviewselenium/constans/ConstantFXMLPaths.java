package webviewselenium.constans;

import java.io.File;

public class ConstantFXMLPaths {
	public static final Integer width = 1200; //1366
	public static final Integer height = 685; //750

	private static final String PATH_TO_GUI_DIRECTORY = "src" + File.separator + "main" + File.separator + "java" + File.separator + "webviewselenium" + File.separator +  "gui" + File.separator;
	public static final String addCategoryMenu = PATH_TO_GUI_DIRECTORY +  "reportChange" + File.separator +  "CreateIssueMenu.fxml";
	public static final String bookDetailsMenu = PATH_TO_GUI_DIRECTORY + "bookDetailsMenu" + File.separator + "bookDetailsMenu.fxml";
	public static final String bookDetailsScanMenu = PATH_TO_GUI_DIRECTORY + "bookDetailsMenu" + File.separator + "bookDetailsScanMenu.fxml";
	public static final String chooseBookMenu = PATH_TO_GUI_DIRECTORY +  "chooseBookMenu" + File.separator +  "ChooseBookMenu.fxml";
	public static final String collectionMenu = PATH_TO_GUI_DIRECTORY + "collectionMenu" + File.separator + "collectionMenu.fxml";
	public static final String compareBookMenu = PATH_TO_GUI_DIRECTORY +  "compareBookMenu" + File.separator +  "compareMenu.fxml";
	public static final String compareMenu = PATH_TO_GUI_DIRECTORY +  "compareMenu" + File.separator +  "compareMenu.fxml";
	public static final String generateIssueMenu = PATH_TO_GUI_DIRECTORY + "generateIssue" + File.separator +  "GenerateIssueMenu.fxml";
	public static final String scanMenu = PATH_TO_GUI_DIRECTORY + "scanMenu" + File.separator + "scanMenu.fxml";
	public static final String reportChangeMenu = PATH_TO_GUI_DIRECTORY +  "reportChange" + File.separator +  "ReportChangeMenu.fxml";
	public static final String yourIssuesMenu = PATH_TO_GUI_DIRECTORY + "generateIssue" + File.separator +  "yourIssuesMenu" + File.separator + "YourIssuesMenu.fxml";
}
