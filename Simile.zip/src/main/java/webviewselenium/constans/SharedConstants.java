package webviewselenium.constans;

import webviewselenium.bookProperties.tableOfContents.ToCComponentProperties;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

/**
 * This class provides a set of paths to all necessary files.
 */
public class SharedConstants {
    public static String basicPath = "";

    // Structure: Directories' Names
    public static final String NAME_OF_DIRECTORY_THAT_CONTAINS_SCANS = "ScanDB";
    public static final String NAME_OF_DIRECTORY_THAT_CONTAINS_RESULTANT_REPORTS = "reports";

    // Structure: Files' extensions
    public static final String PDF_EXTENSION = ".pdf";
    public static final String PNG_EXTENSION = ".png";
    public static final String XML_EXTENSION = ".xml";

    // Domain: Useful chapters' names
    public static final String EXERCISES_CHAPTER_NAME = "Exercises";

    // GUI: Book Summary Fields
    public static final String FOLDER_SUMMARY_HEADER = "Folder: ";
    public static final String DATE_SUMMARY_HEADER = "Date: ";
    public static final String SERVER_SUMMARY_HEADER = "Server: ";

    // GUI: CollectionMenu
    public static final String FOLDER_COLUMN_VALUE_FACTORY = "directoryIndex";
    public static final String TITLE_COLUMN_VALUE_FACTORY = "title";
    public static final String SERVER_COLUMN_VALUE_FACTORY = "server";
    public static final String NOTE_COLUMN_VALUE_FACTORY = "note";
    public static final String DATE_COLUMN_VALUE_FACTORY = "creationDate";

    // GUI: ScanMenu
    public static String nameOfVariableThatConstitutesColumn = ToCComponentProperties.COMPONENT_TITLE_VARIABLE_NAME;

    // GUI: YourIssuesMenu
    public static final String YI_DATE_COLUMN_VALUE_FACTORY = "creationDate";
    public static final String YI_TITLE_COLUMN_VALUE_FACTORY = "title";
    public static final String YI_CATEGORY_COLUMN_VALUE_FACTORY = "category";
    public static final String YI_DESCRIPTION_COLUMN_VALUE_FACTORY = "description";

    // JSON Parser: Table of Contents
    public static final String TOC_FILENAME = "toc.json";
    public static final String CUSTOM_TOC_FILENAME = "custom_toc.json";
    public static final String BOOK_TITLE_JSON_ATTRIBUTE = "bookTitle";
    public static final String SECTIONS_JSON_ATTRIBUTE = "sections";
    public static final String TITLE_JSON_ATTRIBUTE = "title";
    public static final String URL_JSON_ATTRIBUTE = "url";
    public static final String TYPE_JSON_ATTRIBUTE = "type";
    public static final String MODULE_JSON_ATTRIBUTE = "module";

    // JSON Parser: Related Paths
    public static final String WORKSPACE_TOC_JSON_PATH = NAME_OF_DIRECTORY_THAT_CONTAINS_SCANS + File.separator + TOC_FILENAME;
    public static final String WORKSPACE_CUSTOM_TOC_JSON_PATH = NAME_OF_DIRECTORY_THAT_CONTAINS_SCANS + File.separator + CUSTOM_TOC_FILENAME;

    // CNX-BOOK-SCANNER: Structure
    public static String CNX_BOOK_SCANNER_DIRECTORY_NAME = "cnx-books-scanner";

    // CNX-BOOK-SCANNER: Command Parameters
    public static final String DEFAULT_CNX_BOOK_SCANNER_COMMAND_CONTENT = "yarn --cwd ./" + SharedConstants.CNX_BOOK_SCANNER_DIRECTORY_NAME + " start";

    // RESULTANT IMAGES: Filenames
    public static final String QA_RESULTANT_IMAGE_PREFIX = "croppedImagecroppedScannedImage_";
    public static final String REFERENCE_RESULTANT_IMAGE_PREFIX = "croppedImagecroppedTemplateImage_";

    // XMLs: Filenames
    public static final String SCAN_INFO_FILENAME = "info.xml";
    public static final String ISSUE_INFO_FILENAME = "category.xml";

    // XMLs: Issues' Properties
    public static final String ISSUE_NODE_NAME = "Category";
    public static final String ISSUE_TITLE = "Title";
    public static final String ISSUE_CATEGORY = "Name";
    public static final String ISSUE_DESCRIPTION = "Description";
    public static final String ISSUE_CREATION_DATE = "creationDate";
    public static final String ISSUE_PARENT_DIRECTORY_NAME = "parentDirectory";

    // XMLs: Scans' Properties
    public static final String SCAN_NODE_NAME = "ScanInfo";
    public static final String SCAN_PROPERTY_TITLE = "Title";
    public static final String SCAN_PROPERTY_CREATION_DATE = "Creation-Date";
    public static final String SCAN_PROPERTY_NOTE = "Note";
    public static final String SCAN_PROPERTY_SERVER = "Server";
    public static final String SCAN_PROPERTY_ESTIMATED_COMPARISON_TIME = "Estimated-Comparison-Time";



    // Path to the directory that contains produced scans

    public static String fullNameOfDirectoryThatContainsScans = basicPath + NAME_OF_DIRECTORY_THAT_CONTAINS_SCANS;

    // Path to the directory that contains resultant images
    public static String nameOfDirectoryThatContainsResultantImages = "Results";
    public static String fullNameOfDirectoryThatContainsResultantImages = fullNameOfDirectoryThatContainsScans + File.separator + nameOfDirectoryThatContainsResultantImages;

    // Path to the directory that contains resultant reports
    public static String nameOfDirectoryThatContainsResultantReports = "reports";
    public static String fullNameOfDirectoryThatContainsResultantReports = basicPath + nameOfDirectoryThatContainsResultantReports;
	public static final String nameOfDirectoryThatContainsLogs = "logs";
    public static final String fullNameOfDirectoryThatContainsLogs = fullNameOfDirectoryThatContainsResultantReports + File.separator + nameOfDirectoryThatContainsLogs;

    // Path to the text file that stores information about subchapters difference
    public static String pathToDifferenceReportFile = "." + File.separator + fullNameOfDirectoryThatContainsResultantReports + File.separator + "Difference_Report.txt";

    // Table of Contents (TOC)
	public static final String mapKeyThatIndicatesAdditionalSubchapters = "additional";
	public static final String mapKeyThatIndicatesMissingSubchapters = "missing";
    public static final String fullNameOfFileThatStoresToC = "toc_1.json";
    public static final String JSON_TITLE_VALUE = "title";
    public static final String JSON_CHAPTER_VALUE = "chapters";


    // Path to the directory that contains database files.
    public static String pathToDirectoryThatContainsDatabaseFiles = "XMLdb";
    public static String fullNameOfDirectoryThatContainsDatabaseFiles = basicPath + pathToDirectoryThatContainsDatabaseFiles;
    public static String fullNameOfFileThatContainsSupportedServersList = fullNameOfDirectoryThatContainsDatabaseFiles + File.separator + "supported-servers.xml";
	public static String fullNameOfFileThatContainsBooksAvailableForScan = fullNameOfDirectoryThatContainsDatabaseFiles + File.separator + "BooksAvailableForScan.xml";

		// XMLs
		// 1.1. supported-servers.xml
		public static final String supportedServersRootElementName = "server";
		public static final String supportedServersServerName = "server-name";
		public static final String supportedServersServerUrl = "server-url";
		public static final String supportedServersServerElement = "server-element";
		// 1.2. BooksAvailableForScan.xml
		public static final String availableBooksRootElementName = "Book";
		public static final String availableBooksRootAttributeName = "Name";

    // Path to the directory that contains CNX Books Scanner
    public static String pathToDirectoryThatContainsCnxBookScanner = "cnx-books-scanner";
    public static String fullNameOfDirectoryThatContainsCnxBookScanner = basicPath + pathToDirectoryThatContainsCnxBookScanner;
    public static String fullNameOfDirectoryThatContainsCnxBookScannerBuilds = fullNameOfDirectoryThatContainsCnxBookScanner + File.separator + "build";

    // Names of relevant files
    public static String nameOfBookInfoXmlFile = "info";

    ///// TEST RESOURCES /////
	public static String nameOfDirectoryThatContainsTestResources = "src" + File.separator + "test" + File.separator + "resources" + File.separator;
	public static String nameOfDirectoryThatContainsXmlResources = "xmls" + File.separator;
	public static String fullNameOfSampleBookInformationScanDB =
			nameOfDirectoryThatContainsTestResources + nameOfDirectoryThatContainsXmlResources + "sample-book-information-scandb.xml";
	public static String fullNameOfRealBookInformationScanDB =
			nameOfDirectoryThatContainsTestResources + nameOfDirectoryThatContainsXmlResources + "real-book-information-scandb.xml";

	public static final String fullNameOfFirstFileThatStoresTestToC = "resources/Unit Tests/ScanDB Test Cases/996/" + fullNameOfFileThatStoresToC;
	public static final String fullNameOfSecondFileThatStoresTestToC = "resources/Unit Tests/ScanDB Test Cases/997/" + fullNameOfFileThatStoresToC;
	public static final String fullNameOfFirstFileThatStoresInvalidTestToC = "resources/Unit Tests/ScanDB Test Cases/998/" + fullNameOfFileThatStoresToC;
	public static final String fullNameOfSecondFileThatStoresInvalidTestToC = "resources/Unit Tests/ScanDB Test Cases/999/" + fullNameOfFileThatStoresToC;

    // Name of the ScannebBookProperties for REX books provided for tests
    public static String rexQaBook = "Anatomy and Physiology  asdfbb  Chrome      asdfghjkl         https://openstax.org/  25.11.2019       4ScanDB/996";
    public static String rexRefBook = "Anatomy and Physiology  zxcvhh  Chrome        zxcvbnm         https://openstax.org/37.26.12.25.11.2019       4ScanDB/997";

    // Name of the ScannebBookProperties for CNX books provided for tests
    public static String cnxQaBook = "Fizyka dla szkół wyższych. Tom 3  stage   Chrome          stage https://staging.openstax.org/33.43.12.24.3.2020       0ScanDB/998";
    public static String cnxRefBook = "Fizyka dla szkół wyższych. Tom 3  stage2  Chrome          stage https://staging.openstax.org/33.43.12.24.3.2020       0ScanDB/999";




    // Name of the ScannebBookProperties for PDF books provided for tests
	public static String nameOfScriptsDirectory = "Scripts";
	public static String nameOfScanPathFile = "ScanPath";
    public static String nameOfBookScanDirectory = basicPath + NAME_OF_DIRECTORY_THAT_CONTAINS_SCANS;
    


    public static String nameOfLinksXmlFile = "links";
    public static String nameOfCategoryInfoXmlFile = "category";
    public static String nameOfCategoryImagesXmlFile = "category-images";
    public static String nameOfCategoryReportPdfFile = "category-report";
    
    public static String nameOfXmlConfigFile = "Config";
    public static String pathToXmlConfig = "XMLdb" + File.separator + nameOfXmlConfigFile + ".xml";

    
    public static String nameOfScanningServiceDirectory = "cnx-books-scanner";
    public static String nameOfScanningServiceScript = "index.ts";
    
    public static String nameOfCNXBookScannerDirectory = "cnx-books-scanner";
    public static String nameOfKillScanningProcessesScript = "script.sh";
    
    // DeepComparison script paths
    public static String nameOfDeepComparisionScript = "DeepComparisionScript.py";
    public static String pathToDeepComparisionScript = nameOfScriptsDirectory + File.separator + nameOfDeepComparisionScript;
    
    // DifferenceComparison script paths
    public static String nameOfDifferenceComaprisonScript = "DifferenceComparison.py";
    public static String pathToDifferenceComparisonScript = nameOfScriptsDirectory + File.separator + nameOfDifferenceComaprisonScript;
    
    // Unit Tests paths
    public static String unitTestsPath = "resources" + File.separator + "Unit Tests" + File.separator;
    public static String unitTestsPathImagesPNG = unitTestsPath + "Image Finder" + File.separator;
    public static String unitTestsImageSpliter = unitTestsPath + "Image Spliter" + File.separator;
    public static String unitTestsImageDeleter = unitTestsPath + "Image Deleter" + File.separator;
    
    public static void refreshScanDBPath() {
    	
    	File file = new File("XMLdb" + File.separator + SharedConstants.nameOfScanPathFile + ".txt");

		try {
	    	BufferedReader bufferedReader = new BufferedReader(new FileReader(file));
	    	String thePath; 

			while ((thePath = bufferedReader.readLine()) != null) {
				SharedConstants.basicPath = thePath;
			}
			
			bufferedReader.close();

		} catch (IOException e0) {
			e0.printStackTrace();
		} 
		
    	SharedConstants.nameOfBookScanDirectory = SharedConstants.basicPath + "ScanDB";
		SharedConstants.fullNameOfDirectoryThatContainsResultantImages = SharedConstants.basicPath + "ScanDB" + File.separator + "Results";
    }
    
}
