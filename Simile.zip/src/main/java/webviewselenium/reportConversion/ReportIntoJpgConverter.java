package webviewselenium.reportConversion;

import java.io.File;

/**
 * Class contains methods that allow to convert Issue Report in PDF format into JPGs.
 *
 */
public class ReportIntoJpgConverter implements IReportIntoImagesConverter {
	private final static String NAME_FORMAT = "Report_%d.%s";

	@Override
	public void convertPDF(String pdfFilePath, String outputDirectoryPath) {
		final File reportFile = new File(pdfFilePath);

		if(isItPdfFile(reportFile)) {
			convertIntoImages(pdfFilePath, outputDirectoryPath + File.separator + NAME_FORMAT, PossibleConversionExtensions.jpg);
		}		
	}
}
