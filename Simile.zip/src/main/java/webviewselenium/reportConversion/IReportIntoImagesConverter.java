package webviewselenium.reportConversion;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.stream.Stream;

import org.apache.log4j.Logger;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.rendering.ImageType;
import org.apache.pdfbox.rendering.PDFRenderer;
import org.apache.pdfbox.tools.imageio.ImageIOUtil;
import webviewselenium.constans.SharedConstants;
import webviewselenium.gui.ApplicationLoader;

/**
 * Interface contains methods that allow to convert PDF into the Images.
 */
public interface IReportIntoImagesConverter {
	Logger LOGGER = ApplicationLoader.getLogger();

	Integer DEFAULT_DPI = 300;
	String PDF_NOT_EXISTS_WARNING_MESSAGE = "PDF File not exists!";

	/**
	 * Method allows to convert PDF file into an Image file.
	 * 
	 * @param pdfFilePath path to a PDF file that should be converted into the Images
	 * @param outputDirectoryPath path to an output directory that should store the created Images
	 */
	void convertPDF(String pdfFilePath, String outputDirectoryPath);
    
	/**
	 * Method allows to convert a PDF file into the Images. Each PDF page is converted into a single Image.
	 * 
	 * @param pathToPdfFile path to a PDF file that should be converted into the Images
	 * @param nameFormat output file's path
	 * @param conversionExtension extension of the Image to which PDF file will be converted
	 */
	default void convertIntoImages(String pathToPdfFile, String nameFormat, PossibleConversionExtensions conversionExtension) {
		try {
			PDDocument document = PDDocument.load(new File(pathToPdfFile));
			document.close();
			
	        Stream.iterate(0, pageNum -> pageNum + 1)
	        	.limit(document.getNumberOfPages())
	        	.forEach(page -> {
	        		try {
	        			PDDocument singlePage = PDDocument.load(new File(pathToPdfFile));
	        			PDFRenderer pdfRenderer = new PDFRenderer(singlePage);
						BufferedImage bufferedImage = pdfRenderer.renderImageWithDPI(page, DEFAULT_DPI, ImageType.RGB);
						ImageIOUtil.writeImage(bufferedImage, String.format(nameFormat, page + 1, conversionExtension.toString()), DEFAULT_DPI);
						singlePage.close();
					} catch(IOException exc) {
						LOGGER.warn(exc);
					}
	        	});
	        
		} catch(IOException exc) {
			LOGGER.warn(exc);
		} 
	}
	
	/**
	 * Method allows to verify if a requested PDF file exists and all properties are correct.
	 * Default implementation has been prepared, because every conversion case should contains the same validation process.
	 * 
	 * @param sourceFile path to a PDF file that should be validated
	 * @return true if validation is successful, false if validation is not successful
	 */
    default boolean isItPdfFile(File sourceFile) {
        if (sourceFile == null || !sourceFile.exists() || !sourceFile.getPath().endsWith(SharedConstants.PDF_EXTENSION)) {
        	LOGGER.warn(PDF_NOT_EXISTS_WARNING_MESSAGE);
            return false;
        }
        return true;
    }
}
