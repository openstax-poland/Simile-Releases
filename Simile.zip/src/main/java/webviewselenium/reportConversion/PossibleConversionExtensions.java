package webviewselenium.reportConversion;

public enum PossibleConversionExtensions {
    jpeg,
    jpg,
    gif,
    tiff,
    png
}
