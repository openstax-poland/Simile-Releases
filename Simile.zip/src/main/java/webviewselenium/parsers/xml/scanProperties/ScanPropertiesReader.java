package webviewselenium.parsers.xml.scanProperties;

import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import webviewselenium.bookProperties.ScanProperties;
import webviewselenium.constans.SharedConstants;
import webviewselenium.parsers.xml.ContentXmlReader;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ScanPropertiesReader {
    private final Pattern DIRECTORY_INDEX_PATTERN = Pattern.compile("\\d+");
    private final String NODE_NAME = SharedConstants.SCAN_NODE_NAME;
    private final String xmlFilePath;
    private final ContentXmlReader contentXmlReader;
    private final NodeList readXmlContent;
    private final Element scanInformation;

    public ScanPropertiesReader(String xmlFilePath) {
        this.xmlFilePath = xmlFilePath;
        contentXmlReader = new ContentXmlReader(xmlFilePath, NODE_NAME);
        readXmlContent = contentXmlReader.readXmlContent();
        scanInformation = (Element) readXmlContent.item(0);
    }

    public ScanProperties findScanProperties() {
        return new ScanProperties.Builder()
            .title(readTitleValue())
            .creationDate(readCreationDateValue())
            .note(readNoteValue())
            .server(readServerValue())
            .estimatedComparisonTime(readEstimatedComparisonTimeValue())
            .directoryIndex(readDirectoryIndexValue())
            .build();
    }

    private String readTitleValue() {
        return scanInformation.getElementsByTagName(SharedConstants.SCAN_PROPERTY_TITLE).item(0).getTextContent().trim();
    }

    private String readCreationDateValue() {
        return scanInformation.getElementsByTagName(SharedConstants.SCAN_PROPERTY_CREATION_DATE).item(0).getTextContent().trim();
    }

    private String readNoteValue() {
        return scanInformation.getElementsByTagName(SharedConstants.SCAN_PROPERTY_NOTE).item(0).getTextContent().trim();
    }

    private String readServerValue() {
        return scanInformation.getElementsByTagName(SharedConstants.SCAN_PROPERTY_SERVER).item(0).getTextContent().trim();
    }

    private String readEstimatedComparisonTimeValue() {
        return scanInformation.getElementsByTagName(SharedConstants.SCAN_PROPERTY_ESTIMATED_COMPARISON_TIME).item(0).getTextContent().trim();
    }

    private String readDirectoryIndexValue() {
        Matcher directoryIndexMatcher = DIRECTORY_INDEX_PATTERN.matcher(xmlFilePath);
        directoryIndexMatcher.find();
        return directoryIndexMatcher.group();
    }
}
