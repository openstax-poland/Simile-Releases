package webviewselenium.parsers.xml.issueProperties;

import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import webviewselenium.bookProperties.IssueProperties;
import webviewselenium.constans.SharedConstants;
import webviewselenium.gui.ApplicationLoader;
import webviewselenium.parsers.xml.ContentXmlReader;

public class IssuePropertiesReader {
    private final String NODE_NAME = SharedConstants.ISSUE_NODE_NAME;
    private final String xmlFilePath;
    private final ContentXmlReader contentXmlReader;
    private final NodeList readXmlContent;
    private final Element issueInformation;

    public IssuePropertiesReader(String xmlFilePath) {
        this.xmlFilePath = xmlFilePath;
        contentXmlReader = new ContentXmlReader(xmlFilePath, NODE_NAME);
        readXmlContent = contentXmlReader.readXmlContent();
        issueInformation = (Element) readXmlContent.item(0);
    }

    /**
     * Allows to find all Issue's Properties from the provided XML file.
     * @return object that stores all properties that characterizes each Issue
     */
    public IssueProperties findIssueProperties() {
        return new IssueProperties.Builder()
                .title(readTitleValue())
                .category(readCategoryValue())
                .description(readDescriptionValue())
                .creationDate(readCreationDateValue())
                .parentDirectoryName(readParentDirectoryNameValue())
                .build();
    }

    /**
     * Allows to read book's title value from the XML file. In case of failure, it returns appropriate information about the lack of title value.
     * @return book's title from which an issue has been created
     */
    private String readTitleValue() {
        try {
            return issueInformation.getElementsByTagName(SharedConstants.ISSUE_TITLE).item(0).getTextContent().trim();
        } catch (Exception ex) {
            ApplicationLoader.getLogger().warn("Cannot find Title value in the Report file: " + xmlFilePath);
            return "Title not found";
        }
    }

    /**
     * Allows to read issue category value from the XML file. In case of failure, it returns appropriate information about the lack of category value.
     * @return category of an issue
     */
    private String readCategoryValue() {
        try {
            return issueInformation.getElementsByTagName(SharedConstants.ISSUE_CATEGORY).item(0).getTextContent().trim();
        } catch (Exception ex) {
            ApplicationLoader.getLogger().warn("Cannot find Category value in the Report file: " + xmlFilePath);
            return "Category not found";
        }
    }

    /**
     * Allows to read issue description value from the XML file. In case of failure, it returns appropriate information about the lack of description value.
     * @return description of an issue
     */
    private String readDescriptionValue() {
        try {
            return issueInformation.getElementsByTagName(SharedConstants.ISSUE_DESCRIPTION).item(0).getTextContent().trim();
        } catch (Exception ex) {
            ApplicationLoader.getLogger().warn("Cannot find Description value in the Report file: " + xmlFilePath);
            return "Description not found";
        }
    }

    /**
     * Allows to read issue creation date value from the XML file. In case of failure, it returns appropriate information about the lack of creation date value.
     * @return creation date of an issue
     */
    private String readCreationDateValue() {
        try {
            return issueInformation.getElementsByTagName(SharedConstants.ISSUE_CREATION_DATE).item(0).getTextContent().trim();
        } catch (Exception ex) {
            ApplicationLoader.getLogger().warn("Cannot find Creation Date value in the Report file: " + xmlFilePath);
            return "Date not found";
        }
    }

    private String readParentDirectoryNameValue() {
        try {
            return issueInformation.getElementsByTagName(SharedConstants.ISSUE_PARENT_DIRECTORY_NAME).item(0).getTextContent().trim();
        } catch (Exception ex) {
            ApplicationLoader.getLogger().warn("Cannot find Parent Directory Name value in the Report file: " + xmlFilePath);
            return "Parent Directory Name not found";
        }
    }
}
