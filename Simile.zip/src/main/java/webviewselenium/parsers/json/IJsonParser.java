package webviewselenium.parsers.json;

import org.apache.log4j.Logger;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import webviewselenium.gui.ApplicationLoader;

import java.io.FileReader;
import java.io.IOException;

public interface IJsonParser {
    Logger LOGGER = ApplicationLoader.getLogger();

    /**
     * Returns parsed JSON object.
     * Once it isn't possible to parse that file - empty Parser object is returned.
     *
     * @param pathToJsonFile path to the JSON file that should be parsed
     * @return parsed JSON file
     */
    default Object getParsedJsonFile(String pathToJsonFile) {
        try {
            return new JSONParser().parse(new FileReader(pathToJsonFile));
        } catch (IOException | ParseException e) {
            e.printStackTrace();
            LOGGER.error(IJsonParser.class.getSimpleName() + ":" + e.getMessage());
        }
        return new JSONParser();
    }
}
