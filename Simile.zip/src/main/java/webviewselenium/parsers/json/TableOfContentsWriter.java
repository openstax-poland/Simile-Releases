package webviewselenium.parsers.json;

import javafx.scene.control.TablePosition;
import org.json.JSONArray;
import org.json.JSONObject;
import webviewselenium.bookProperties.tableOfContents.ToCComponentProperties;
import webviewselenium.constans.SharedConstants;

import java.io.IOException;
import java.util.List;

public class TableOfContentsWriter implements IJsonWriter{

    /**
     * Allows to create JSON object which contains information about all components
     * selected in the JavaFX component - Table View.
     *
     * @param path path to the file that is created
     * @param bookTitle title of the book to which the created json object relates
     * @param toCComponentProperties list of all selected ToCComponentsProperties objects in the TableView
     * @param tablePositions list of all selected ToCComponentsProperties objects' positions in the TableView
     * @throws IOException if it isn't possible to write to the file
     */
    public void createCustomScanTableOfContentsJson(String path, String bookTitle,
                                                    List<ToCComponentProperties> toCComponentProperties,
                                                    List<TablePosition> tablePositions) throws IOException {
        JSONObject jsonObject = new JSONObject();
        JSONArray sections = new JSONArray();

        jsonObject.put(SharedConstants.BOOK_TITLE_JSON_ATTRIBUTE, bookTitle);
        tablePositions.forEach(cell -> {
            JSONObject module = new JSONObject();
            module.put(SharedConstants.TYPE_JSON_ATTRIBUTE, SharedConstants.MODULE_JSON_ATTRIBUTE);
            module.put(SharedConstants.TITLE_JSON_ATTRIBUTE, toCComponentProperties.get(cell.getRow()).getComponentTitle().trim());
            module.put(SharedConstants.URL_JSON_ATTRIBUTE, toCComponentProperties.get(cell.getRow()).getComponentUrl());
            if (!toCComponentProperties.get(cell.getRow()).getComponentUrl().isEmpty()) {
                sections.put(module);
            }
        });

        jsonObject.put(SharedConstants.SECTIONS_JSON_ATTRIBUTE, sections);
        writeToFile(path, jsonObject);
    }
}
