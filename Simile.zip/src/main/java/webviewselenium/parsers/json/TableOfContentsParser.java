package webviewselenium.parsers.json;

import lombok.AllArgsConstructor;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import webviewselenium.bookProperties.tableOfContents.ToCComponentProperties;
import webviewselenium.bookProperties.tableOfContents.ToCComponentsTypes;
import webviewselenium.constans.SharedConstants;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.IntStream;

/**
 * Class contains methods that allow to parse Table Of Contents components provided in the JSON format.
 */
@AllArgsConstructor
public class TableOfContentsParser implements IJsonParser {
    private static final String ORG_EXTENSION = ".org";
    private static final String COM_EXTENSION = ".com";
    private static final int HTTPS_PREFIX_LENGTH = "https://".length();
    private static final List<JSONObject> parsedChapters = new ArrayList<>();
    private static final List<ToCComponentProperties> parsedComponents = new ArrayList<>();
    private final String pathToJsonFile;

    /**
     * Allows to get book's title from the parsed JSON file.
     *
     * @return book's title
     */
    public String getBookTitle() {
        JSONObject parsedTableOfContents = (JSONObject) getParsedJsonFile(pathToJsonFile);
        return parsedTableOfContents.get(SharedConstants.BOOK_TITLE_JSON_ATTRIBUTE).toString();
    }

    /**
     * Allows to get book's source server from the parsed JSON file.
     *
     * @return book's source server
     */
    public String getServerName() {
        String parsedUrl = getParsedChapters().stream().findFirst().get().get(SharedConstants.URL_JSON_ATTRIBUTE).toString();
        if (parsedUrl.contains(ORG_EXTENSION)) {
            return parsedUrl.substring(HTTPS_PREFIX_LENGTH, parsedUrl.lastIndexOf(ORG_EXTENSION) + ORG_EXTENSION.length());
        }
        else if (parsedUrl.contains(COM_EXTENSION)) {
            return parsedUrl.substring(HTTPS_PREFIX_LENGTH, parsedUrl.lastIndexOf(COM_EXTENSION) + COM_EXTENSION.length());
        }
        return "server-name-not-found";
    }

    /**
     * Allows to get all parsed components - book's Chapters and Modules.
     *
     * @return all parsed components - book's Chapters and Modules
     */
    public List<ToCComponentProperties> getParsedComponents() {
        getParsedChapters().forEach(this::parseComponents);
        return parsedComponents;
    }

    /**
     * Allows to get parsed chapters.
     * Chapters in the cnx-book-scanner context are the components which contain modules.
     *
     * @return all parsed chapters
     */
    private List<JSONObject> getParsedChapters() {
        parsedChapters.clear();
        parsedComponents.clear();
        JSONObject parsedTableOfContents = (JSONObject) getParsedJsonFile(pathToJsonFile);
        JSONArray parsedMainBookChapters = (JSONArray) parsedTableOfContents.get(SharedConstants.SECTIONS_JSON_ATTRIBUTE);

        IntStream.range(0, parsedMainBookChapters.size()).forEach(chapterJsonObject -> {
            JSONObject currentParentChapterJsonObject = (JSONObject) parsedMainBookChapters.get(chapterJsonObject);
            parsedChapters.add(currentParentChapterJsonObject);
        });
        return parsedChapters;
    }

    /**
     * Allows to parse all components.
     * Methods fills both lists - parsed Chapters list (Parent list) and parsed Modules list (Child list).
     *
     * @param parsedChapter parsed Chapter's (Parent) JSON object
     */
    private void parseComponents(JSONObject parsedChapter) {
        addParsedParentChapterToComponentsList(parsedChapter);
        addParsedModulesToComponentsList(parsedChapter, (JSONArray) parsedChapter.get(SharedConstants.SECTIONS_JSON_ATTRIBUTE));
    }

    /**
     * Allows to add Chapter to Parent list.
     *
     * @param parentChapter parsed Chapter's (Parent) JSON object
     */
    private void addParsedParentChapterToComponentsList(JSONObject parentChapter) {
        parsedComponents.add(new ToCComponentProperties(
                parentChapter.get(SharedConstants.TITLE_JSON_ATTRIBUTE).toString(), doesUrlParameterExist(parentChapter), ToCComponentsTypes.chapter, ""));
    }

    /**
     * Allows to verify if component has URL parameter.
     * All Modules contain URL parameter. Some chapters have URL parameter, it depends on the chapter type.
     * If Chapter is just a container for Modules - chapter doesn't contain URL parameter.
     * If Chapter is an independent component with content - chapter does contain URL parameter.
     *
     * @param parentChapter parsed Chapter's JSON object
     * @return answer if component contains URL parameter or not
     */
    private String doesUrlParameterExist(JSONObject parentChapter) {
        return parentChapter.get(SharedConstants.URL_JSON_ATTRIBUTE) != null
                ? parentChapter.get(SharedConstants.URL_JSON_ATTRIBUTE).toString() : "";
    }

    /**
     * Allows to add Module to Components (Child) list.
     *
     * @param parentChapter parsed Chapter's (Parent) JSON object
     * @param modulesIncludedInParentChapter parsed Modules' (Children) JSON objects
     */
    private void addParsedModulesToComponentsList(JSONObject parentChapter, JSONArray modulesIncludedInParentChapter) {
        if (modulesIncludedInParentChapter != null) {
            IntStream.range(0, modulesIncludedInParentChapter.size()).forEach(moduleIndex -> {
                JSONObject module = (JSONObject) modulesIncludedInParentChapter.get(moduleIndex);
                if (module.get(SharedConstants.TYPE_JSON_ATTRIBUTE).equals(SharedConstants.MODULE_JSON_ATTRIBUTE)) {
                    parsedComponents.add(new ToCComponentProperties(
                            module.get(SharedConstants.TITLE_JSON_ATTRIBUTE).toString(),
                            module.get(SharedConstants.URL_JSON_ATTRIBUTE).toString(),
                            ToCComponentsTypes.module,
                            parentChapter.get(SharedConstants.TITLE_JSON_ATTRIBUTE).toString()));
                } else {
                    parseComponents(module);
                }
            });
        }
    }
}
