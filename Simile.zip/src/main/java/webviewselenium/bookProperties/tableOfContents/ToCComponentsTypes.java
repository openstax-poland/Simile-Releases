package webviewselenium.bookProperties.tableOfContents;

/**
 * Class contains possible Components Types which are defined by cnx-books-scanner.
 * It is necessary to modify those values, if new types will be added/removed in the cnx-book-scanner project.
 */
public enum ToCComponentsTypes {
    chapter,
    module,
}
