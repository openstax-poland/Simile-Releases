package webviewselenium.bookProperties.tableOfContents;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

/**
 * Class contains fields that fully describe each Table of Contents component.
 * It is important to modify the final field value if componentTitle variable name will be changed.
 */
@Getter
@Setter
@AllArgsConstructor
public class ToCComponentProperties {
    public static final String COMPONENT_TITLE_VARIABLE_NAME = "componentTitle";
    private String componentTitle;
    private String componentUrl;
    private ToCComponentsTypes componentType;
    private String componentsParentChapterName;
}
