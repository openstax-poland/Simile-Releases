package webviewselenium.bookProperties;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Class contains fields that fully describe each Scanned Book component.
 */
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class ScanProperties {
    private String title;
    private String creationDate;
    private String note;
    private String server;
    private String estimatedComparisonTime;
    private String directoryIndex;

    public static final class Builder {
        private String title;
        private String creationDate;
        private String note;
        private String server;
        private String estimatedComparisonTime;
        private String directoryIndex;

        public ScanProperties.Builder title(String title) {
            this.title = title;
            return this;
        }

        public ScanProperties.Builder creationDate(String creationDate) {
            this.creationDate = creationDate;
            return this;
        }

        public ScanProperties.Builder note(String note) {
            this.note = note;
            return this;
        }

        public ScanProperties.Builder server(String server) {
            this.server = server;
            return this;
        }

        public ScanProperties.Builder estimatedComparisonTime(String estimatedComparisonTime) {
            this.estimatedComparisonTime = estimatedComparisonTime;
            return this;
        }

        public ScanProperties.Builder directoryIndex(String directoryIndex) {
            this.directoryIndex = directoryIndex;
            return this;
        }

        public ScanProperties build() {
            if (title.isEmpty())
                throw new IllegalStateException("Title value cannot be empty!");
            if (server.isEmpty())
                throw new IllegalStateException("Server value cannot be empty!");
            if (directoryIndex.isEmpty())
                throw new IllegalStateException("Directory index value cannot be empty!");

            ScanProperties ScanProperties = new ScanProperties();
            ScanProperties.title = this.title;
            ScanProperties.creationDate = this.creationDate;
            ScanProperties.note = this.note;
            ScanProperties.server = this.server;
            ScanProperties.estimatedComparisonTime = this.estimatedComparisonTime;
            ScanProperties.directoryIndex = this.directoryIndex;

            return ScanProperties;
        }
    }
}
