package webviewselenium.bashRunScripts;

import org.apache.log4j.Logger;
import webviewselenium.gui.ApplicationLoader;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 * Class contains methods that allow to run terminal commands from the Simile side.
 */
public class CommandsRunner {
    private final static Logger LOGGER = ApplicationLoader.getLogger();

    /**
     * Runs process based on the provided command.
     *
     * @param command command which is used as a base for the run process's content
     * @throws IOException if script cannot be run or script cannot read line from the Buffer
     * @throws InterruptedException if something interrupts waiting for the end of the script execution
     */
    public static void runCommand(String command) throws IOException, InterruptedException {
        String scanningProcessOutputLine;

        Process scanningProcess = Runtime.getRuntime().exec(command);
        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(scanningProcess.getInputStream()));

        while ((scanningProcessOutputLine = bufferedReader.readLine()) != null) {
            LOGGER.info(scanningProcessOutputLine);
        }

        scanningProcess.waitFor();
        scanningProcess.destroy();
    }
}
