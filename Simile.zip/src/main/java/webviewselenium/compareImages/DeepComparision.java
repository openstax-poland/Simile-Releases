package webviewselenium.compareImages;

public class DeepComparision {

	public static void findDifferencesBetweenImages(String pathToScannedImage, String pathToTemplateImage, String pathForResultantImage) {
		
	}
	
}
