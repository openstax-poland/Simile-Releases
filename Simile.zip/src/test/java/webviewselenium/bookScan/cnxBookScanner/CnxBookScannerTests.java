package webviewselenium.bookScan.cnxBookScanner;

import org.junit.Assert;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import webviewselenium.constans.SharedConstants;

import java.io.File;
import java.io.IOException;
import java.util.Arrays;

public class CnxBookScannerTests {
    private final String scanOutputPath = "resources/unit-tests/cnx-book-scanner/created-scans";
    private final File scanOutputDirectory = new File(scanOutputPath);
    private final String tocSourcePath = "../resources/unit-tests/cnx-book-scanner/test-scan-toc-source.json";
    private final CnxBookScanner cnxBookScanner = new CnxBookScanner();

    @BeforeEach
    public void setUp() {
        cnxBookScanner.resetYarnCommandContentToDefaultValue();
        Arrays.stream(scanOutputDirectory.listFiles()).forEach(File::delete);
    }

    @Test
    public void should_generate_default_command_content() {
        Assert.assertEquals(SharedConstants.DEFAULT_CNX_BOOK_SCANNER_COMMAND_CONTENT, cnxBookScanner.getYarnCommand());
    }

    @Test
    public void should_generate_correct_custom_command_content() {
        cnxBookScanner.addScanFromUrlParameter("url");
        cnxBookScanner.addPathParameter("path_to_file");
        cnxBookScanner.addFilenameParameter("filename_pattern");
        cnxBookScanner.addOpenTabsLimitParameter("number_of_tabs");
        cnxBookScanner.addWidthParameter("width_value");
        cnxBookScanner.addHeightParameter("height_value");
        cnxBookScanner.addLoggerParameter(CnxBookScannerLoggerTypes.DEVELOPMENT);
        cnxBookScanner.addOnlyToCParameter();

        Assert.assertEquals(
                "yarn --cwd ./cnx-books-scanner start --scan-from-url=url --path=path_to_file " +
                         "--filename=filename_pattern --open-tabs-limit=number_of_tabs --width=width_value --height=height_value " +
                         "--logger=development --only-toc",
                cnxBookScanner.getYarnCommand());
    }

    @Test
    public void should_reset_command_to_default_value_after_usage() throws IOException, InterruptedException {
        cnxBookScanner.addScanFromUrlParameter("url");
        cnxBookScanner.addOnlyToCParameter();

        Assert.assertEquals(SharedConstants.DEFAULT_CNX_BOOK_SCANNER_COMMAND_CONTENT +
                " --scan-from-url=url --only-toc", cnxBookScanner.getYarnCommand());

        cnxBookScanner.runCommand();
        Assert.assertEquals(SharedConstants.DEFAULT_CNX_BOOK_SCANNER_COMMAND_CONTENT, cnxBookScanner.getYarnCommand());
    }

    @Test
    public void should_scan_books_correctly() throws IOException, InterruptedException {
        String expectedFilenamePattern = "https_++openstax_org+books+calculus-volume-1+pages+";
        cnxBookScanner.addScanFromTocParameter(tocSourcePath);
        cnxBookScanner.addPathParameter("../" + scanOutputPath);
        cnxBookScanner.runCommand();

        Arrays.stream(scanOutputDirectory.listFiles()).forEach(scan -> Assert.assertTrue(scan.getName().contains(expectedFilenamePattern)));
        Assert.assertEquals(10, scanOutputDirectory.listFiles().length);
    }
}
