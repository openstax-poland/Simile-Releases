package webviewselenium.parsers.json;

import org.junit.Assert;
import org.junit.Test;

public class TableOfContentsParserTests {
    private final String astronomyToC = "resources/unit-tests/json-table-of-contents-parser/astronomy-toc.json";
    private final String biologyToC = "resources/unit-tests/json-table-of-contents-parser/biology-toc.json";
    private final String calculusToC = "resources/unit-tests/json-table-of-contents-parser/calculus-volume-1-toc.json";
    private final String chemistryToC = "resources/unit-tests/json-table-of-contents-parser/chemistry-toc.json";
    private final String entrepreneurshipToC = "resources/unit-tests/json-table-of-contents-parser/entrepreneurship-toc.json";
    private final String prealgebraToC = "resources/unit-tests/json-table-of-contents-parser/prealgebra-toc.json";
    private final String statisticsToC = "resources/unit-tests/json-table-of-contents-parser/statistics-toc.json";
    private final String cnxSourceToC = "resources/unit-tests/json-table-of-contents-parser/cnx-source-toc.json";

    private final TableOfContentsParser astronomyToCParser = new TableOfContentsParser(astronomyToC);
    private final TableOfContentsParser biologyToCParser = new TableOfContentsParser(biologyToC);
    private final TableOfContentsParser calculusToCParser = new TableOfContentsParser(calculusToC);
    private final TableOfContentsParser chemistryToCParser = new TableOfContentsParser(chemistryToC);
    private final TableOfContentsParser entrepreneurshipToCParser = new TableOfContentsParser(entrepreneurshipToC);
    private final TableOfContentsParser prealgebraToCParser = new TableOfContentsParser(prealgebraToC);
    private final TableOfContentsParser statisticsToCParser = new TableOfContentsParser(statisticsToC);
    private final TableOfContentsParser cnxSourceToCParser = new TableOfContentsParser(cnxSourceToC);
    private final TableOfContentsParser noneParser = new TableOfContentsParser("");

    @Test
    public void should_return_correctly_parsed_rex_book_titles() {
        Assert.assertEquals("Astronomy", astronomyToCParser.getBookTitle());
        Assert.assertEquals("Biology 2e", biologyToCParser.getBookTitle());
        Assert.assertEquals("Calculus Volume 1", calculusToCParser.getBookTitle());
        Assert.assertEquals("Chemistry 2e", chemistryToCParser.getBookTitle());
        Assert.assertEquals("Entrepreneurship", entrepreneurshipToCParser.getBookTitle());
        Assert.assertEquals("Prealgebra 2e", prealgebraToCParser.getBookTitle());
        Assert.assertEquals("Statistics", statisticsToCParser.getBookTitle());
    }

    @Test
    public void should_return_correctly_parsed_cnx_book_titles() {
        Assert.assertEquals("Fizyka dla szkół wyższych. Tom 1", cnxSourceToCParser.getBookTitle());
    }

    @Test(expected = ClassCastException.class)
    public void should_throw_exception_for_invalid_file() {
        noneParser.getBookTitle();
    }

    @Test
    public void should_return_correctly_parsed_rex_server_names() {
        Assert.assertEquals("staging.openstax.org", astronomyToCParser.getServerName());
        Assert.assertEquals("openstax.org", biologyToCParser.getServerName());
        Assert.assertEquals("openstax.org", calculusToCParser.getServerName());
        Assert.assertEquals("openstax.org", chemistryToCParser.getServerName());
        Assert.assertEquals("openstax.org", entrepreneurshipToCParser.getServerName());
        Assert.assertEquals("openstax.org", prealgebraToCParser.getServerName());
        Assert.assertEquals("openstax.org", statisticsToCParser.getServerName());
    }

    @Test
    public void should_return_correctly_parsed_cnx_server_names() {
        Assert.assertEquals("cnx.org", cnxSourceToCParser.getServerName());
    }

    @Test(expected = ClassCastException.class)
    public void should_return_unknown_server_name_for_invalid_file() {
        noneParser.getServerName();
    }

    @Test
    public void should_return_correctly_parsed_rex_components() {
        Assert.assertEquals(463, astronomyToCParser.getParsedComponents().size());
        Assert.assertEquals(550, biologyToCParser.getParsedComponents().size());
        Assert.assertEquals(93, calculusToCParser.getParsedComponents().size());
        Assert.assertEquals(274, chemistryToCParser.getParsedComponents().size());
        Assert.assertEquals(185, entrepreneurshipToCParser.getParsedComponents().size());
        Assert.assertEquals(154, prealgebraToCParser.getParsedComponents().size());
        Assert.assertEquals(212, statisticsToCParser.getParsedComponents().size());
    }

    @Test
    public void should_return_correctly_parsed_cnx_components() {
        Assert.assertEquals(299, cnxSourceToCParser.getParsedComponents().size());
    }

    @Test(expected = ClassCastException.class)
    public void should_return_no_parsed_components_for_invalid_file() {
        noneParser.getParsedComponents();
    }
}
