package webviewselenium.parsers.json;

/**
 * Class doesn't contain any test case as to prepare one it is necessary to use UI.
 * Once we implement automated tests that can manage UI JSON creations tests should be created.
 */
public class TableOfContentsWriterTests {

}
