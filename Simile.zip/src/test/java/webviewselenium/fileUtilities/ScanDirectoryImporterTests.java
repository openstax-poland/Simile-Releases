package webviewselenium.fileUtilities;

import org.apache.commons.io.FileUtils;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import webviewselenium.constans.ConstantMessages;
import webviewselenium.constans.SharedConstants;

import java.io.File;
import java.io.IOException;

public class ScanDirectoryImporterTests {
    private final File ASTRONOMY_ORIGINAL_FILE = new File("resources/unit-tests/collection-import/astronomy-original");
    private final File ENTREPRENEURSHIP_ORIGINAL_FILE = new File("resources/unit-tests/collection-import/entrepreneurship-original");
    private final File INVALID_FORMAT_ORIGINAL_FILE = new File("resources/unit-tests/collection-import/invalid-format-name");
    private final File INVALID_SOURCE_NO_INFO = new File("resources/unit-tests/collection-import/invalid-source-no-info");
    private final File INVALID_SOURCE_NO_TOC = new File("resources/unit-tests/collection-import/invalid-source-no-toc");

    private File importedAstronomy = new File("invalid-path");
    private File importedEntrepreneurship = new File("invalid-path");
    private File importedScanWithInvalidFormatName = new File("invalid-path");

    @Before
    public void verifyArrangement() {
        Assert.assertFalse(importedAstronomy.exists());
        Assert.assertFalse(importedEntrepreneurship.exists());
        Assert.assertFalse(importedScanWithInvalidFormatName.exists());
    }

    @After
    public void cleanUp() throws IOException {
        FileUtils.deleteDirectory(importedAstronomy);
        FileUtils.deleteDirectory(importedEntrepreneurship);
        FileUtils.deleteDirectory(importedScanWithInvalidFormatName);
    }

    @Test
    public void should_import_correctly_named_files() throws IOException, InterruptedException {
        final int NUMBER_OF_FILES_IN_ORIGINAL_ASTRONOMY_FOLDER = 4;
        final int NUMBER_OF_FILES_IN_ORIGINAL_ENTREPRENEURSHIP_FOLDER = 3;
        ScanDirectoryImporter scanDirectoryImporter = new ScanDirectoryImporter();

        String astronomyImportOutputPath = scanDirectoryImporter.handleScanImport(ASTRONOMY_ORIGINAL_FILE,
                SharedConstants.NAME_OF_DIRECTORY_THAT_CONTAINS_SCANS + File.separator);
        String entrepreneurshipImportOutputPath = scanDirectoryImporter.handleScanImport(ENTREPRENEURSHIP_ORIGINAL_FILE,
                SharedConstants.NAME_OF_DIRECTORY_THAT_CONTAINS_SCANS + File.separator);

        importedAstronomy = new File(astronomyImportOutputPath);
        importedEntrepreneurship = new File(entrepreneurshipImportOutputPath);

        Assert.assertTrue(importedAstronomy.exists());
        Assert.assertTrue(importedAstronomy.listFiles().length == NUMBER_OF_FILES_IN_ORIGINAL_ASTRONOMY_FOLDER);

        Assert.assertTrue(importedEntrepreneurship.exists());
        Assert.assertTrue(importedEntrepreneurship.listFiles().length == NUMBER_OF_FILES_IN_ORIGINAL_ENTREPRENEURSHIP_FOLDER);

        Assert.assertTrue(Integer.parseInt(importedAstronomy.getName()) == Integer.parseInt(importedEntrepreneurship.getName()) - 1);
    }

    @Test
    public void should_import_incorrectly_named_files() throws IOException, InterruptedException {
        final int NUMBER_OF_FILES_IN_INVALID_FORMAT_NAME_FOLDER = 2;
        ScanDirectoryImporter scanDirectoryImporter = new ScanDirectoryImporter();

        String scanImportOutputPath = scanDirectoryImporter.handleScanImport(INVALID_FORMAT_ORIGINAL_FILE,
                SharedConstants.NAME_OF_DIRECTORY_THAT_CONTAINS_SCANS + File.separator);

        importedScanWithInvalidFormatName = new File(scanImportOutputPath);

        Assert.assertTrue(importedScanWithInvalidFormatName.exists());
        Assert.assertTrue(importedScanWithInvalidFormatName.getName().matches("^\\d+$"));
        Assert.assertTrue(importedScanWithInvalidFormatName.listFiles().length == 2);
    }

    @Test
    public void should_not_import_incorrect_source_files() throws IOException, InterruptedException {
        ScanDirectoryImporter scanDirectoryImporter = new ScanDirectoryImporter();

        String noInfoOutputPath = scanDirectoryImporter.handleScanImport(INVALID_SOURCE_NO_INFO,
                SharedConstants.NAME_OF_DIRECTORY_THAT_CONTAINS_SCANS + File.separator);
        String noToCImportOutputPath = scanDirectoryImporter.handleScanImport(INVALID_SOURCE_NO_TOC,
                SharedConstants.NAME_OF_DIRECTORY_THAT_CONTAINS_SCANS + File.separator);

        Assert.assertEquals(ConstantMessages.INVALID_SOURCE_DIRECTORY, noInfoOutputPath);
        Assert.assertEquals(ConstantMessages.INVALID_SOURCE_DIRECTORY, noToCImportOutputPath);
    }
}
