package webviewselenium.gui.chooseBookMenu;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class BookChooserTest {

    @Test
    public void getFullInformationAboutBook() {
        // WRÓCIĆ DO TEGO, ROZDZIEL OPIS ZA POMOCĄ SPACJI
        // ZWRÓĆ UWAGĘ, ZE CZAS I SCIEZKA SA ZE SOBA SKLEJONE
        String fullDescription = "Anatomy and Physiology  zxcvhh  Chrome        zxcvbnm         https://openstax.org/ .25.11.2019       4ScanDB/6";
        String expectedDomain = "https_++staging.cnx";
        //assertEquals(versionFinder.find(rexImagePath), expectedDomain);
    }
    //
}
