package gui.compareBookMenu.utilities;

import org.junit.jupiter.api.Test;
import webviewselenium.gui.compareBookMenu.utilities.BookInformationFormatter;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class BookInformationFormatterTest {
	BookInformationFormatter bookInformationFormatter = new BookInformationFormatter();

	@Test
	void chapterNamesAreFormattedProperly() {
		List<String> pathsToFiles = Stream.of(
		"ScanDB/Results/https_++openstax.org+books+anatomy-and-physiology+pages+1-6-anatomical-terminology_4.png",
		"ScanDB/Results/https_++openstax.org+books+entrepreneurship+pages+1-case-questions_1.png").collect(Collectors.toList());

		List<String> formattedChapterNames = Stream.of(
				"1.6 Anatomical Terminology", "1. Case Questions").collect(Collectors.toList());

		IntStream.range(0, pathsToFiles.size()).forEach(pathIndex -> {
			assertEquals(formattedChapterNames.get(pathIndex), bookInformationFormatter.getFormattedChapterName(pathsToFiles.get(pathIndex)));
		});
	}

}
