pkill -9 -f cnx-books-scanner

